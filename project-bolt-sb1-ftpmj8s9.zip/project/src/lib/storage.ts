import { Medicine, StockBatch, Patient, Doctor, Dispense, Invoice, Alert, Category, DosageForm, Unit, PackagingType, Supplier, ClinicSettings, TaxRule, StockMovement, Payment } from '../types';

const STORAGE_KEYS = {
  MEDICINES: 'medical_inventory_medicines',
  STOCK_BATCHES: 'medical_inventory_stock_batches',
  STOCK_MOVEMENTS: 'medical_inventory_stock_movements',
  PATIENTS: 'medical_inventory_patients',
  DOCTORS: 'medical_inventory_doctors',
  DISPENSES: 'medical_inventory_dispenses',
  INVOICES: 'medical_inventory_invoices',
  PAYMENTS: 'medical_inventory_payments',
  ALERTS: 'medical_inventory_alerts',
  CATEGORIES: 'medical_inventory_categories',
  DOSAGE_FORMS: 'medical_inventory_dosage_forms',
  UNITS: 'medical_inventory_units',
  PACKAGING_TYPES: 'medical_inventory_packaging_types',
  SUPPLIERS: 'medical_inventory_suppliers',
  CLINIC_SETTINGS: 'medical_inventory_clinic_settings',
  TAX_RULES: 'medical_inventory_tax_rules',
};

export class StorageService {
  private static getItem<T>(key: string): T[] {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private static setItem<T>(key: string, data: T[]): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  static getMedicines(): Medicine[] {
    return this.getItem<Medicine>(STORAGE_KEYS.MEDICINES);
  }

  static saveMedicine(medicine: Medicine): void {
    const medicines = this.getMedicines();
    const index = medicines.findIndex(m => m.id === medicine.id);
    if (index >= 0) {
      medicines[index] = medicine;
    } else {
      medicines.push(medicine);
    }
    this.setItem(STORAGE_KEYS.MEDICINES, medicines);
  }

  static deleteMedicine(id: string): void {
    const medicines = this.getMedicines().filter(m => m.id !== id);
    this.setItem(STORAGE_KEYS.MEDICINES, medicines);
  }

  static getStockBatches(): StockBatch[] {
    return this.getItem<StockBatch>(STORAGE_KEYS.STOCK_BATCHES);
  }

  static saveStockBatch(batch: StockBatch): void {
    const batches = this.getStockBatches();
    const index = batches.findIndex(b => b.id === batch.id);
    if (index >= 0) {
      batches[index] = batch;
    } else {
      batches.push(batch);
    }
    this.setItem(STORAGE_KEYS.STOCK_BATCHES, batches);
  }

  static deleteStockBatch(id: string): void {
    const batches = this.getStockBatches().filter(b => b.id !== id);
    this.setItem(STORAGE_KEYS.STOCK_BATCHES, batches);
  }

  static getStockMovements(): StockMovement[] {
    return this.getItem<StockMovement>(STORAGE_KEYS.STOCK_MOVEMENTS);
  }

  static saveStockMovement(movement: StockMovement): void {
    const movements = this.getStockMovements();
    movements.push(movement);
    this.setItem(STORAGE_KEYS.STOCK_MOVEMENTS, movements);
  }

  static getPatients(): Patient[] {
    return this.getItem<Patient>(STORAGE_KEYS.PATIENTS);
  }

  static savePatient(patient: Patient): void {
    const patients = this.getPatients();
    const index = patients.findIndex(p => p.id === patient.id);
    if (index >= 0) {
      patients[index] = patient;
    } else {
      patients.push(patient);
    }
    this.setItem(STORAGE_KEYS.PATIENTS, patients);
  }

  static deletePatient(id: string): void {
    const patients = this.getPatients().filter(p => p.id !== id);
    this.setItem(STORAGE_KEYS.PATIENTS, patients);
  }

  static getDoctors(): Doctor[] {
    return this.getItem<Doctor>(STORAGE_KEYS.DOCTORS);
  }

  static saveDoctor(doctor: Doctor): void {
    const doctors = this.getDoctors();
    const index = doctors.findIndex(d => d.id === doctor.id);
    if (index >= 0) {
      doctors[index] = doctor;
    } else {
      doctors.push(doctor);
    }
    this.setItem(STORAGE_KEYS.DOCTORS, doctors);
  }

  static deleteDoctor(id: string): void {
    const doctors = this.getDoctors().filter(d => d.id !== id);
    this.setItem(STORAGE_KEYS.DOCTORS, doctors);
  }

  static getDispenses(): Dispense[] {
    return this.getItem<Dispense>(STORAGE_KEYS.DISPENSES);
  }

  static saveDispense(dispense: Dispense): void {
    const dispenses = this.getDispenses();
    const index = dispenses.findIndex(d => d.id === dispense.id);
    if (index >= 0) {
      dispenses[index] = dispense;
    } else {
      dispenses.push(dispense);
    }
    this.setItem(STORAGE_KEYS.DISPENSES, dispenses);
  }

  static deleteDispense(id: string): void {
    const dispenses = this.getDispenses().filter(d => d.id !== id);
    this.setItem(STORAGE_KEYS.DISPENSES, dispenses);
  }

  static getInvoices(): Invoice[] {
    return this.getItem<Invoice>(STORAGE_KEYS.INVOICES);
  }

  static saveInvoice(invoice: Invoice): void {
    const invoices = this.getInvoices();
    const index = invoices.findIndex(i => i.id === invoice.id);
    if (index >= 0) {
      invoices[index] = invoice;
    } else {
      invoices.push(invoice);
    }
    this.setItem(STORAGE_KEYS.INVOICES, invoices);
  }

  static deleteInvoice(id: string): void {
    const invoices = this.getInvoices().filter(i => i.id !== id);
    this.setItem(STORAGE_KEYS.INVOICES, invoices);
  }

  static getPayments(): Payment[] {
    return this.getItem<Payment>(STORAGE_KEYS.PAYMENTS);
  }

  static savePayment(payment: Payment): void {
    const payments = this.getPayments();
    payments.push(payment);
    this.setItem(STORAGE_KEYS.PAYMENTS, payments);
  }

  static getAlerts(): Alert[] {
    return this.getItem<Alert>(STORAGE_KEYS.ALERTS);
  }

  static saveAlert(alert: Alert): void {
    const alerts = this.getAlerts();
    const index = alerts.findIndex(a => a.id === alert.id);
    if (index >= 0) {
      alerts[index] = alert;
    } else {
      alerts.push(alert);
    }
    this.setItem(STORAGE_KEYS.ALERTS, alerts);
  }

  static deleteAlert(id: string): void {
    const alerts = this.getAlerts().filter(a => a.id !== id);
    this.setItem(STORAGE_KEYS.ALERTS, alerts);
  }

  static getCategories(): Category[] {
    return this.getItem<Category>(STORAGE_KEYS.CATEGORIES);
  }

  static saveCategory(category: Category): void {
    const categories = this.getCategories();
    const index = categories.findIndex(c => c.id === category.id);
    if (index >= 0) {
      categories[index] = category;
    } else {
      categories.push(category);
    }
    this.setItem(STORAGE_KEYS.CATEGORIES, categories);
  }

  static deleteCategory(id: string): void {
    const categories = this.getCategories().filter(c => c.id !== id);
    this.setItem(STORAGE_KEYS.CATEGORIES, categories);
  }

  static getDosageForms(): DosageForm[] {
    return this.getItem<DosageForm>(STORAGE_KEYS.DOSAGE_FORMS);
  }

  static saveDosageForm(form: DosageForm): void {
    const forms = this.getDosageForms();
    const index = forms.findIndex(f => f.id === form.id);
    if (index >= 0) {
      forms[index] = form;
    } else {
      forms.push(form);
    }
    this.setItem(STORAGE_KEYS.DOSAGE_FORMS, forms);
  }

  static deleteDosageForm(id: string): void {
    const forms = this.getDosageForms().filter(f => f.id !== id);
    this.setItem(STORAGE_KEYS.DOSAGE_FORMS, forms);
  }

  static getUnits(): Unit[] {
    return this.getItem<Unit>(STORAGE_KEYS.UNITS);
  }

  static saveUnit(unit: Unit): void {
    const units = this.getUnits();
    const index = units.findIndex(u => u.id === unit.id);
    if (index >= 0) {
      units[index] = unit;
    } else {
      units.push(unit);
    }
    this.setItem(STORAGE_KEYS.UNITS, units);
  }

  static deleteUnit(id: string): void {
    const units = this.getUnits().filter(u => u.id !== id);
    this.setItem(STORAGE_KEYS.UNITS, units);
  }

  static getPackagingTypes(): PackagingType[] {
    return this.getItem<PackagingType>(STORAGE_KEYS.PACKAGING_TYPES);
  }

  static savePackagingType(type: PackagingType): void {
    const types = this.getPackagingTypes();
    const index = types.findIndex(t => t.id === type.id);
    if (index >= 0) {
      types[index] = type;
    } else {
      types.push(type);
    }
    this.setItem(STORAGE_KEYS.PACKAGING_TYPES, types);
  }

  static deletePackagingType(id: string): void {
    const types = this.getPackagingTypes().filter(t => t.id !== id);
    this.setItem(STORAGE_KEYS.PACKAGING_TYPES, types);
  }

  static getSuppliers(): Supplier[] {
    return this.getItem<Supplier>(STORAGE_KEYS.SUPPLIERS);
  }

  static saveSupplier(supplier: Supplier): void {
    const suppliers = this.getSuppliers();
    const index = suppliers.findIndex(s => s.id === supplier.id);
    if (index >= 0) {
      suppliers[index] = supplier;
    } else {
      suppliers.push(supplier);
    }
    this.setItem(STORAGE_KEYS.SUPPLIERS, suppliers);
  }

  static deleteSupplier(id: string): void {
    const suppliers = this.getSuppliers().filter(s => s.id !== id);
    this.setItem(STORAGE_KEYS.SUPPLIERS, suppliers);
  }

  static getClinicSettings(): ClinicSettings | null {
    const settings = this.getItem<ClinicSettings>(STORAGE_KEYS.CLINIC_SETTINGS);
    return settings.length > 0 ? settings[0] : null;
  }

  static saveClinicSettings(settings: ClinicSettings): void {
    this.setItem(STORAGE_KEYS.CLINIC_SETTINGS, [settings]);
  }

  static getTaxRules(): TaxRule[] {
    return this.getItem<TaxRule>(STORAGE_KEYS.TAX_RULES);
  }

  static saveTaxRule(rule: TaxRule): void {
    const rules = this.getTaxRules();
    const index = rules.findIndex(r => r.id === rule.id);
    if (index >= 0) {
      rules[index] = rule;
    } else {
      rules.push(rule);
    }
    this.setItem(STORAGE_KEYS.TAX_RULES, rules);
  }

  static deleteTaxRule(id: string): void {
    const rules = this.getTaxRules().filter(r => r.id !== id);
    this.setItem(STORAGE_KEYS.TAX_RULES, rules);
  }

  static initializeDefaultData(): void {
    if (this.getCategories().length === 0) {
      const defaultCategories: Category[] = [
        { id: '1', name: 'Antibiotics', description: 'Antimicrobial medications' },
        { id: '2', name: 'Analgesics', description: 'Pain relief medications' },
        { id: '3', name: 'Antipyretics', description: 'Fever reducing medications' },
        { id: '4', name: 'Vitamins', description: 'Vitamin supplements' },
      ];
      this.setItem(STORAGE_KEYS.CATEGORIES, defaultCategories);
    }

    if (this.getDosageForms().length === 0) {
      const defaultForms: DosageForm[] = [
        { id: '1', name: 'Tablet', description: 'Solid oral dosage' },
        { id: '2', name: 'Capsule', description: 'Gelatin shell oral dosage' },
        { id: '3', name: 'Syrup', description: 'Liquid oral dosage' },
        { id: '4', name: 'Injection', description: 'Injectable solution' },
      ];
      this.setItem(STORAGE_KEYS.DOSAGE_FORMS, defaultForms);
    }

    if (this.getUnits().length === 0) {
      const defaultUnits: Unit[] = [
        { id: '1', name: 'Strip', abbreviation: 'str' },
        { id: '2', name: 'Bottle', abbreviation: 'btl' },
        { id: '3', name: 'Box', abbreviation: 'box' },
        { id: '4', name: 'Vial', abbreviation: 'vial' },
        { id: '5', name: 'Piece', abbreviation: 'pc' },
      ];
      this.setItem(STORAGE_KEYS.UNITS, defaultUnits);
    }

    if (!this.getClinicSettings()) {
      const defaultSettings: ClinicSettings = {
        id: '1',
        clinicName: 'Medical Care Clinic',
        address: '123 Healthcare Ave, Medical District',
        phone: '+1 (555) 123-4567',
        email: 'info@medicalcare.com',
        taxId: 'TAX123456',
        currency: 'USD',
        invoiceFooter: 'Thank you for your business!',
      };
      this.saveClinicSettings(defaultSettings);
    }

    if (this.getTaxRules().length === 0) {
      const defaultTaxRule: TaxRule = {
        id: '1',
        name: 'Standard Tax',
        taxRate: 10,
        isDefault: true,
        isActive: true,
      };
      this.setItem(STORAGE_KEYS.TAX_RULES, [defaultTaxRule]);
    }
  }
}
