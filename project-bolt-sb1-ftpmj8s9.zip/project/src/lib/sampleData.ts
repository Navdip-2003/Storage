import { StorageService } from './storage';
import { Medicine, StockBatch, Supplier, Patient, Doctor, Invoice } from '../types';

export function initializeSampleData() {
  if (StorageService.getMedicines().length > 0) {
    return;
  }

  const suppliers: Supplier[] = [
    {
      id: 'sup_1',
      name: 'MediPharm Distributors',
      contactPerson: 'John Smith',
      phone: '+1-555-0101',
      email: 'orders@medipharm.com',
      address: '456 Commerce St, Medical City',
      paymentTerms: 'Net 30',
      isActive: true,
    },
    {
      id: 'sup_2',
      name: 'HealthCare Supplies Inc',
      contactPerson: 'Sarah Johnson',
      phone: '+1-555-0202',
      email: 'sales@healthcaresupplies.com',
      address: '789 Industrial Blvd, Medical District',
      paymentTerms: 'Net 45',
      isActive: true,
    },
  ];

  suppliers.forEach(supplier => StorageService.saveSupplier(supplier));

  const medicines: Medicine[] = [
    {
      id: 'med_1',
      name: 'Amoxicillin',
      genericName: 'Amoxicillin',
      categoryId: '1',
      dosageFormId: '2',
      strength: '500mg',
      packSize: '10 capsules',
      manufacturer: 'PharmaCorp',
      defaultUnitId: '1',
      defaultUnitPrice: 12.50,
      reorderLevel: 50,
      defaultSupplierId: 'sup_1',
      barcode: 'MED001',
      isActive: true,
    },
    {
      id: 'med_2',
      name: 'Paracetamol',
      genericName: 'Acetaminophen',
      categoryId: '2',
      dosageFormId: '1',
      strength: '500mg',
      packSize: '10 tablets',
      manufacturer: 'MediGen',
      defaultUnitId: '1',
      defaultUnitPrice: 5.00,
      reorderLevel: 100,
      defaultSupplierId: 'sup_1',
      barcode: 'MED002',
      isActive: true,
    },
    {
      id: 'med_3',
      name: 'Ibuprofen',
      genericName: 'Ibuprofen',
      categoryId: '2',
      dosageFormId: '1',
      strength: '400mg',
      packSize: '10 tablets',
      manufacturer: 'PainRelief Labs',
      defaultUnitId: '1',
      defaultUnitPrice: 8.00,
      reorderLevel: 75,
      defaultSupplierId: 'sup_2',
      barcode: 'MED003',
      isActive: true,
    },
    {
      id: 'med_4',
      name: 'Cough Syrup',
      genericName: 'Dextromethorphan',
      categoryId: '2',
      dosageFormId: '3',
      strength: '100ml',
      packSize: '1 bottle',
      manufacturer: 'CoughCare',
      defaultUnitId: '2',
      defaultUnitPrice: 15.00,
      reorderLevel: 30,
      defaultSupplierId: 'sup_2',
      barcode: 'MED004',
      isActive: true,
    },
    {
      id: 'med_5',
      name: 'Vitamin C',
      genericName: 'Ascorbic Acid',
      categoryId: '4',
      dosageFormId: '1',
      strength: '1000mg',
      packSize: '30 tablets',
      manufacturer: 'VitaHealth',
      defaultUnitId: '3',
      defaultUnitPrice: 18.00,
      reorderLevel: 40,
      defaultSupplierId: 'sup_1',
      barcode: 'MED005',
      isActive: true,
    },
  ];

  medicines.forEach(medicine => StorageService.saveMedicine(medicine));

  const today = new Date();
  const batches: StockBatch[] = [
    {
      id: 'batch_1',
      medicineId: 'med_1',
      batchNumber: 'AMOX2024A',
      expiryDate: new Date(today.getFullYear(), today.getMonth() + 6, 15).toISOString().split('T')[0],
      quantity: 120,
      unitPrice: 12.50,
      supplierId: 'sup_1',
      purchaseDate: new Date(today.getFullYear(), today.getMonth() - 1, 10).toISOString().split('T')[0],
      location: 'Shelf A-1',
    },
    {
      id: 'batch_2',
      medicineId: 'med_2',
      batchNumber: 'PARA2024B',
      expiryDate: new Date(today.getFullYear(), today.getMonth() + 12, 20).toISOString().split('T')[0],
      quantity: 200,
      unitPrice: 5.00,
      supplierId: 'sup_1',
      purchaseDate: new Date(today.getFullYear(), today.getMonth() - 2, 5).toISOString().split('T')[0],
      location: 'Shelf A-2',
    },
    {
      id: 'batch_3',
      medicineId: 'med_3',
      batchNumber: 'IBU2024C',
      expiryDate: new Date(today.getFullYear(), today.getMonth() + 2, 10).toISOString().split('T')[0],
      quantity: 45,
      unitPrice: 8.00,
      supplierId: 'sup_2',
      purchaseDate: new Date(today.getFullYear(), today.getMonth() - 1, 15).toISOString().split('T')[0],
      location: 'Shelf B-1',
    },
    {
      id: 'batch_4',
      medicineId: 'med_4',
      batchNumber: 'COUGH2024D',
      expiryDate: new Date(today.getFullYear(), today.getMonth() + 8, 25).toISOString().split('T')[0],
      quantity: 60,
      unitPrice: 15.00,
      supplierId: 'sup_2',
      purchaseDate: new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0],
      location: 'Shelf C-1',
    },
    {
      id: 'batch_5',
      medicineId: 'med_5',
      batchNumber: 'VITC2024E',
      expiryDate: new Date(today.getFullYear() + 1, today.getMonth() + 3, 30).toISOString().split('T')[0],
      quantity: 80,
      unitPrice: 18.00,
      supplierId: 'sup_1',
      purchaseDate: new Date(today.getFullYear(), today.getMonth(), 10).toISOString().split('T')[0],
      location: 'Shelf D-1',
    },
  ];

  batches.forEach(batch => StorageService.saveStockBatch(batch));

  const patients: Patient[] = [
    {
      id: 'pat_1',
      patientCode: 'PAT001',
      firstName: 'Michael',
      lastName: 'Johnson',
      dateOfBirth: '1985-06-15',
      gender: 'Male',
      phone: '+1-555-1001',
      email: 'michael.j@email.com',
      address: '123 Main St, City',
      isActive: true,
    },
    {
      id: 'pat_2',
      patientCode: 'PAT002',
      firstName: 'Emma',
      lastName: 'Wilson',
      dateOfBirth: '1992-03-22',
      gender: 'Female',
      phone: '+1-555-1002',
      email: 'emma.w@email.com',
      address: '456 Oak Ave, City',
      isActive: true,
    },
  ];

  patients.forEach(patient => StorageService.savePatient(patient));

  const doctors: Doctor[] = [
    {
      id: 'doc_1',
      name: 'Dr. Sarah Mitchell',
      specialization: 'General Practitioner',
      phone: '+1-555-2001',
      email: 'dr.mitchell@clinic.com',
      registrationNumber: 'MD12345',
      isActive: true,
    },
  ];

  doctors.forEach(doctor => StorageService.saveDoctor(doctor));

  const sampleInvoices: Invoice[] = [
    {
      id: 'inv_1',
      invoiceNumber: 'INV-2024-001',
      patientId: 'pat_1',
      invoiceDate: today.toISOString().split('T')[0],
      subtotal: 50.00,
      taxAmount: 5.00,
      discountAmount: 0,
      totalAmount: 55.00,
      paidAmount: 55.00,
      paymentStatus: 'Paid',
      paymentMethod: 'Cash',
      items: [
        {
          id: 'invitem_1',
          invoiceId: 'inv_1',
          medicineId: 'med_2',
          batchId: 'batch_2',
          quantity: 2,
          unitPrice: 5.00,
          taxRate: 10,
          taxAmount: 1.00,
          discountAmount: 0,
          lineTotal: 11.00,
        },
      ],
    },
  ];

  sampleInvoices.forEach(invoice => StorageService.saveInvoice(invoice));

  console.log('Sample data initialized successfully!');
}
