import { useState } from 'react';
import { SubNav } from '../components/Layout/SubNav';
import { BarChart3, Download } from 'lucide-react';

export function Reports() {
  const [activeTab, setActiveTab] = useState('inventory');

  const tabs = [
    { id: 'inventory', label: 'Inventory Reports' },
    { id: 'sales', label: 'Sales Reports' },
    { id: 'audit', label: 'Audit Logs' },
  ];

  return (
    <div className="flex flex-col h-full">
      <SubNav items={tabs} activeItem={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 overflow-auto p-6">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">Reports</h2>
          <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-8 text-center">
          <BarChart3 className="w-16 h-16 mx-auto mb-4 text-slate-400" />
          <h3 className="text-xl font-semibold text-slate-800 mb-2">Reports Module</h3>
          <p className="text-slate-600">
            Comprehensive reporting with inventory valuation, sales analytics, and audit trails
          </p>
        </div>
      </div>
    </div>
  );
}
