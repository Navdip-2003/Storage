import { useEffect, useState } from 'react';
import { StorageService } from '../lib/storage';
import { DollarSign, Package, AlertTriangle, Calendar, TrendingUp, Plus, FileText } from 'lucide-react';

export function Dashboard() {
  const [stats, setStats] = useState({
    totalStockValue: 0,
    todaySales: 0,
    lowStockCount: 0,
    expiringBatches: 0,
  });

  const [salesByDay, setSalesByDay] = useState<{ day: string; amount: number }[]>([]);
  const [stockByCategory, setStockByCategory] = useState<{ category: string; value: number }[]>([]);

  useEffect(() => {
    const batches = StorageService.getStockBatches();
    const medicines = StorageService.getMedicines();
    const invoices = StorageService.getInvoices();
    const alerts = StorageService.getAlerts();

    const totalValue = batches.reduce((sum, batch) => sum + batch.quantity * batch.unitPrice, 0);

    const today = new Date().toISOString().split('T')[0];
    const todayInvoices = invoices.filter(inv => inv.invoiceDate === today && inv.paymentStatus === 'Paid');
    const todaySalesTotal = todayInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);

    const lowStock = alerts.filter(a => a.alertType === 'LOW_STOCK' && !a.isAcknowledged).length;
    const expiring = alerts.filter(a => a.alertType === 'EXPIRY' && !a.isAcknowledged).length;

    setStats({
      totalStockValue: totalValue,
      todaySales: todaySalesTotal,
      lowStockCount: lowStock,
      expiringBatches: expiring,
    });

    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date.toISOString().split('T')[0];
    });

    const salesData = last7Days.map(date => {
      const dayInvoices = invoices.filter(inv => inv.invoiceDate === date && inv.paymentStatus === 'Paid');
      const amount = dayInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
      const dayName = new Date(date).toLocaleDateString('en-US', { weekday: 'short' });
      return { day: dayName, amount };
    });
    setSalesByDay(salesData);

    const categories = StorageService.getCategories();
    const categoryData = categories.map(cat => {
      const categoryMeds = medicines.filter(m => m.categoryId === cat.id);
      const value = batches
        .filter(b => categoryMeds.some(m => m.id === b.medicineId))
        .reduce((sum, b) => sum + b.quantity * b.unitPrice, 0);
      return { category: cat.name, value };
    }).filter(c => c.value > 0);
    setStockByCategory(categoryData);
  }, []);

  const maxSales = Math.max(...salesByDay.map(d => d.amount), 1);
  const maxStock = Math.max(...stockByCategory.map(c => c.value), 1);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800">Dashboard</h1>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Plus className="w-4 h-4" />
            Add Stock
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <FileText className="w-4 h-4" />
            Create Invoice
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Total Stock Value</p>
              <p className="text-2xl font-bold text-slate-800 mt-2">
                ${stats.totalStockValue.toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Today's Sales</p>
              <p className="text-2xl font-bold text-slate-800 mt-2">
                ${stats.todaySales.toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Low Stock Items</p>
              <p className="text-2xl font-bold text-slate-800 mt-2">{stats.lowStockCount}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Expiring Batches</p>
              <p className="text-2xl font-bold text-slate-800 mt-2">{stats.expiringBatches}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Sales - Last 7 Days</h3>
          <div className="space-y-3">
            {salesByDay.map((day) => (
              <div key={day.day} className="flex items-center gap-3">
                <span className="w-12 text-sm font-medium text-slate-600">{day.day}</span>
                <div className="flex-1 bg-slate-100 rounded-full h-8 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full flex items-center justify-end pr-3"
                    style={{ width: `${(day.amount / maxSales) * 100}%` }}
                  >
                    {day.amount > 0 && (
                      <span className="text-xs font-semibold text-white">
                        ${day.amount.toFixed(0)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Stock Value by Category</h3>
          <div className="space-y-3">
            {stockByCategory.length > 0 ? (
              stockByCategory.map((cat) => (
                <div key={cat.category} className="flex items-center gap-3">
                  <span className="w-24 text-sm font-medium text-slate-600 truncate">
                    {cat.category}
                  </span>
                  <div className="flex-1 bg-slate-100 rounded-full h-8 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-green-500 to-green-600 h-full rounded-full flex items-center justify-end pr-3"
                      style={{ width: `${(cat.value / maxStock) * 100}%` }}
                    >
                      <span className="text-xs font-semibold text-white">
                        ${cat.value.toFixed(0)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-500">
                <Package className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No stock data available</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="p-4 border-2 border-slate-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left">
            <Plus className="w-6 h-6 text-blue-600 mb-2" />
            <p className="font-semibold text-slate-800">Add Medicine</p>
            <p className="text-xs text-slate-500">Add to catalog</p>
          </button>
          <button className="p-4 border-2 border-slate-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all text-left">
            <Package className="w-6 h-6 text-green-600 mb-2" />
            <p className="font-semibold text-slate-800">Receive Stock</p>
            <p className="text-xs text-slate-500">Add inventory</p>
          </button>
          <button className="p-4 border-2 border-slate-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all text-left">
            <FileText className="w-6 h-6 text-purple-600 mb-2" />
            <p className="font-semibold text-slate-800">New Dispense</p>
            <p className="text-xs text-slate-500">Dispense medicine</p>
          </button>
          <button className="p-4 border-2 border-slate-200 rounded-lg hover:border-orange-500 hover:bg-orange-50 transition-all text-left">
            <DollarSign className="w-6 h-6 text-orange-600 mb-2" />
            <p className="font-semibold text-slate-800">Create Invoice</p>
            <p className="text-xs text-slate-500">Bill patient</p>
          </button>
        </div>
      </div>
    </div>
  );
}
