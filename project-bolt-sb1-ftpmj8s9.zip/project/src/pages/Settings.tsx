import { useState, useEffect } from 'react';
import { SubNav } from '../components/Layout/SubNav';
import { StorageService } from '../lib/storage';
import { ClinicSettings } from '../types';

export function Settings() {
  const [activeTab, setActiveTab] = useState('clinic');
  const [clinicSettings, setClinicSettings] = useState<ClinicSettings | null>(null);

  const tabs = [
    { id: 'clinic', label: 'Clinic Profile' },
    { id: 'tax', label: 'Tax & Pricing' },
    { id: 'users', label: 'Users & Roles' },
  ];

  useEffect(() => {
    const settings = StorageService.getClinicSettings();
    setClinicSettings(settings);
  }, []);

  const handleClinicUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (clinicSettings) {
      StorageService.saveClinicSettings(clinicSettings);
      alert('Settings updated successfully!');
    }
  };

  return (
    <div className="flex flex-col h-full">
      <SubNav items={tabs} activeItem={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'clinic' && clinicSettings && (
          <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Clinic Profile</h2>
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 max-w-2xl">
              <form onSubmit={handleClinicUpdate} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Clinic Name *
                  </label>
                  <input
                    type="text"
                    value={clinicSettings.clinicName}
                    onChange={(e) => setClinicSettings({ ...clinicSettings, clinicName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                  <textarea
                    value={clinicSettings.address || ''}
                    onChange={(e) => setClinicSettings({ ...clinicSettings, address: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                    <input
                      type="tel"
                      value={clinicSettings.phone || ''}
                      onChange={(e) => setClinicSettings({ ...clinicSettings, phone: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input
                      type="email"
                      value={clinicSettings.email || ''}
                      onChange={(e) => setClinicSettings({ ...clinicSettings, email: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Tax ID</label>
                    <input
                      type="text"
                      value={clinicSettings.taxId || ''}
                      onChange={(e) => setClinicSettings({ ...clinicSettings, taxId: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Currency</label>
                    <select
                      value={clinicSettings.currency}
                      onChange={(e) => setClinicSettings({ ...clinicSettings, currency: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                      <option value="GBP">GBP</option>
                      <option value="INR">INR</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Invoice Footer
                  </label>
                  <textarea
                    value={clinicSettings.invoiceFooter || ''}
                    onChange={(e) => setClinicSettings({ ...clinicSettings, invoiceFooter: e.target.value })}
                    rows={2}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Thank you for your business!"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'tax' && (
          <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Tax & Pricing Rules</h2>
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <p className="text-slate-600">Configure tax rates and pricing rules for invoices.</p>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Users & Roles</h2>
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
              <p className="text-slate-600">Manage user accounts and role permissions.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
