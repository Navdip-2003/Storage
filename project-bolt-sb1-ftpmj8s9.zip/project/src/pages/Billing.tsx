import { useState, useEffect } from 'react';
import { SubNav } from '../components/Layout/SubNav';
import { Plus, FileText } from 'lucide-react';
import { StorageService } from '../lib/storage';

export function Billing() {
  const [activeTab, setActiveTab] = useState('invoices');
  const [invoices, setInvoices] = useState(StorageService.getInvoices());

  const tabs = [
    { id: 'create', label: 'Create Invoice' },
    { id: 'invoices', label: 'Invoice List' },
  ];

  useEffect(() => {
    setInvoices(StorageService.getInvoices());
  }, [activeTab]);

  return (
    <div className="flex flex-col h-full">
      <SubNav items={tabs} activeItem={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'create' ? (
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-8 text-center">
            <Plus className="w-16 h-16 mx-auto mb-4 text-slate-400" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">Create New Invoice</h3>
            <p className="text-slate-600">Invoice creation form with line items, taxes, and payment processing</p>
          </div>
        ) : (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-800">Invoice List</h2>
            </div>
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Invoice No.</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Date</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Total</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-4 py-8 text-center text-slate-500">
                        <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No invoices yet</p>
                      </td>
                    </tr>
                  ) : (
                    invoices.map((invoice) => (
                      <tr key={invoice.id} className="hover:bg-slate-50 border-b border-slate-200">
                        <td className="px-4 py-3 text-sm font-medium text-slate-800">{invoice.invoiceNumber}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">{new Date(invoice.invoiceDate).toLocaleDateString()}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">${invoice.totalAmount.toFixed(2)}</td>
                        <td className="px-4 py-3 text-sm">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${
                            invoice.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' :
                            invoice.paymentStatus === 'Partial' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-red-100 text-red-700'
                          }`}>
                            {invoice.paymentStatus}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
