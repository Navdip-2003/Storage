import { useState } from 'react';
import { SubNav } from '../components/Layout/SubNav';
import { MedicineCatalog } from '../components/Inventory/MedicineCatalog';
import { StockManagement } from '../components/Inventory/StockManagement';
import { StockLevels } from '../components/Inventory/StockLevels';
import { Suppliers } from '../components/Inventory/Suppliers';
import { ReferenceData } from '../components/Inventory/ReferenceData';

export function Inventory() {
  const [activeTab, setActiveTab] = useState('catalog');

  const tabs = [
    { id: 'catalog', label: 'Medicine Catalog' },
    { id: 'add-stock', label: 'Add Stock' },
    { id: 'stock-levels', label: 'Stock Levels' },
    { id: 'suppliers', label: 'Suppliers' },
    { id: 'reference', label: 'Reference Data' },
  ];

  return (
    <div className="flex flex-col h-full">
      <SubNav items={tabs} activeItem={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 overflow-auto">
        {activeTab === 'catalog' && <MedicineCatalog />}
        {activeTab === 'add-stock' && <StockManagement />}
        {activeTab === 'stock-levels' && <StockLevels />}
        {activeTab === 'suppliers' && <Suppliers />}
        {activeTab === 'reference' && <ReferenceData />}
      </div>
    </div>
  );
}
