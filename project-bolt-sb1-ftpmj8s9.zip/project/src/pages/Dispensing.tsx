import { useState } from 'react';
import { SubNav } from '../components/Layout/SubNav';
import { Package } from 'lucide-react';

export function Dispensing() {
  const [activeTab, setActiveTab] = useState('new-dispense');

  const tabs = [
    { id: 'new-dispense', label: 'New Dispense' },
    { id: 'history', label: 'Dispense History' },
  ];

  return (
    <div className="flex flex-col h-full">
      <SubNav items={tabs} activeItem={activeTab} onNavigate={setActiveTab} />
      <div className="flex-1 overflow-auto p-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-8 text-center">
          <Package className="w-16 h-16 mx-auto mb-4 text-slate-400" />
          <h3 className="text-xl font-semibold text-slate-800 mb-2">Dispensing Module</h3>
          <p className="text-slate-600">Dispense medicine to patients with FEFO batch selection</p>
        </div>
      </div>
    </div>
  );
}
