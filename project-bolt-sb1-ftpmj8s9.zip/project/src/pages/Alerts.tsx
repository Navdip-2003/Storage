import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Package, Calendar } from 'lucide-react';
import { StorageService } from '../lib/storage';
import { Alert } from '../types';

export function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    generateAlerts();
    loadAlerts();
  }, []);

  const generateAlerts = () => {
    const batches = StorageService.getStockBatches();
    const medicines = StorageService.getMedicines();
    const existingAlerts = StorageService.getAlerts();

    batches.forEach((batch) => {
      const medicine = medicines.find(m => m.id === batch.medicineId);
      if (!medicine) return;

      const expiryDate = new Date(batch.expiryDate);
      const today = new Date();
      const daysToExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      const existingExpiryAlert = existingAlerts.find(
        a => a.alertType === 'EXPIRY' && a.batchId === batch.id && !a.isAcknowledged
      );

      if ((daysToExpiry <= 90 && daysToExpiry >= 0) && !existingExpiryAlert) {
        const alert: Alert = {
          id: `alert_exp_${batch.id}_${Date.now()}`,
          alertType: 'EXPIRY',
          severity: daysToExpiry <= 30 ? 'critical' : 'warning',
          medicineId: batch.medicineId,
          batchId: batch.id,
          message: `${medicine.name} (Batch: ${batch.batchNumber}) expires in ${daysToExpiry} days`,
          isAcknowledged: false,
          createdAt: new Date().toISOString(),
        };
        StorageService.saveAlert(alert);
      }

      const totalStock = batches
        .filter(b => b.medicineId === medicine.id)
        .reduce((sum, b) => sum + b.quantity, 0);

      const existingLowStockAlert = existingAlerts.find(
        a => a.alertType === 'LOW_STOCK' && a.medicineId === medicine.id && !a.isAcknowledged
      );

      if (totalStock <= medicine.reorderLevel && !existingLowStockAlert) {
        const alert: Alert = {
          id: `alert_low_${medicine.id}_${Date.now()}`,
          alertType: 'LOW_STOCK',
          severity: totalStock === 0 ? 'critical' : 'warning',
          medicineId: medicine.id,
          message: `${medicine.name} stock is low (${totalStock} remaining, reorder at ${medicine.reorderLevel})`,
          isAcknowledged: false,
          createdAt: new Date().toISOString(),
        };
        StorageService.saveAlert(alert);
      }
    });
  };

  const loadAlerts = () => {
    setAlerts(StorageService.getAlerts().sort((a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };

  const handleAcknowledge = (id: string) => {
    const alert = alerts.find(a => a.id === id);
    if (alert) {
      alert.isAcknowledged = true;
      alert.acknowledgedAt = new Date().toISOString();
      StorageService.saveAlert(alert);
      loadAlerts();
    }
  };

  const unacknowledgedAlerts = alerts.filter(a => !a.isAcknowledged);
  const acknowledgedAlerts = alerts.filter(a => a.isAcknowledged);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Alerts & Notifications</h2>

      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Active Alerts ({unacknowledgedAlerts.length})
          </h3>

          {unacknowledgedAlerts.length === 0 ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
              <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-600" />
              <p className="text-green-700 font-medium">All clear! No active alerts.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {unacknowledgedAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`bg-white rounded-lg shadow-sm border-2 p-4 flex items-start justify-between ${
                    alert.severity === 'critical'
                      ? 'border-red-300 bg-red-50'
                      : 'border-yellow-300 bg-yellow-50'
                  }`}
                >
                  <div className="flex items-start gap-3 flex-1">
                    {alert.alertType === 'LOW_STOCK' ? (
                      <Package className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                        alert.severity === 'critical' ? 'text-red-600' : 'text-yellow-600'
                      }`} />
                    ) : (
                      <Calendar className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                        alert.severity === 'critical' ? 'text-red-600' : 'text-yellow-600'
                      }`} />
                    )}
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          alert.severity === 'critical'
                            ? 'bg-red-200 text-red-800'
                            : 'bg-yellow-200 text-yellow-800'
                        }`}>
                          {alert.severity === 'critical' ? 'CRITICAL' : 'WARNING'}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          alert.alertType === 'LOW_STOCK'
                            ? 'bg-blue-200 text-blue-800'
                            : 'bg-purple-200 text-purple-800'
                        }`}>
                          {alert.alertType === 'LOW_STOCK' ? 'LOW STOCK' : 'EXPIRY'}
                        </span>
                      </div>
                      <p className={`font-medium ${
                        alert.severity === 'critical' ? 'text-red-900' : 'text-yellow-900'
                      }`}>
                        {alert.message}
                      </p>
                      <p className="text-xs text-slate-600 mt-1">
                        {new Date(alert.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleAcknowledge(alert.id)}
                    className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors text-sm font-medium"
                  >
                    Acknowledge
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {acknowledgedAlerts.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Acknowledged Alerts ({acknowledgedAlerts.length})
            </h3>
            <div className="space-y-2">
              {acknowledgedAlerts.slice(0, 5).map((alert) => (
                <div
                  key={alert.id}
                  className="bg-white rounded-lg border border-slate-200 p-3 opacity-60"
                >
                  <p className="text-sm text-slate-700">{alert.message}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Acknowledged on {new Date(alert.acknowledgedAt!).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
