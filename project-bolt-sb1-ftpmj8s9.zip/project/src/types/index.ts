export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface DosageForm {
  id: string;
  name: string;
  description?: string;
}

export interface Unit {
  id: string;
  name: string;
  abbreviation?: string;
}

export interface PackagingType {
  id: string;
  name: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  address?: string;
  paymentTerms?: string;
  notes?: string;
  isActive: boolean;
}

export interface Medicine {
  id: string;
  name: string;
  genericName?: string;
  categoryId?: string;
  dosageFormId?: string;
  strength?: string;
  packSize?: string;
  manufacturer?: string;
  defaultUnitId?: string;
  defaultUnitPrice: number;
  reorderLevel: number;
  defaultSupplierId?: string;
  barcode?: string;
  description?: string;
  isActive: boolean;
}

export interface StockBatch {
  id: string;
  medicineId: string;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  unitPrice: number;
  supplierId?: string;
  purchaseDate: string;
  location?: string;
  notes?: string;
}

export interface StockMovement {
  id: string;
  batchId: string;
  medicineId: string;
  movementType: 'IN' | 'OUT' | 'ADJUSTMENT';
  quantity: number;
  referenceType?: string;
  referenceId?: string;
  notes?: string;
  createdBy?: string;
  createdAt: string;
}

export interface Patient {
  id: string;
  patientCode?: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  gender?: 'Male' | 'Female' | 'Other';
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
  isActive: boolean;
}

export interface Doctor {
  id: string;
  name: string;
  specialization?: string;
  phone?: string;
  email?: string;
  registrationNumber?: string;
  isActive: boolean;
}

export interface Dispense {
  id: string;
  dispenseNumber: string;
  patientId?: string;
  doctorId?: string;
  dispenseDate: string;
  totalQuantity: number;
  notes?: string;
  dispensedBy?: string;
  items: DispenseItem[];
}

export interface DispenseItem {
  id: string;
  dispenseId: string;
  medicineId: string;
  batchId?: string;
  quantity: number;
  unitId?: string;
  instructions?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  patientId?: string;
  invoiceDate: string;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  totalAmount: number;
  paidAmount: number;
  paymentStatus: 'Paid' | 'Unpaid' | 'Partial';
  paymentMethod?: string;
  notes?: string;
  createdBy?: string;
  items: InvoiceItem[];
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  medicineId: string;
  batchId?: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  taxAmount: number;
  discountAmount: number;
  lineTotal: number;
}

export interface Payment {
  id: string;
  invoiceId: string;
  paymentDate: string;
  amount: number;
  paymentMethod: string;
  notes?: string;
  receivedBy?: string;
}

export interface Alert {
  id: string;
  alertType: 'LOW_STOCK' | 'EXPIRY';
  severity: 'info' | 'warning' | 'critical';
  medicineId?: string;
  batchId?: string;
  message: string;
  isAcknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  createdAt: string;
}

export interface ClinicSettings {
  id: string;
  clinicName: string;
  address?: string;
  phone?: string;
  email?: string;
  taxId?: string;
  logoUrl?: string;
  invoiceFooter?: string;
  currency: string;
}

export interface TaxRule {
  id: string;
  name: string;
  taxRate: number;
  isDefault: boolean;
  isActive: boolean;
}

export interface User {
  id: string;
  fullName: string;
  role: 'Admin' | 'Pharmacist' | 'Cashier';
  isActive: boolean;
}
