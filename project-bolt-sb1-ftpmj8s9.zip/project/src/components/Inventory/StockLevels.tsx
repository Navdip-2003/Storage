import { useState, useEffect } from 'react';
import { AlertTriangle, Package } from 'lucide-react';
import { StorageService } from '../../lib/storage';

export function StockLevels() {
  const [stockData, setStockData] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'low' | 'expiring'>('all');

  useEffect(() => {
    const batches = StorageService.getStockBatches();
    const medicines = StorageService.getMedicines();
    const categories = StorageService.getCategories();
    const suppliers = StorageService.getSuppliers();

    const data = batches.map(batch => {
      const medicine = medicines.find(m => m.id === batch.medicineId);
      const category = categories.find(c => c.id === medicine?.categoryId);
      const supplier = suppliers.find(s => s.id === batch.supplierId);

      const expiryDate = new Date(batch.expiryDate);
      const today = new Date();
      const daysToExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      const isExpired = daysToExpiry < 0;
      const isExpiring = daysToExpiry >= 0 && daysToExpiry <= 90;
      const isLowStock = medicine && batch.quantity <= medicine.reorderLevel;

      return {
        ...batch,
        medicineName: medicine?.name || 'Unknown',
        categoryName: category?.name || '-',
        supplierName: supplier?.name || '-',
        daysToExpiry,
        isExpired,
        isExpiring,
        isLowStock,
      };
    });

    setStockData(data);
  }, []);

  const filteredData = stockData.filter(item => {
    if (filter === 'low') return item.isLowStock;
    if (filter === 'expiring') return item.isExpiring || item.isExpired;
    return true;
  });

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Stock Levels</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            All Stock
          </button>
          <button
            onClick={() => setFilter('low')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'low'
                ? 'bg-yellow-600 text-white'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            Low Stock
          </button>
          <button
            onClick={() => setFilter('expiring')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'expiring'
                ? 'bg-red-600 text-white'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            Expiring
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Medicine</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Batch No.</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Expiry Date</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Quantity</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Location</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Supplier</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                    <Package className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No stock data available</p>
                  </td>
                </tr>
              ) : (
                filteredData.map((item) => (
                  <tr
                    key={item.id}
                    className={`hover:bg-slate-50 ${
                      item.isExpired ? 'bg-red-50' : item.isLowStock ? 'bg-yellow-50' : ''
                    }`}
                  >
                    <td className="px-4 py-3 text-sm">
                      <div>
                        <p className="font-medium text-slate-800">{item.medicineName}</p>
                        <p className="text-xs text-slate-500">{item.categoryName}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">{item.batchNumber}</td>
                    <td className="px-4 py-3 text-sm">
                      <div>
                        <p className="text-slate-700">{new Date(item.expiryDate).toLocaleDateString()}</p>
                        <p className={`text-xs ${item.isExpired ? 'text-red-600' : item.isExpiring ? 'text-yellow-600' : 'text-slate-500'}`}>
                          {item.isExpired ? 'Expired' : `${item.daysToExpiry} days`}
                        </p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`font-semibold ${item.isLowStock ? 'text-yellow-700' : 'text-slate-700'}`}>
                        {item.quantity}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">{item.location || '-'}</td>
                    <td className="px-4 py-3 text-sm text-slate-600">{item.supplierName}</td>
                    <td className="px-4 py-3 text-sm">
                      <div className="flex flex-col gap-1">
                        {item.isExpired && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 text-xs font-medium rounded">
                            <AlertTriangle className="w-3 h-3" />
                            Expired
                          </span>
                        )}
                        {!item.isExpired && item.isExpiring && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-medium rounded">
                            <AlertTriangle className="w-3 h-3" />
                            Expiring Soon
                          </span>
                        )}
                        {item.isLowStock && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-medium rounded">
                            <Package className="w-3 h-3" />
                            Low Stock
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
