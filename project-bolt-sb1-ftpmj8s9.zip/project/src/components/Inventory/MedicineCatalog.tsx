import { useState, useEffect } from 'react';
import { Plus, CreditCard as Edit, Trash2, Search } from 'lucide-react';
import { StorageService } from '../../lib/storage';
import { Medicine } from '../../types';
import { MedicineForm } from './MedicineForm';

export function MedicineCatalog() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [filteredMedicines, setFilteredMedicines] = useState<Medicine[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);

  useEffect(() => {
    loadMedicines();
  }, []);

  useEffect(() => {
    const filtered = medicines.filter(m =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.genericName && m.genericName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (m.manufacturer && m.manufacturer.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    setFilteredMedicines(filtered);
  }, [searchTerm, medicines]);

  const loadMedicines = () => {
    const meds = StorageService.getMedicines();
    setMedicines(meds);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this medicine?')) {
      StorageService.deleteMedicine(id);
      loadMedicines();
    }
  };

  const handleEdit = (medicine: Medicine) => {
    setEditingMedicine(medicine);
    setShowForm(true);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingMedicine(null);
    loadMedicines();
  };

  const categories = StorageService.getCategories();
  const dosageForms = StorageService.getDosageForms();
  const units = StorageService.getUnits();

  const getCategoryName = (id?: string) => categories.find(c => c.id === id)?.name || '-';
  const getDosageFormName = (id?: string) => dosageForms.find(d => d.id === id)?.name || '-';
  const getUnitName = (id?: string) => units.find(u => u.id === id)?.name || '-';

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Medicine Catalog</h2>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Medicine
        </button>
      </div>

      <div className="mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search medicines..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Name</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Category</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Dosage Form</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Strength</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Unit</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Price</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Reorder Level</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                    No medicines found. Click "Add Medicine" to create one.
                  </td>
                </tr>
              ) : (
                filteredMedicines.map((medicine) => (
                  <tr key={medicine.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-sm">
                      <div>
                        <p className="font-medium text-slate-800">{medicine.name}</p>
                        {medicine.genericName && (
                          <p className="text-xs text-slate-500">{medicine.genericName}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      {getCategoryName(medicine.categoryId)}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      {getDosageFormName(medicine.dosageFormId)}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">{medicine.strength || '-'}</td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      {getUnitName(medicine.defaultUnitId)}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      ${medicine.defaultUnitPrice.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">{medicine.reorderLevel}</td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleEdit(medicine)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(medicine.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <MedicineForm
          medicine={editingMedicine}
          onClose={handleFormClose}
        />
      )}
    </div>
  );
}
