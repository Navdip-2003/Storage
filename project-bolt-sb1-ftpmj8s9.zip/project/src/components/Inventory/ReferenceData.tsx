import { useState } from 'react';
import { Plus, CreditCard as Edit, Trash2 } from 'lucide-react';
import { StorageService } from '../../lib/storage';

export function ReferenceData() {
  const [activeTab, setActiveTab] = useState<'categories' | 'dosageForms' | 'units' | 'packaging'>('categories');

  const tabs = [
    { id: 'categories' as const, label: 'Categories' },
    { id: 'dosageForms' as const, label: 'Dosage Forms' },
    { id: 'units' as const, label: 'Units' },
    { id: 'packaging' as const, label: 'Packaging Types' },
  ];

  const ReferenceTable = ({ type }: { type: typeof activeTab }) => {
    const [items, setItems] = useState(() => {
      switch (type) {
        case 'categories': return StorageService.getCategories();
        case 'dosageForms': return StorageService.getDosageForms();
        case 'units': return StorageService.getUnits();
        case 'packaging': return StorageService.getPackagingTypes();
      }
    });

    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({ name: '', description: '', abbreviation: '' });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      const newItem = { id: `${type}_${Date.now()}`, ...formData };

      switch (type) {
        case 'categories': StorageService.saveCategory(newItem); break;
        case 'dosageForms': StorageService.saveDosageForm(newItem); break;
        case 'units': StorageService.saveUnit(newItem); break;
        case 'packaging': StorageService.savePackagingType(newItem); break;
      }

      setFormData({ name: '', description: '', abbreviation: '' });
      setShowForm(false);

      switch (type) {
        case 'categories': setItems(StorageService.getCategories()); break;
        case 'dosageForms': setItems(StorageService.getDosageForms()); break;
        case 'units': setItems(StorageService.getUnits()); break;
        case 'packaging': setItems(StorageService.getPackagingTypes()); break;
      }
    };

    const handleDelete = (id: string) => {
      if (!confirm('Delete this item?')) return;

      switch (type) {
        case 'categories': StorageService.deleteCategory(id); setItems(StorageService.getCategories()); break;
        case 'dosageForms': StorageService.deleteDosageForm(id); setItems(StorageService.getDosageForms()); break;
        case 'units': StorageService.deleteUnit(id); setItems(StorageService.getUnits()); break;
        case 'packaging': StorageService.deletePackagingType(id); setItems(StorageService.getPackagingTypes()); break;
      }
    };

    return (
      <div>
        <div className="mb-4 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-slate-800">
            {tabs.find(t => t.id === type)?.label}
          </h3>
          <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
            <Plus className="w-4 h-4" />
            Add
          </button>
        </div>

        {showForm && (
          <div className="bg-slate-50 p-4 rounded-lg mb-4">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <input type="text" placeholder="Name *" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
              {type === 'units' && (
                <input type="text" placeholder="Abbreviation" value={formData.abbreviation} onChange={(e) => setFormData({ ...formData, abbreviation: e.target.value })} className="w-32 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
              )}
              {(type === 'categories' || type === 'dosageForms') && (
                <input type="text" placeholder="Description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
              )}
              <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                Add
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors">
                Cancel
              </button>
            </form>
          </div>
        )}

        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Name</th>
                {type === 'units' && <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Abbreviation</th>}
                {(type === 'categories' || type === 'dosageForms') && <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">Description</th>}
                <th className="px-4 py-3 text-right text-sm font-semibold text-slate-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {items.map((item: any) => (
                <tr key={item.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 text-sm text-slate-800">{item.name}</td>
                  {type === 'units' && <td className="px-4 py-3 text-sm text-slate-600">{item.abbreviation || '-'}</td>}
                  {(type === 'categories' || type === 'dosageForms') && <td className="px-4 py-3 text-sm text-slate-600">{item.description || '-'}</td>}
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(item.id)} className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Reference Data</h2>

      <div className="mb-4">
        <div className="flex gap-2 border-b border-slate-200">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 font-medium text-sm transition-colors border-b-2 ${
                activeTab === tab.id
                  ? 'text-blue-600 border-blue-600'
                  : 'text-slate-600 border-transparent hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <ReferenceTable type={activeTab} />
    </div>
  );
}
