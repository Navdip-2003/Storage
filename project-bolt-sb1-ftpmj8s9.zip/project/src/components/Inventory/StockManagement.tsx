import { useState, useEffect } from 'react';
import { StorageService } from '../../lib/storage';
import { Medicine, StockBatch } from '../../types';

export function StockManagement() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [suppliers, setSuppliers] = useState(StorageService.getSuppliers());
  const [formData, setFormData] = useState({
    medicineId: '',
    batchNumber: '',
    expiryDate: '',
    quantity: 0,
    unitPrice: 0,
    supplierId: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    location: '',
    notes: '',
  });

  useEffect(() => {
    setMedicines(StorageService.getMedicines().filter(m => m.isActive));
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.medicineId || !formData.batchNumber || !formData.expiryDate || formData.quantity <= 0) {
      alert('Please fill all required fields');
      return;
    }

    const expiryDate = new Date(formData.expiryDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (expiryDate < today) {
      alert('Expiry date cannot be in the past');
      return;
    }

    const batch: StockBatch = {
      id: `batch_${Date.now()}`,
      medicineId: formData.medicineId,
      batchNumber: formData.batchNumber,
      expiryDate: formData.expiryDate,
      quantity: Number(formData.quantity),
      unitPrice: Number(formData.unitPrice),
      supplierId: formData.supplierId || undefined,
      purchaseDate: formData.purchaseDate,
      location: formData.location || undefined,
      notes: formData.notes || undefined,
    };

    StorageService.saveStockBatch(batch);

    const movement = {
      id: `mov_${Date.now()}`,
      batchId: batch.id,
      medicineId: batch.medicineId,
      movementType: 'IN' as const,
      quantity: batch.quantity,
      referenceType: 'PURCHASE',
      notes: 'Stock received',
      createdAt: new Date().toISOString(),
    };
    StorageService.saveStockMovement(movement);

    alert('Stock added successfully!');
    setFormData({
      medicineId: '',
      batchNumber: '',
      expiryDate: '',
      quantity: 0,
      unitPrice: 0,
      supplierId: '',
      purchaseDate: new Date().toISOString().split('T')[0],
      location: '',
      notes: '',
    });
  };

  const selectedMedicine = medicines.find(m => m.id === formData.medicineId);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Add Stock / Receive Inventory</h2>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 max-w-3xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Medicine *
              </label>
              <select
                value={formData.medicineId}
                onChange={(e) => {
                  const med = medicines.find(m => m.id === e.target.value);
                  setFormData({
                    ...formData,
                    medicineId: e.target.value,
                    unitPrice: med?.defaultUnitPrice || 0,
                    supplierId: med?.defaultSupplierId || '',
                  });
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Medicine</option>
                {medicines.map((med) => (
                  <option key={med.id} value={med.id}>
                    {med.name} {med.strength ? `- ${med.strength}` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Batch Number *
              </label>
              <input
                type="text"
                value={formData.batchNumber}
                onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Expiry Date *
              </label>
              <input
                type="date"
                value={formData.expiryDate}
                onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Quantity *
              </label>
              <input
                type="number"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                min="1"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Unit Price *
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.unitPrice}
                onChange={(e) => setFormData({ ...formData, unitPrice: parseFloat(e.target.value) })}
                min="0"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Supplier</label>
              <select
                value={formData.supplierId}
                onChange={(e) => setFormData({ ...formData, supplierId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Supplier</option>
                {suppliers.filter(s => s.isActive).map((supplier) => (
                  <option key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Purchase Date
              </label>
              <input
                type="date"
                value={formData.purchaseDate}
                onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                max={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g., Shelf A-1"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {selectedMedicine && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Selected Medicine Details</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-blue-700">Category:</span>{' '}
                  <span className="text-blue-900">
                    {StorageService.getCategories().find(c => c.id === selectedMedicine.categoryId)?.name || '-'}
                  </span>
                </div>
                <div>
                  <span className="text-blue-700">Reorder Level:</span>{' '}
                  <span className="text-blue-900">{selectedMedicine.reorderLevel}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
            >
              Add Stock
            </button>
            <button
              type="button"
              onClick={() => {
                setFormData({
                  medicineId: '',
                  batchNumber: '',
                  expiryDate: '',
                  quantity: 0,
                  unitPrice: 0,
                  supplierId: '',
                  purchaseDate: new Date().toISOString().split('T')[0],
                  location: '',
                  notes: '',
                });
              }}
              className="px-6 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors font-medium"
            >
              Clear
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
