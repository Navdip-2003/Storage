interface SubNavProps {
  items: { id: string; label: string }[];
  activeItem: string;
  onNavigate: (itemId: string) => void;
}

export function SubNav({ items, activeItem, onNavigate }: SubNavProps) {
  return (
    <div className="bg-white border-b border-slate-200">
      <nav className="px-6">
        <ul className="flex gap-1">
          {items.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => onNavigate(item.id)}
                className={`px-4 py-3 font-medium text-sm transition-colors border-b-2 ${
                  activeItem === item.id
                    ? 'text-blue-600 border-blue-600'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
