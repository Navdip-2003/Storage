import { Bell, User } from 'lucide-react';
import { StorageService } from '../../lib/storage';
import { useEffect, useState } from 'react';

export function Header() {
  const [clinicName, setClinicName] = useState('Medical Clinic');
  const [unreadAlerts, setUnreadAlerts] = useState(0);

  useEffect(() => {
    const settings = StorageService.getClinicSettings();
    if (settings) {
      setClinicName(settings.clinicName);
    }

    const alerts = StorageService.getAlerts().filter(a => !a.isAcknowledged);
    setUnreadAlerts(alerts.length);
  }, []);

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{clinicName}</h2>
          <p className="text-sm text-slate-500">Inventory & Billing Management</p>
        </div>

        <div className="flex items-center gap-4">
          <button className="relative p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <Bell className="w-5 h-5 text-slate-600" />
            {unreadAlerts > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {unreadAlerts > 9 ? '9+' : unreadAlerts}
              </span>
            )}
          </button>

          <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
            <div className="text-right">
              <p className="text-sm font-medium text-slate-700">Admin User</p>
              <p className="text-xs text-slate-500">Administrator</p>
            </div>
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
