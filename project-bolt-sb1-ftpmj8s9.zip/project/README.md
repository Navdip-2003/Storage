# Medical Inventory & Billing System

A comprehensive web application for clinics and pharmacies to manage medical inventory, dispensing, and billing operations.

## Features

### Dashboard
- Real-time KPIs: Total stock value, today's sales, low-stock count, expiring batches
- Sales trends (last 7 days bar chart)
- Stock value by category visualization
- Quick action buttons for common tasks

### Inventory Management
- **Medicine Catalog**: Complete medicine database with categories, dosage forms, pricing
- **Add Stock**: Receive inventory with batch tracking, expiry dates, and locations
- **Stock Levels**: Real-time view of all batches with expiry and low-stock highlighting
- **Suppliers**: Manage supplier contacts and payment terms
- **Reference Data**: Configure categories, dosage forms, units, and packaging types

### Dispensing
- Medicine dispensing with FEFO (First Expiry, First Out) batch selection
- Patient and doctor tracking
- Dispense history and records

### Billing
- Create invoices with line items, taxes, and discounts
- Invoice list with payment status tracking
- Support for multiple payment methods
- Partial payment handling

### Reports
- Inventory reports (valuation, movement, expiry)
- Sales analytics (daily/monthly, top medicines, by patient)
- Audit logs for compliance

### Alerts
- Automatic low-stock alerts based on reorder levels
- Expiry warnings (90-day advance notice)
- Critical alerts for expired items
- Acknowledgment system

### Settings
- Clinic profile configuration
- Tax and pricing rules
- User and role management
- Invoice customization

## Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Storage**: LocalStorage (for demo purposes)
- **Build Tool**: Vite

## Data Storage

All data is stored in browser localStorage for demonstration purposes. The system includes:
- Automatic initialization of reference data
- Sample medicines, suppliers, and transactions
- Persistent data across browser sessions

## Key Features

- **Responsive Design**: Works on desktop and tablet devices
- **Color-Coded UI**: Red (expired/critical), Yellow (warning/low stock), Green (normal)
- **Real-time Updates**: Stock levels and alerts update automatically
- **CRUD Operations**: Full create, read, update, delete for all entities
- **Data Validation**: Input validation and error handling throughout
- **Professional Layout**: Collapsible sidebar, header with notifications, multi-level navigation

## Sample Data

The application comes pre-loaded with:
- 5 sample medicines across different categories
- 5 stock batches with varying expiry dates
- 2 suppliers with contact details
- 2 patients and 1 doctor
- 1 sample invoice
- Default categories, dosage forms, and units

## Getting Started

The application is ready to use. Navigate through the sidebar to explore different modules:

1. **Dashboard** - Overview of your inventory and sales
2. **Inventory** - Manage medicines and stock
3. **Dispensing** - Dispense medicines to patients
4. **Billing** - Create and manage invoices
5. **Reports** - Generate business reports
6. **Alerts** - View and manage system alerts
7. **Settings** - Configure clinic and system settings
