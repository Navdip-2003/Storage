import { InventoryItem, Supplier, StockAlert, Location, PatientBill, POSTransaction } from '../types';

export const mockInventoryItems: InventoryItem[] = [
  {
    id: '1',
    name: 'Acetaminophen 500mg',
    type: 'drug',
    category: 'Pain Relief',
    sku: 'ACT-500-001',
    currentStock: 250,
    reorderLevel: 50,
    unit: 'tablets',
    cost: 0.15,
    sellingPrice: 0.25,
    location: 'Main Clinic',
    supplier: 'PharmaCorp',
    isActive: true,
    createdAt: '2024-01-15',
    batches: [
      {
        id: 'b1',
        batchNumber: 'ACT-2024-001',
        expiryDate: '2025-12-31',
        manufactureDate: '2024-01-01',
        quantity: 500,
        remainingQuantity: 250,
        cost: 0.15,
        supplier: 'PharmaCorp',
        status: 'active'
      }
    ]
  },
  {
    id: '2',
    name: 'Disposable Syringes 5ml',
    type: 'consumable',
    category: 'Medical Supplies',
    sku: 'SYR-5ML-001',
    currentStock: 15,
    reorderLevel: 100,
    unit: 'pieces',
    cost: 0.50,
    sellingPrice: 0.75,
    location: 'Main Clinic',
    supplier: 'MedSupply Inc',
    isActive: true,
    createdAt: '2024-01-10',
    batches: [
      {
        id: 'b2',
        batchNumber: 'SYR-2024-002',
        expiryDate: '2026-06-30',
        manufactureDate: '2024-01-05',
        quantity: 1000,
        remainingQuantity: 15,
        cost: 0.50,
        supplier: 'MedSupply Inc',
        status: 'active'
      }
    ]
  },
  {
    id: '3',
    name: 'Blood Pressure Monitor',
    type: 'device',
    category: 'Diagnostic Equipment',
    sku: 'BPM-DIG-001',
    currentStock: 8,
    reorderLevel: 3,
    unit: 'units',
    cost: 150.00,
    sellingPrice: 200.00,
    location: 'Main Clinic',
    supplier: 'MedTech Solutions',
    isActive: true,
    createdAt: '2024-01-05',
    batches: [
      {
        id: 'b3',
        batchNumber: 'BPM-2024-001',
        expiryDate: '2029-01-01',
        manufactureDate: '2024-01-01',
        quantity: 10,
        remainingQuantity: 8,
        cost: 150.00,
        supplier: 'MedTech Solutions',
        status: 'active'
      }
    ]
  },
  {
    id: '4',
    name: 'Ibuprofen 400mg',
    type: 'drug',
    category: 'Pain Relief',
    sku: 'IBU-400-001',
    currentStock: 0,
    reorderLevel: 25,
    unit: 'tablets',
    cost: 0.12,
    sellingPrice: 0.20,
    location: 'Branch Clinic',
    supplier: 'PharmaCorp',
    isActive: true,
    createdAt: '2024-01-08',
    batches: []
  },
  {
    id: '5',
    name: 'Surgical Gloves (Latex)',
    type: 'consumable',
    category: 'PPE',
    sku: 'GLV-LAT-001',
    currentStock: 45,
    reorderLevel: 200,
    unit: 'pairs',
    cost: 0.25,
    sellingPrice: 0.40,
    location: 'Main Clinic',
    supplier: 'SafetyFirst Medical',
    isActive: true,
    createdAt: '2024-01-12',
    batches: [
      {
        id: 'b5',
        batchNumber: 'GLV-2024-003',
        expiryDate: '2025-03-15',
        manufactureDate: '2024-01-10',
        quantity: 1000,
        remainingQuantity: 45,
        cost: 0.25,
        supplier: 'SafetyFirst Medical',
        status: 'active'
      }
    ]
  }
];

export const mockSuppliers: Supplier[] = [
  {
    id: '1',
    name: 'PharmaCorp',
    contact: 'John Smith',
    email: 'orders@pharmacorp.com',
    phone: '+1-555-0101',
    address: '123 Medical District, Healthcare City, HC 12345',
    leadTime: 5,
    rating: 4.8,
    isActive: true
  },
  {
    id: '2',
    name: 'MedSupply Inc',
    contact: 'Sarah Johnson',
    email: 'procurement@medsupply.com',
    phone: '+1-555-0202',
    address: '456 Supply Avenue, Medical Hub, MH 67890',
    leadTime: 3,
    rating: 4.6,
    isActive: true
  },
  {
    id: '3',
    name: 'MedTech Solutions',
    contact: 'Dr. Mike Chen',
    email: 'sales@medtechsol.com',
    phone: '+1-555-0303',
    address: '789 Innovation Blvd, Tech Valley, TV 13579',
    leadTime: 7,
    rating: 4.9,
    isActive: true
  },
  {
    id: '4',
    name: 'SafetyFirst Medical',
    contact: 'Lisa Brown',
    email: 'orders@safetyfirstmed.com',
    phone: '+1-555-0404',
    address: '321 Safety Street, Protection Park, PP 24680',
    leadTime: 4,
    rating: 4.5,
    isActive: true
  }
];

export const mockStockAlerts: StockAlert[] = [
  {
    id: '1',
    itemId: '2',
    itemName: 'Disposable Syringes 5ml',
    type: 'low_stock',
    message: 'Stock level is below reorder point (15/100)',
    severity: 'high',
    location: 'Main Clinic',
    createdAt: '2024-01-20T10:30:00Z',
    isRead: false
  },
  {
    id: '2',
    itemId: '4',
    itemName: 'Ibuprofen 400mg',
    type: 'out_of_stock',
    message: 'Item is completely out of stock',
    severity: 'high',
    location: 'Branch Clinic',
    createdAt: '2024-01-20T09:15:00Z',
    isRead: false
  },
  {
    id: '3',
    itemId: '5',
    itemName: 'Surgical Gloves (Latex)',
    type: 'expiring_soon',
    message: 'Batch GLV-2024-003 expires in 2 months',
    severity: 'medium',
    location: 'Main Clinic',
    createdAt: '2024-01-19T14:45:00Z',
    isRead: true
  }
];

export const mockLocations: Location[] = [
  {
    id: '1',
    name: 'Main Clinic',
    address: '100 Healthcare Boulevard, Medical City, MC 11111',
    type: 'main_clinic',
    manager: 'Dr. Sarah Johnson',
    isActive: true
  },
  {
    id: '2',
    name: 'Branch Clinic',
    address: '200 Wellness Street, Health Town, HT 22222',
    type: 'branch',
    manager: 'Dr. Michael Brown',
    isActive: true
  },
  {
    id: '3',
    name: 'Central Pharmacy',
    address: '300 Medication Ave, Pharma District, PD 33333',
    type: 'pharmacy',
    manager: 'PharmD Lisa White',
    isActive: true
  }
];

export const mockPatientBills: PatientBill[] = [
  {
    id: '1',
    patientId: 'P001',
    patientName: 'John Doe',
    items: [
      {
        itemId: '1',
        itemName: 'Acetaminophen 500mg',
        quantity: 20,
        unitPrice: 0.25,
        totalPrice: 5.00,
        batchId: 'b1'
      },
      {
        itemId: '2',
        itemName: 'Disposable Syringes 5ml',
        quantity: 2,
        unitPrice: 0.75,
        totalPrice: 1.50,
        batchId: 'b2'
      }
    ],
    totalAmount: 6.50,
    status: 'paid',
    createdAt: '2024-01-20T11:30:00Z',
    location: 'Main Clinic'
  }
];

export const mockPOSTransactions: POSTransaction[] = [
  {
    id: '1',
    items: [
      {
        itemId: '1',
        itemName: 'Acetaminophen 500mg',
        quantity: 10,
        unitPrice: 0.25,
        totalPrice: 2.50,
        batchId: 'b1'
      }
    ],
    paymentMethod: 'card',
    totalAmount: 2.50,
    customerName: 'Walk-in Customer',
    location: 'Main Clinic',
    createdAt: '2024-01-20T15:45:00Z',
    status: 'completed'
  }
];