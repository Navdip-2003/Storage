import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import ForgotPasswordForm from './components/auth/ForgotPasswordForm';
import Dashboard from './components/Dashboard';

function AuthApp() {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    switch (authMode) {
      case 'register':
        return (
          <RegisterForm onSwitchToLogin={() => setAuthMode('login')} />
        );
      case 'forgot':
        return (
          <ForgotPasswordForm onSwitchToLogin={() => setAuthMode('login')} />
        );
      default:
        return (
          <LoginForm
            onSwitchToRegister={() => setAuthMode('register')}
            onSwitchToForgotPassword={() => setAuthMode('forgot')}
          />
        );
    }
  }

  return <Dashboard />;
}

function App() {
  return (
    <AuthProvider>
      <AuthApp />
    </AuthProvider>
  );
}

export default App;