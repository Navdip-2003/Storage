export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'staff' | 'pharmacist';
  location: string;
  avatar?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  type: 'drug' | 'consumable' | 'device';
  category: string;
  sku: string;
  currentStock: number;
  reorderLevel: number;
  unit: string;
  cost: number;
  sellingPrice: number;
  location: string;
  batches: Batch[];
  supplier: string;
  isActive: boolean;
  createdAt: string;
}

export interface Batch {
  id: string;
  batchNumber: string;
  expiryDate: string;
  manufactureDate: string;
  quantity: number;
  remainingQuantity: number;
  cost: number;
  supplier: string;
  status: 'active' | 'expired' | 'recalled';
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone: string;
  address: string;
  leadTime: number;
  rating: number;
  isActive: boolean;
}

export interface StockAlert {
  id: string;
  itemId: string;
  itemName: string;
  type: 'low_stock' | 'expired' | 'expiring_soon' | 'out_of_stock';
  message: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  createdAt: string;
  isRead: boolean;
}

export interface PatientBill {
  id: string;
  patientId: string;
  patientName: string;
  items: BilledItem[];
  totalAmount: number;
  status: 'pending' | 'paid' | 'cancelled';
  createdAt: string;
  location: string;
}

export interface BilledItem {
  itemId: string;
  itemName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  batchId: string;
}

export interface Location {
  id: string;
  name: string;
  address: string;
  type: 'main_clinic' | 'branch' | 'pharmacy' | 'warehouse';
  manager: string;
  isActive: boolean;
}

export interface POSTransaction {
  id: string;
  items: BilledItem[];
  paymentMethod: 'cash' | 'card' | 'insurance';
  totalAmount: number;
  customerId?: string;
  customerName?: string;
  location: string;
  createdAt: string;
  status: 'completed' | 'refunded';
}