import React, { useState } from 'react';
import Sidebar from './layout/Sidebar';
import Header from './layout/Header';
import DashboardOverview from './dashboard/DashboardOverview';
import InventoryList from './inventory/InventoryList';
import SuppliersList from './suppliers/SuppliersList';
import StockAlerts from './alerts/StockAlerts';
import PatientBilling from './billing/PatientBilling';
import POSSystem from './pos/POSSystem';
import LocationsList from './locations/LocationsList';
import ProcurementSystem from './procurement/ProcurementSystem';
import SettingsPanel from './settings/SettingsPanel';

const Dashboard: React.FC = () => {
  const [currentView, setCurrentView] = useState('dashboard');

  const getViewTitle = () => {
    switch (currentView) {
      case 'dashboard': return 'Dashboard Overview';
      case 'inventory': return 'Inventory Management';
      case 'suppliers': return 'Supplier Management';
      case 'alerts': return 'Stock Alerts';
      case 'billing': return 'Patient Billing';
      case 'pos': return 'Point of Sale';
      case 'locations': return 'Location Management';
      case 'procurement': return 'Procurement System';
      case 'settings': return 'System Settings';
      default: return 'Dashboard';
    }
  };

  const getViewSubtitle = () => {
    switch (currentView) {
      case 'dashboard': return 'Monitor your medical inventory at a glance';
      case 'inventory': return 'Track drugs, consumables, and devices across all locations';
      case 'suppliers': return 'Manage vendor relationships and procurement';
      case 'alerts': return 'Critical notifications for stock levels and expiries';
      case 'billing': return 'Integrated billing with automatic inventory deduction';
      case 'pos': return 'Retail sales with real-time inventory updates';
      case 'locations': return 'Multi-location inventory synchronization';
      case 'procurement': return 'Automated ordering and purchase management';
      case 'settings': return 'Configure system preferences and user management';
      default: return '';
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardOverview />;
      case 'inventory': return <InventoryList />;
      case 'suppliers': return <SuppliersList />;
      case 'alerts': return <StockAlerts />;
      case 'billing': return <PatientBilling />;
      case 'pos': return <POSSystem />;
      case 'locations': return <LocationsList />;
      case 'procurement': return <ProcurementSystem />;
      case 'settings': return <SettingsPanel />;
      default: return <DashboardOverview />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={getViewTitle()} subtitle={getViewSubtitle()} />
        <main className="flex-1 overflow-auto p-6">
          {renderCurrentView()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;