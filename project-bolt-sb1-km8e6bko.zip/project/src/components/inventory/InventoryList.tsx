import React, { useState } from 'react';
import { Plus, Search, Filter, Package, AlertTriangle, Calendar, Edit, Trash2 } from 'lucide-react';
import { mockInventoryItems } from '../../data/mockData';
import { InventoryItem } from '../../types';
import AddInventoryModal from './AddInventoryModal';
import EditInventoryModal from './EditInventoryModal';

const InventoryList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const filteredItems = mockInventoryItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterType === 'all' || item.type === filterType;
    
    return matchesSearch && matchesFilter;
  });

  const getStockStatus = (item: InventoryItem) => {
    if (item.currentStock === 0) return { status: 'out', color: 'red', text: 'Out of Stock' };
    if (item.currentStock <= item.reorderLevel) return { status: 'low', color: 'yellow', text: 'Low Stock' };
    return { status: 'good', color: 'green', text: 'In Stock' };
  };

  const getExpiryStatus = (item: InventoryItem) => {
    if (item.batches.length === 0) return { status: 'none', color: 'gray', text: 'No Batches' };
    
    const nearestExpiry = item.batches.reduce((nearest, batch) => {
      return new Date(batch.expiryDate) < new Date(nearest.expiryDate) ? batch : nearest;
    }, item.batches[0]);

    const daysToExpiry = Math.ceil((new Date(nearestExpiry.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
    
    if (daysToExpiry < 0) return { status: 'expired', color: 'red', text: 'Expired' };
    if (daysToExpiry <= 30) return { status: 'expiring', color: 'yellow', text: `${daysToExpiry} days` };
    return { status: 'good', color: 'green', text: `${daysToExpiry} days` };
  };

  const handleEdit = (item: InventoryItem) => {
    setSelectedItem(item);
    setShowEditModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search inventory items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-80 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Types</option>
            <option value="drug">Drugs</option>
            <option value="consumable">Consumables</option>
            <option value="device">Devices</option>
          </select>

          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Filter className="w-4 h-4" />
            More Filters
          </button>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add New Item
        </button>
      </div>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredItems.map((item) => {
          const stockStatus = getStockStatus(item);
          const expiryStatus = getExpiryStatus(item);

          return (
            <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${
                    item.type === 'drug' ? 'bg-blue-50 text-blue-600' :
                    item.type === 'consumable' ? 'bg-green-50 text-green-600' :
                    'bg-purple-50 text-purple-600'
                  }`}>
                    <Package className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{item.name}</h3>
                    <p className="text-sm text-gray-600">{item.category}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleEdit(item)}
                    className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-1 text-gray-400 hover:text-red-600 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">SKU:</span>
                  <span className="text-sm font-medium">{item.sku}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Current Stock:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{item.currentStock} {item.unit}</span>
                    <span className={`w-2 h-2 rounded-full ${
                      stockStatus.color === 'red' ? 'bg-red-500' :
                      stockStatus.color === 'yellow' ? 'bg-yellow-500' : 'bg-green-500'
                    }`} />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Reorder Level:</span>
                  <span className="text-sm font-medium">{item.reorderLevel} {item.unit}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Location:</span>
                  <span className="text-sm font-medium">{item.location}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Unit Cost:</span>
                  <span className="text-sm font-medium">${item.cost.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    stockStatus.color === 'red' ? 'bg-red-100 text-red-800' :
                    stockStatus.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' : 
                    'bg-green-100 text-green-800'
                  }`}>
                    {stockStatus.text}
                  </span>

                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    expiryStatus.color === 'red' ? 'bg-red-100 text-red-800' :
                    expiryStatus.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' : 
                    expiryStatus.color === 'green' ? 'bg-green-100 text-green-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    <Calendar className="w-3 h-3 mr-1" />
                    {expiryStatus.text}
                  </span>
                </div>

                {item.currentStock <= item.reorderLevel && (
                  <div className="flex items-center gap-1 text-xs text-orange-600">
                    <AlertTriangle className="w-3 h-3" />
                    Reorder needed
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No inventory items found</p>
          <p className="text-sm text-gray-500">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Modals */}
      {showAddModal && (
        <AddInventoryModal
          onClose={() => setShowAddModal(false)}
          onSave={(item) => {
            console.log('Adding new item:', item);
            setShowAddModal(false);
          }}
        />
      )}

      {showEditModal && selectedItem && (
        <EditInventoryModal
          item={selectedItem}
          onClose={() => {
            setShowEditModal(false);
            setSelectedItem(null);
          }}
          onSave={(item) => {
            console.log('Updating item:', item);
            setShowEditModal(false);
            setSelectedItem(null);
          }}
        />
      )}
    </div>
  );
};

export default InventoryList;