import React, { useState } from 'react';
import { Plus, MapPin, Users, Building, Edit, Trash2, ArrowUpDown } from 'lucide-react';
import { mockLocations } from '../../data/mockData';
import { Location } from '../../types';

const LocationsList: React.FC = () => {
  const [locations] = useState<Location[]>(mockLocations);

  const getLocationTypeConfig = (type: string) => {
    switch (type) {
      case 'main_clinic':
        return {
          label: 'Main Clinic',
          color: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: 'bg-blue-100 text-blue-600'
        };
      case 'branch':
        return {
          label: 'Branch Clinic',
          color: 'bg-green-50 text-green-700 border-green-200',
          icon: 'bg-green-100 text-green-600'
        };
      case 'pharmacy':
        return {
          label: 'Pharmacy',
          color: 'bg-purple-50 text-purple-700 border-purple-200',
          icon: 'bg-purple-100 text-purple-600'
        };
      case 'warehouse':
        return {
          label: 'Warehouse',
          color: 'bg-orange-50 text-orange-700 border-orange-200',
          icon: 'bg-orange-100 text-orange-600'
        };
      default:
        return {
          label: 'Unknown',
          color: 'bg-gray-50 text-gray-700 border-gray-200',
          icon: 'bg-gray-100 text-gray-600'
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Location Management</h2>
          <p className="text-gray-600">Manage inventory across multiple clinic locations</p>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <ArrowUpDown className="w-4 h-4" />
            Transfer Stock
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Plus className="w-4 h-4" />
            Add Location
          </button>
        </div>
      </div>

      {/* Locations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {locations.map((location) => {
          const typeConfig = getLocationTypeConfig(location.type);

          return (
            <div key={location.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${typeConfig.icon}`}>
                      <Building className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{location.name}</h3>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${typeConfig.color}`}>
                        {typeConfig.label}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-gray-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                    <span className="text-sm text-gray-600">{location.address}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-600">Manager: {location.manager}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between mb-3">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      location.isActive 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {location.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="bg-blue-50 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-blue-600">24</div>
                      <div className="text-blue-700">Items</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-3 text-center">
                      <div className="text-2xl font-bold text-green-600">$8.2k</div>
                      <div className="text-green-700">Value</div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button className="flex-1 bg-blue-50 text-blue-700 py-2 px-3 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium">
                    View Inventory
                  </button>
                  <button className="flex-1 bg-green-50 text-green-700 py-2 px-3 rounded-lg hover:bg-green-100 transition-colors text-sm font-medium">
                    Transfer Stock
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stock Transfer Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Stock Transfers</h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <ArrowUpDown className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Acetaminophen 500mg</p>
                <p className="text-sm text-gray-600">100 tablets transferred</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">Main Clinic → Branch Clinic</p>
              <p className="text-sm text-gray-500">2 hours ago</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <ArrowUpDown className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Surgical Gloves</p>
                <p className="text-sm text-gray-600">50 pairs transferred</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">Central Pharmacy → Main Clinic</p>
              <p className="text-sm text-gray-500">1 day ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationsList;