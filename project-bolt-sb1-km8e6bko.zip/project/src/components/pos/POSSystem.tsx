import React, { useState } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, CreditCard, DollarSign, Receipt, Search } from 'lucide-react';
import { mockInventoryItems } from '../../data/mockData';
import { BilledItem, POSTransaction } from '../../types';

const POSSystem: React.FC = () => {
  const [cart, setCart] = useState<BilledItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'insurance'>('cash');
  const [showPayment, setShowPayment] = useState(false);

  const availableItems = mockInventoryItems.filter(item => 
    item.currentStock > 0 && 
    (item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     item.sku.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalAmount = cart.reduce((sum, item) => sum + item.totalPrice, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const addToCart = (itemId: string) => {
    const inventoryItem = mockInventoryItems.find(item => item.id === itemId);
    if (!inventoryItem || inventoryItem.currentStock === 0) return;

    const existingItemIndex = cart.findIndex(item => item.itemId === itemId);
    
    if (existingItemIndex >= 0) {
      setCart(prev => prev.map((item, index) => 
        index === existingItemIndex 
          ? {
              ...item,
              quantity: item.quantity + 1,
              totalPrice: (item.quantity + 1) * item.unitPrice
            }
          : item
      ));
    } else {
      const newCartItem: BilledItem = {
        itemId: inventoryItem.id,
        itemName: inventoryItem.name,
        quantity: 1,
        unitPrice: inventoryItem.sellingPrice,
        totalPrice: inventoryItem.sellingPrice,
        batchId: inventoryItem.batches.length > 0 ? inventoryItem.batches[0].id : ''
      };
      setCart(prev => [...prev, newCartItem]);
    }
  };

  const updateQuantity = (index: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      setCart(prev => prev.filter((_, i) => i !== index));
      return;
    }

    setCart(prev => prev.map((item, i) => 
      i === index 
        ? {
            ...item,
            quantity: newQuantity,
            totalPrice: newQuantity * item.unitPrice
          }
        : item
    ));
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const clearCart = () => {
    setCart([]);
    setCustomerName('');
    setShowPayment(false);
  };

  const processPayment = () => {
    const transaction: Partial<POSTransaction> = {
      items: cart,
      paymentMethod: paymentMethod,
      totalAmount: totalAmount,
      customerName: customerName || 'Walk-in Customer',
      location: 'Main Clinic',
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    console.log('Processing transaction:', transaction);
    alert('Payment processed successfully!');
    clearCart();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Product Selection */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 xl:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
            {availableItems.map((item) => (
              <div
                key={item.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 cursor-pointer transition-colors"
                onClick={() => addToCart(item.id)}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-3 h-3 rounded-full ${
                    item.type === 'drug' ? 'bg-blue-500' :
                    item.type === 'consumable' ? 'bg-green-500' : 'bg-purple-500'
                  }`} />
                  <h3 className="font-medium text-gray-900 text-sm">{item.name}</h3>
                </div>
                
                <p className="text-xs text-gray-600 mb-2">{item.category}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-blue-600">
                    ${item.sellingPrice.toFixed(2)}
                  </span>
                  <span className="text-xs text-gray-500">
                    Stock: {item.currentStock}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {availableItems.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <ShoppingCart className="w-12 h-12 mx-auto mb-4" />
              <p>No products found</p>
            </div>
          )}
        </div>
      </div>

      {/* Shopping Cart */}
      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                Cart ({itemCount} items)
              </h3>
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-red-600 hover:text-red-800 text-sm font-medium"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {cart.map((item, index) => (
              <div key={index} className="p-4 border-b border-gray-100 last:border-b-0">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-gray-900 text-sm">{item.itemName}</h4>
                  <button
                    onClick={() => removeFromCart(index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQuantity(index, item.quantity - 1)}
                      className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-medium">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(index, item.quantity + 1)}
                      className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm text-gray-600">${item.unitPrice.toFixed(2)} each</div>
                    <div className="font-bold text-blue-600">${item.totalPrice.toFixed(2)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {cart.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <ShoppingCart className="w-12 h-12 mx-auto mb-4" />
              <p>Your cart is empty</p>
              <p className="text-sm">Add items from the product list</p>
            </div>
          )}

          {cart.length > 0 && (
            <div className="p-6 border-t border-gray-200 bg-gray-50">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Customer Name (Optional)
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Walk-in Customer"
                  />
                </div>

                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total:</span>
                  <span className="text-blue-600">${totalAmount.toFixed(2)}</span>
                </div>

                {!showPayment ? (
                  <button
                    onClick={() => setShowPayment(true)}
                    className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center gap-2"
                  >
                    <CreditCard className="w-5 h-5" />
                    Proceed to Payment
                  </button>
                ) : (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Payment Method
                      </label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="cash">Cash</option>
                        <option value="card">Card</option>
                        <option value="insurance">Insurance</option>
                      </select>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowPayment(false)}
                        className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                      >
                        Back
                      </button>
                      <button
                        onClick={processPayment}
                        className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                      >
                        <Receipt className="w-4 h-4" />
                        Pay
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default POSSystem;