import React from 'react';
import { 
  Package, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign,
  Users,
  MapPin
} from 'lucide-react';
import { mockInventoryItems, mockStockAlerts } from '../../data/mockData';

const DashboardOverview: React.FC = () => {
  const totalItems = mockInventoryItems.length;
  const lowStockItems = mockInventoryItems.filter(item => item.currentStock <= item.reorderLevel).length;
  const outOfStockItems = mockInventoryItems.filter(item => item.currentStock === 0).length;
  const totalValue = mockInventoryItems.reduce((sum, item) => sum + (item.currentStock * item.cost), 0);
  const criticalAlerts = mockStockAlerts.filter(alert => alert.severity === 'high' && !alert.isRead).length;

  const stats = [
    {
      name: 'Total Items',
      value: totalItems.toString(),
      change: '+12%',
      changeType: 'increase' as const,
      icon: Package,
      color: 'blue'
    },
    {
      name: 'Low Stock Items',
      value: lowStockItems.toString(),
      change: '-8%',
      changeType: 'decrease' as const,
      icon: AlertTriangle,
      color: 'yellow'
    },
    {
      name: 'Out of Stock',
      value: outOfStockItems.toString(),
      change: '+2',
      changeType: 'increase' as const,
      icon: Package,
      color: 'red'
    },
    {
      name: 'Inventory Value',
      value: `$${totalValue.toLocaleString()}`,
      change: '+15%',
      changeType: 'increase' as const,
      icon: DollarSign,
      color: 'green'
    }
  ];

  const recentActivity = [
    { id: 1, action: 'Stock Received', item: 'Acetaminophen 500mg', quantity: 250, time: '2 hours ago' },
    { id: 2, action: 'Low Stock Alert', item: 'Disposable Syringes 5ml', quantity: 15, time: '4 hours ago' },
    { id: 3, action: 'Patient Billing', item: 'Blood Pressure Monitor', quantity: 1, time: '6 hours ago' },
    { id: 4, action: 'Stock Transfer', item: 'Surgical Gloves', quantity: 100, time: '1 day ago' }
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const colorClasses = {
            blue: 'bg-blue-50 text-blue-600 border-blue-200',
            yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200',
            red: 'bg-red-50 text-red-600 border-red-200',
            green: 'bg-green-50 text-green-600 border-green-200'
          };

          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      stat.changeType === 'increase' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {stat.change}
                    </span>
                    <span className="text-xs text-gray-500 ml-2">vs last month</span>
                  </div>
                </div>
                <div className={`p-3 rounded-lg border ${colorClasses[stat.color]}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Critical Alerts */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Critical Alerts</h3>
              <p className="text-sm text-gray-600 mt-1">{criticalAlerts} items need immediate attention</p>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {mockStockAlerts.slice(0, 5).map((alert) => (
                  <div key={alert.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        alert.severity === 'high' ? 'bg-red-500' :
                        alert.severity === 'medium' ? 'bg-yellow-500' : 'bg-gray-400'
                      }`} />
                      <div>
                        <p className="font-medium text-gray-900">{alert.itemName}</p>
                        <p className="text-sm text-gray-600">{alert.message}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">{alert.location}</p>
                      <p className="text-xs text-gray-400">{new Date(alert.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                      <p className="text-sm text-gray-600">{activity.item}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                    {activity.quantity && (
                      <span className="text-sm font-medium text-gray-900">
                        {activity.quantity}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-center">
            <Package className="w-6 h-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Add Item</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-center">
            <Users className="w-6 h-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">New Supplier</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-center">
            <TrendingUp className="w-6 h-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Generate Report</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors text-center">
            <MapPin className="w-6 h-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Stock Transfer</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;