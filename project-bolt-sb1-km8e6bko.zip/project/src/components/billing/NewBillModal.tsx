import React, { useState } from 'react';
import { X, Plus, Trash2, User, FileText, Calculator } from 'lucide-react';
import { PatientBill, BilledItem } from '../../types';
import { mockInventoryItems } from '../../data/mockData';

interface NewBillModalProps {
  onClose: () => void;
  onSave: (bill: Partial<PatientBill>) => void;
}

const NewBillModal: React.FC<NewBillModalProps> = ({ onClose, onSave }) => {
  const [formData, setFormData] = useState({
    patientId: '',
    patientName: '',
    location: 'Main Clinic'
  });

  const [billedItems, setBilledItems] = useState<BilledItem[]>([]);
  const [selectedItem, setSelectedItem] = useState('');
  const [itemQuantity, setItemQuantity] = useState(1);

  const availableItems = mockInventoryItems.filter(item => item.currentStock > 0);
  const totalAmount = billedItems.reduce((sum, item) => sum + item.totalPrice, 0);

  const handleAddItem = () => {
    if (!selectedItem) return;

    const inventoryItem = availableItems.find(item => item.id === selectedItem);
    if (!inventoryItem) return;

    const existingItemIndex = billedItems.findIndex(item => item.itemId === selectedItem);
    
    if (existingItemIndex >= 0) {
      // Update existing item
      setBilledItems(prev => prev.map((item, index) => 
        index === existingItemIndex 
          ? {
              ...item,
              quantity: item.quantity + itemQuantity,
              totalPrice: (item.quantity + itemQuantity) * item.unitPrice
            }
          : item
      ));
    } else {
      // Add new item
      const newBilledItem: BilledItem = {
        itemId: inventoryItem.id,
        itemName: inventoryItem.name,
        quantity: itemQuantity,
        unitPrice: inventoryItem.sellingPrice,
        totalPrice: itemQuantity * inventoryItem.sellingPrice,
        batchId: inventoryItem.batches.length > 0 ? inventoryItem.batches[0].id : ''
      };

      setBilledItems(prev => [...prev, newBilledItem]);
    }

    setSelectedItem('');
    setItemQuantity(1);
  };

  const handleRemoveItem = (index: number) => {
    setBilledItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.patientName || !formData.patientId || billedItems.length === 0) {
      alert('Please fill in all required fields and add at least one item');
      return;
    }

    const newBill: Partial<PatientBill> = {
      patientId: formData.patientId,
      patientName: formData.patientName,
      items: billedItems,
      totalAmount: totalAmount,
      status: 'pending',
      createdAt: new Date().toISOString(),
      location: formData.location
    };

    onSave(newBill);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Create New Patient Bill</h2>
              <p className="text-sm text-gray-600">Add items and generate invoice automatically</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Patient Information */}
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
                <User className="w-5 h-5" />
                Patient Information
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Patient ID *
                  </label>
                  <input
                    type="text"
                    value={formData.patientId}
                    onChange={(e) => setFormData(prev => ({ ...prev, patientId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., P001"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Patient Name *
                  </label>
                  <input
                    type="text"
                    value={formData.patientName}
                    onChange={(e) => setFormData(prev => ({ ...prev, patientName: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Full name"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <select
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Main Clinic">Main Clinic</option>
                  <option value="Branch Clinic">Branch Clinic</option>
                  <option value="Central Pharmacy">Central Pharmacy</option>
                </select>
              </div>

              {/* Add Items Section */}
              <div className="space-y-4 border-t pt-6">
                <h4 className="font-medium text-gray-900">Add Items to Bill</h4>
                
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Item
                    </label>
                    <select
                      value={selectedItem}
                      onChange={(e) => setSelectedItem(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Choose an item...</option>
                      {availableItems.map(item => (
                        <option key={item.id} value={item.id}>
                          {item.name} - ${item.sellingPrice.toFixed(2)} (Stock: {item.currentStock})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Quantity
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={itemQuantity}
                      onChange={(e) => setItemQuantity(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddItem}
                  disabled={!selectedItem}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Plus className="w-4 h-4" />
                  Add Item
                </button>
              </div>
            </div>

            {/* Bill Items */}
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Bill Items
              </h3>

              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Item
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Qty
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Price
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Total
                      </th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {billedItems.map((item, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 text-sm text-gray-900">
                          {item.itemName}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-900">
                          {item.quantity}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-900">
                          ${item.unitPrice.toFixed(2)}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-900">
                          ${item.totalPrice.toFixed(2)}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(index)}
                            className="text-red-600 hover:text-red-900 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {billedItems.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-8 h-8 mx-auto mb-2" />
                    <p>No items added yet</p>
                  </div>
                )}
              </div>

              {/* Total */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium text-gray-900">Total Amount:</span>
                  <span className="text-2xl font-bold text-blue-600">${totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-6 mt-8 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Create Bill
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewBillModal;