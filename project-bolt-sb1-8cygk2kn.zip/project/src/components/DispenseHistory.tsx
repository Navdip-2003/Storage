import { getAll } from '../lib/mockApi';
import { Dispense, Patient, Medicine } from '../lib/types';
import { Eye } from 'lucide-react';

interface DispenseHistoryProps {
  onNewDispense: () => void;
}

export default function DispenseHistory({ onNewDispense }: DispenseHistoryProps) {
  const dispenses = getAll<Dispense>('dispenses').sort((a, b) =>
    new Date(b.dispenseDate).getTime() - new Date(a.dispenseDate).getTime()
  );
  const patients = getAll<Patient>('patients');
  const medicines = getAll<Medicine>('medicines');

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Dispense History</h3>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Date</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Patient</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Doctor</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Items</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Dispensed By</th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {dispenses.map(dispense => {
                const patient = patients.find(p => p._id === dispense.patientId);

                return (
                  <tr key={dispense._id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-700">
                      {new Date(dispense.dispenseDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-800">{patient?.name}</div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{dispense.doctorName || 'N/A'}</td>
                    <td className="py-3 px-4">
                      <div className="text-sm">
                        {dispense.items.map((item, idx) => {
                          const med = medicines.find(m => m._id === item.medicineId);
                          return (
                            <div key={idx} className="text-gray-700">
                              {med?.name} × {item.quantity}
                            </div>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{dispense.dispensedBy}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Eye size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {dispenses.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No dispenses recorded yet</p>
              <button
                onClick={onNewDispense}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Create First Dispense
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
