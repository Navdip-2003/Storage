import { useState } from 'react';
import { Medicine, Supplier, Location, Batch, StockAdjustment } from '../lib/types';
import { getAll, create } from '../lib/mockApi';

interface AddStockFormProps {
  onComplete: () => void;
}

export default function AddStockForm({ onComplete }: AddStockFormProps) {
  const medicines = getAll<Medicine>('medicines').filter(m => m.isActive);
  const suppliers = getAll<Supplier>('suppliers');
  const locations = getAll<Location>('locations');

  const [formData, setFormData] = useState({
    medicineId: '',
    batchNumber: '',
    expiryDate: '',
    quantity: 0,
    unitCost: 0,
    supplierId: '',
    locationId: '',
    receivedDate: new Date().toISOString().split('T')[0],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.medicineId || !formData.batchNumber || !formData.expiryDate || formData.quantity <= 0) {
      alert('Please fill in all required fields');
      return;
    }

    const batch: Partial<Batch> = {
      medicineId: formData.medicineId,
      batchNumber: formData.batchNumber,
      expiryDate: new Date(formData.expiryDate).toISOString(),
      quantity: formData.quantity,
      unitCost: formData.unitCost,
      supplierId: formData.supplierId,
      locationId: formData.locationId,
      receivedDate: new Date(formData.receivedDate).toISOString(),
      status: 'available',
    };

    const createdBatch = create<Batch>('batches', batch as Batch);

    const adjustment: Partial<StockAdjustment> = {
      medicineId: formData.medicineId,
      batchId: createdBatch._id,
      type: 'receive',
      quantityChange: formData.quantity,
      reason: 'Stock received',
      createdBy: 'Admin',
    };

    create<StockAdjustment>('stockAdjustments', adjustment as StockAdjustment);

    alert('Stock added successfully!');
    onComplete();
  };

  const selectedMedicine = medicines.find(m => m._id === formData.medicineId);

  return (
    <div className="p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-6">Add Stock / Receive Inventory</h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Medicine <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.medicineId}
              onChange={(e) => {
                const med = medicines.find(m => m._id === e.target.value);
                setFormData({
                  ...formData,
                  medicineId: e.target.value,
                  unitCost: med?.defaultUnitPrice || 0,
                  supplierId: med?.defaultSupplierId || '',
                });
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select Medicine</option>
              {medicines.map(med => (
                <option key={med._id} value={med._id}>
                  {med.name} ({med.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Batch Number <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.batchNumber}
              onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Expiry Date <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              value={formData.expiryDate}
              onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantity <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Unit Cost ($)</label>
            <input
              type="number"
              value={formData.unitCost}
              onChange={(e) => setFormData({ ...formData, unitCost: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.01"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Received Date</label>
            <input
              type="date"
              value={formData.receivedDate}
              onChange={(e) => setFormData({ ...formData, receivedDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Supplier</label>
            <select
              value={formData.supplierId}
              onChange={(e) => setFormData({ ...formData, supplierId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Supplier</option>
              {suppliers.map(sup => (
                <option key={sup._id} value={sup._id}>{sup.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <select
              value={formData.locationId}
              onChange={(e) => setFormData({ ...formData, locationId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Location</option>
              {locations.map(loc => (
                <option key={loc._id} value={loc._id}>{loc.name}</option>
              ))}
            </select>
          </div>
        </div>

        {selectedMedicine && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
            <h4 className="font-semibold text-blue-900 mb-2">Medicine Details</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-blue-700">Brand:</span> {selectedMedicine.brand || 'N/A'}</div>
              <div><span className="text-blue-700">Unit:</span> {selectedMedicine.defaultUnit}</div>
              <div><span className="text-blue-700">Default Price:</span> ${selectedMedicine.defaultUnitPrice}</div>
              <div><span className="text-blue-700">Reorder Level:</span> {selectedMedicine.defaultReorderLevel}</div>
            </div>
          </div>
        )}

        <div className="flex gap-3 pt-4">
          <button
            type="submit"
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Add Stock
          </button>
          <button
            type="button"
            onClick={onComplete}
            className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
