import { getAll } from '../lib/mockApi';
import { Batch, Medicine, Location, Supplier, ClinicSettings } from '../lib/types';
import { AlertTriangle, Calendar } from 'lucide-react';

export default function StockLevels() {
  const batches = getAll<Batch>('batches').filter(b => b.status === 'available');
  const medicines = getAll<Medicine>('medicines');
  const locations = getAll<Location>('locations');
  const suppliers = getAll<Supplier>('suppliers');
  const settings = getAll<ClinicSettings>('settings')[0] || { expiryWarningDays: 90 };

  const getBatchStatus = (batch: Batch) => {
    const now = new Date();
    const expiry = new Date(batch.expiryDate);
    const daysUntilExpiry = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (expiry < now) return 'expired';
    if (daysUntilExpiry <= settings.expiryWarningDays) return 'expiring-soon';
    return 'good';
  };

  return (
    <div className="p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Stock Levels by Batch</h3>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Medicine</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Batch No.</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Expiry Date</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Quantity</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Location</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Supplier</th>
            </tr>
          </thead>
          <tbody>
            {batches.map(batch => {
              const medicine = medicines.find(m => m._id === batch.medicineId);
              const location = locations.find(l => l._id === batch.locationId);
              const supplier = suppliers.find(s => s._id === batch.supplierId);
              const status = getBatchStatus(batch);

              const rowClass = status === 'expired'
                ? 'bg-red-50 border-l-4 border-l-red-500'
                : status === 'expiring-soon'
                ? 'bg-yellow-50 border-l-4 border-l-yellow-500'
                : 'border-b border-gray-100 hover:bg-gray-50';

              return (
                <tr key={batch._id} className={rowClass}>
                  <td className="py-3 px-4">
                    <div>
                      <div className="font-medium text-gray-800">{medicine?.name}</div>
                      <div className="text-sm text-gray-500">{medicine?.code}</div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-700">{batch.batchNumber}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      {status !== 'good' && (
                        status === 'expired' ? (
                          <AlertTriangle size={16} className="text-red-600" />
                        ) : (
                          <Calendar size={16} className="text-yellow-600" />
                        )
                      )}
                      <span className={status === 'expired' ? 'text-red-700 font-medium' : status === 'expiring-soon' ? 'text-yellow-700' : 'text-gray-700'}>
                        {new Date(batch.expiryDate).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-gray-800">{batch.quantity}</span>
                    <span className="text-sm text-gray-500 ml-1">{medicine?.defaultUnit}</span>
                  </td>
                  <td className="py-3 px-4 text-gray-700">{location?.name || 'N/A'}</td>
                  <td className="py-3 px-4 text-gray-700">{supplier?.name || 'N/A'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {batches.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            No stock batches found
          </div>
        )}
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-red-700 font-medium mb-1">
            <AlertTriangle size={18} />
            Expired Batches
          </div>
          <div className="text-2xl font-bold text-red-800">
            {batches.filter(b => getBatchStatus(b) === 'expired').length}
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-yellow-700 font-medium mb-1">
            <Calendar size={18} />
            Expiring Soon
          </div>
          <div className="text-2xl font-bold text-yellow-800">
            {batches.filter(b => getBatchStatus(b) === 'expiring-soon').length}
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-green-700 font-medium mb-1">
            Available Stock
          </div>
          <div className="text-2xl font-bold text-green-800">
            {batches.filter(b => getBatchStatus(b) === 'good').length}
          </div>
        </div>
      </div>
    </div>
  );
}
