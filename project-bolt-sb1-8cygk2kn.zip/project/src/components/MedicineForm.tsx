import { useState, useEffect } from 'react';
import { Medicine, Category, DosageForm, Supplier } from '../lib/types';
import { getAll } from '../lib/mockApi';

interface MedicineFormProps {
  medicine: Medicine | null;
  onSave: (medicine: Partial<Medicine>) => void;
  onCancel: () => void;
}

export default function MedicineForm({ medicine, onSave, onCancel }: MedicineFormProps) {
  const categories = getAll<Category>('categories');
  const dosageForms = getAll<DosageForm>('dosageForms');
  const suppliers = getAll<Supplier>('suppliers');

  const [formData, setFormData] = useState({
    name: medicine?.name || '',
    code: medicine?.code || '',
    brand: medicine?.brand || '',
    categoryId: medicine?.categoryId || '',
    dosageFormId: medicine?.dosageFormId || '',
    defaultUnit: medicine?.defaultUnit || 'tablet',
    packQty: medicine?.packSize?.qty || 10,
    packUnit: medicine?.packSize?.unit || 'tablet',
    defaultUnitPrice: medicine?.defaultUnitPrice || 0,
    defaultReorderLevel: medicine?.defaultReorderLevel || 0,
    defaultSupplierId: medicine?.defaultSupplierId || '',
    barcode: medicine?.barcode || '',
    notes: medicine?.notes || '',
    isActive: medicine?.isActive ?? true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.code || !formData.categoryId || !formData.dosageFormId) {
      alert('Please fill in all required fields');
      return;
    }

    onSave({
      name: formData.name,
      code: formData.code,
      brand: formData.brand,
      categoryId: formData.categoryId,
      dosageFormId: formData.dosageFormId,
      defaultUnit: formData.defaultUnit,
      packSize: { qty: formData.packQty, unit: formData.packUnit },
      defaultUnitPrice: formData.defaultUnitPrice,
      defaultReorderLevel: formData.defaultReorderLevel,
      defaultSupplierId: formData.defaultSupplierId,
      barcode: formData.barcode,
      notes: formData.notes,
      isActive: formData.isActive,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-800">
          {medicine ? 'Edit Medicine' : 'Add New Medicine'}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Code <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={formData.code}
            onChange={(e) => setFormData({ ...formData, code: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
          <input
            type="text"
            value={formData.brand}
            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category <span className="text-red-500">*</span>
          </label>
          <select
            value={formData.categoryId}
            onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          >
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat._id} value={cat._id}>{cat.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Dosage Form <span className="text-red-500">*</span>
          </label>
          <select
            value={formData.dosageFormId}
            onChange={(e) => setFormData({ ...formData, dosageFormId: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          >
            <option value="">Select Form</option>
            {dosageForms.map(form => (
              <option key={form._id} value={form._id}>{form.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Default Unit</label>
          <input
            type="text"
            value={formData.defaultUnit}
            onChange={(e) => setFormData({ ...formData, defaultUnit: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Pack Size (Qty)</label>
          <input
            type="number"
            value={formData.packQty}
            onChange={(e) => setFormData({ ...formData, packQty: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            min="1"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Pack Unit</label>
          <input
            type="text"
            value={formData.packUnit}
            onChange={(e) => setFormData({ ...formData, packUnit: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Unit Price ($)</label>
          <input
            type="number"
            value={formData.defaultUnitPrice}
            onChange={(e) => setFormData({ ...formData, defaultUnitPrice: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Reorder Level</label>
          <input
            type="number"
            value={formData.defaultReorderLevel}
            onChange={(e) => setFormData({ ...formData, defaultReorderLevel: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Default Supplier</label>
          <select
            value={formData.defaultSupplierId}
            onChange={(e) => setFormData({ ...formData, defaultSupplierId: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select Supplier</option>
            {suppliers.map(sup => (
              <option key={sup._id} value={sup._id}>{sup.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Barcode</label>
          <input
            type="text"
            value={formData.barcode}
            onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="isActive"
          checked={formData.isActive}
          onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
          className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
        />
        <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
      </div>

      <div className="flex gap-3 pt-4 border-t border-gray-200">
        <button
          type="submit"
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          Save Medicine
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
