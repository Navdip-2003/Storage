import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Medicine, Patient, Batch, Invoice, InvoiceItem, StockAdjustment, BatchAllocation, ClinicSettings } from '../lib/types';
import { getAll, create, update } from '../lib/mockApi';

interface InvoiceFormProps {
  onComplete: () => void;
}

interface InvoiceLine {
  medicineId: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  taxPercent: number;
  allocations: BatchAllocation[];
}

export default function InvoiceForm({ onComplete }: InvoiceFormProps) {
  const medicines = getAll<Medicine>('medicines').filter(m => m.isActive);
  const patients = getAll<Patient>('patients');
  const batches = getAll<Batch>('batches');
  const settings = getAll<ClinicSettings>('settings')[0] || { taxRate: 5 };
  const existingInvoices = getAll<Invoice>('invoices');

  const [patientId, setPatientId] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [lines, setLines] = useState<InvoiceLine[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentReference, setPaymentReference] = useState('');

  const allocateBatches = (medicineId: string, quantity: number): BatchAllocation[] => {
    const availableBatches = batches
      .filter(b => b.medicineId === medicineId && b.status === 'available' && b.quantity > 0)
      .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());

    const allocations: BatchAllocation[] = [];
    let remaining = quantity;

    for (const batch of availableBatches) {
      if (remaining <= 0) break;
      const allocQty = Math.min(remaining, batch.quantity);
      allocations.push({ batchId: batch._id, quantity: allocQty });
      remaining -= allocQty;
    }

    return allocations;
  };

  const addLine = () => {
    setLines([...lines, {
      medicineId: '',
      quantity: 1,
      unitPrice: 0,
      discountPercent: 0,
      taxPercent: settings.taxRate,
      allocations: []
    }]);
  };

  const removeLine = (index: number) => {
    setLines(lines.filter((_, i) => i !== index));
  };

  const updateLine = (index: number, field: string, value: string | number) => {
    const updated = [...lines];
    updated[index] = { ...updated[index], [field]: value };

    if (field === 'medicineId') {
      const med = medicines.find(m => m._id === value);
      if (med) {
        updated[index].unitPrice = med.defaultUnitPrice;
      }
    }

    if (field === 'medicineId' || field === 'quantity') {
      const medicineId = field === 'medicineId' ? String(value) : updated[index].medicineId;
      const quantity = field === 'quantity' ? Number(value) : updated[index].quantity;
      if (medicineId && quantity > 0) {
        updated[index].allocations = allocateBatches(medicineId, quantity);
      }
    }

    setLines(updated);
  };

  const calculateLineTotal = (line: InvoiceLine): number => {
    const subtotal = line.quantity * line.unitPrice;
    const afterDiscount = subtotal * (1 - line.discountPercent / 100);
    const withTax = afterDiscount * (1 + line.taxPercent / 100);
    return withTax;
  };

  const subtotal = lines.reduce((sum, line) => sum + (line.quantity * line.unitPrice), 0);
  const totalDiscount = lines.reduce((sum, line) => {
    return sum + (line.quantity * line.unitPrice * line.discountPercent / 100);
  }, 0);
  const totalTax = lines.reduce((sum, line) => {
    const afterDiscount = (line.quantity * line.unitPrice) * (1 - line.discountPercent / 100);
    return sum + (afterDiscount * line.taxPercent / 100);
  }, 0);
  const total = subtotal - totalDiscount + totalTax;

  const handleSubmit = (saveAndPay: boolean) => {
    if (lines.length === 0) {
      alert('Please add at least one item');
      return;
    }

    for (const line of lines) {
      if (!line.medicineId || line.quantity <= 0) {
        alert('Please complete all invoice lines');
        return;
      }

      const totalAllocated = line.allocations.reduce((sum, a) => sum + a.quantity, 0);
      if (totalAllocated < line.quantity) {
        const med = medicines.find(m => m._id === line.medicineId);
        alert(`Insufficient stock for ${med?.name}`);
        return;
      }
    }

    const invoiceNumber = `INV-${String(existingInvoices.length + 1).padStart(5, '0')}`;

    const invoiceItems: InvoiceItem[] = lines.map(line => ({
      medicineId: line.medicineId,
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      discountPercent: line.discountPercent,
      taxPercent: line.taxPercent,
      lineTotal: calculateLineTotal(line),
      allocations: line.allocations,
    }));

    const payments = saveAndPay && paymentAmount > 0 ? [{
      method: paymentMethod,
      amount: paymentAmount,
      reference: paymentReference,
      date: new Date().toISOString(),
    }] : [];

    const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
    const status = paidAmount >= total ? 'paid' : paidAmount > 0 ? 'partial' : 'unpaid';

    const invoice: Partial<Invoice> = {
      invoiceNumber,
      patientId: patientId || undefined,
      invoiceDate: new Date(invoiceDate).toISOString(),
      items: invoiceItems,
      subtotal,
      taxAmount: totalTax,
      discountAmount: totalDiscount,
      total,
      payments,
      status: status as 'paid' | 'unpaid' | 'partial',
      createdBy: 'Admin',
    };

    create<Invoice>('invoices', invoice as Invoice);

    invoiceItems.forEach(item => {
      item.allocations.forEach(allocation => {
        const batch = batches.find(b => b._id === allocation.batchId);
        if (batch) {
          update<Batch>('batches', batch._id, {
            quantity: batch.quantity - allocation.quantity,
            status: batch.quantity - allocation.quantity === 0 ? 'empty' : 'available',
          });

          create<StockAdjustment>('stockAdjustments', {
            medicineId: item.medicineId,
            batchId: allocation.batchId,
            type: 'sale',
            quantityChange: -allocation.quantity,
            reason: `Invoice ${invoiceNumber}`,
            createdBy: 'Admin',
          } as StockAdjustment);
        }
      });
    });

    alert('Invoice created successfully!');
    onComplete();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-6">Create Invoice</h3>

      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Patient (Optional)</label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Walk-in Customer</option>
              {patients.map(p => (
                <option key={p._id} value={p._id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Invoice Date</label>
            <input
              type="date"
              value={invoiceDate}
              onChange={(e) => setInvoiceDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold text-gray-800">Line Items</h4>
            <button
              type="button"
              onClick={addLine}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700"
            >
              <Plus size={16} />
              Add Item
            </button>
          </div>

          {lines.map((line, index) => {
            const medicine = medicines.find(m => m._id === line.medicineId);
            const lineTotal = calculateLineTotal(line);

            return (
              <div key={index} className="border border-gray-200 rounded-lg p-4 mb-3">
                <div className="grid grid-cols-12 gap-3">
                  <div className="col-span-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Medicine</label>
                    <select
                      value={line.medicineId}
                      onChange={(e) => updateLine(index, 'medicineId', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select</option>
                      {medicines.map(m => (
                        <option key={m._id} value={m._id}>{m.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Qty</label>
                    <input
                      type="number"
                      value={line.quantity}
                      onChange={(e) => updateLine(index, 'quantity', e.target.value)}
                      min="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Price</label>
                    <input
                      type="number"
                      value={line.unitPrice}
                      onChange={(e) => updateLine(index, 'unitPrice', e.target.value)}
                      min="0"
                      step="0.01"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Disc%</label>
                    <input
                      type="number"
                      value={line.discountPercent}
                      onChange={(e) => updateLine(index, 'discountPercent', e.target.value)}
                      min="0"
                      max="100"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Total</label>
                    <div className="px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg font-semibold text-gray-800">
                      ${lineTotal.toFixed(2)}
                    </div>
                  </div>

                  <div className="col-span-1 flex items-end">
                    <button
                      type="button"
                      onClick={() => removeLine(index)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {lines.length === 0 && (
            <div className="text-center py-8 text-gray-500 border-2 border-dashed border-gray-300 rounded-lg">
              Click "Add Item" to start
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 pt-4">
          <div className="max-w-md ml-auto space-y-2">
            <div className="flex justify-between text-gray-700">
              <span>Subtotal:</span>
              <span className="font-medium">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>Discount:</span>
              <span className="font-medium">-${totalDiscount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>Tax:</span>
              <span className="font-medium">${totalTax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold text-gray-900 pt-2 border-t border-gray-300">
              <span>Total:</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-4">
          <h4 className="font-semibold text-gray-800 mb-3">Payment (Optional)</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="cash">Cash</option>
                <option value="card">Card</option>
                <option value="insurance">Insurance</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
              <input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(Number(e.target.value))}
                min="0"
                step="0.01"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Reference</label>
              <input
                type="text"
                value={paymentReference}
                onChange={(e) => setPaymentReference(e.target.value)}
                placeholder="Optional"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-200">
          <button
            type="button"
            onClick={() => handleSubmit(true)}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            Save & Pay
          </button>
          <button
            type="button"
            onClick={() => handleSubmit(false)}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Save (Unpaid)
          </button>
          <button
            type="button"
            onClick={onComplete}
            className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
