import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Medicine, Patient, Batch, Dispense, DispenseItem, StockAdjustment, BatchAllocation } from '../lib/types';
import { getAll, create, update } from '../lib/mockApi';

interface DispenseFormProps {
  onComplete: () => void;
}

interface DispenseLine {
  medicineId: string;
  quantity: number;
  dosageInstructions: string;
  allocations: BatchAllocation[];
}

export default function DispenseForm({ onComplete }: DispenseFormProps) {
  const medicines = getAll<Medicine>('medicines').filter(m => m.isActive);
  const patients = getAll<Patient>('patients');
  const batches = getAll<Batch>('batches');

  const [patientId, setPatientId] = useState('');
  const [patientName, setPatientName] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [dispenseDate, setDispenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [lines, setLines] = useState<DispenseLine[]>([]);
  const [showNewPatient, setShowNewPatient] = useState(false);

  const allocateBatches = (medicineId: string, quantity: number): BatchAllocation[] => {
    const availableBatches = batches
      .filter(b => b.medicineId === medicineId && b.status === 'available' && b.quantity > 0)
      .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());

    const allocations: BatchAllocation[] = [];
    let remaining = quantity;

    for (const batch of availableBatches) {
      if (remaining <= 0) break;
      const allocQty = Math.min(remaining, batch.quantity);
      allocations.push({ batchId: batch._id, quantity: allocQty });
      remaining -= allocQty;
    }

    return allocations;
  };

  const addLine = () => {
    setLines([...lines, { medicineId: '', quantity: 1, dosageInstructions: '', allocations: [] }]);
  };

  const removeLine = (index: number) => {
    setLines(lines.filter((_, i) => i !== index));
  };

  const updateLine = (index: number, field: string, value: string | number) => {
    const updated = [...lines];
    updated[index] = { ...updated[index], [field]: value };

    if (field === 'medicineId' || field === 'quantity') {
      const medicineId = field === 'medicineId' ? String(value) : updated[index].medicineId;
      const quantity = field === 'quantity' ? Number(value) : updated[index].quantity;
      if (medicineId && quantity > 0) {
        updated[index].allocations = allocateBatches(medicineId, quantity);
      }
    }

    setLines(updated);
  };

  const handleCreatePatient = () => {
    if (!patientName.trim()) {
      alert('Please enter patient name');
      return;
    }
    const newPatient = create<Patient>('patients', { name: patientName } as Patient);
    setPatientId(newPatient._id);
    setShowNewPatient(false);
    setPatientName('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientId || lines.length === 0) {
      alert('Please select a patient and add at least one medication');
      return;
    }

    for (const line of lines) {
      if (!line.medicineId || line.quantity <= 0) {
        alert('Please complete all medication lines');
        return;
      }

      const totalAllocated = line.allocations.reduce((sum, a) => sum + a.quantity, 0);
      if (totalAllocated < line.quantity) {
        const med = medicines.find(m => m._id === line.medicineId);
        alert(`Insufficient stock for ${med?.name}. Available: ${totalAllocated}, Required: ${line.quantity}`);
        return;
      }
    }

    const dispenseItems: DispenseItem[] = lines.map(line => {
      const medicine = medicines.find(m => m._id === line.medicineId);
      return {
        medicineId: line.medicineId,
        quantity: line.quantity,
        unit: medicine?.defaultUnit || 'unit',
        dosageInstructions: line.dosageInstructions,
        allocations: line.allocations,
      };
    });

    const dispense: Partial<Dispense> = {
      patientId,
      doctorName,
      dispenseDate: new Date(dispenseDate).toISOString(),
      dispensedBy: 'Admin',
      items: dispenseItems,
    };

    create<Dispense>('dispenses', dispense as Dispense);

    dispenseItems.forEach(item => {
      item.allocations.forEach(allocation => {
        const batch = batches.find(b => b._id === allocation.batchId);
        if (batch) {
          update<Batch>('batches', batch._id, {
            quantity: batch.quantity - allocation.quantity,
            status: batch.quantity - allocation.quantity === 0 ? 'empty' : 'available',
          });

          create<StockAdjustment>('stockAdjustments', {
            medicineId: item.medicineId,
            batchId: allocation.batchId,
            type: 'dispense',
            quantityChange: -allocation.quantity,
            reason: 'Dispensed to patient',
            createdBy: 'Admin',
          } as StockAdjustment);
        }
      });
    });

    alert('Dispense completed successfully!');
    onComplete();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-6">New Dispense</h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Patient <span className="text-red-500">*</span>
            </label>
            {!showNewPatient ? (
              <div className="flex gap-2">
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Patient</option>
                  {patients.map(p => (
                    <option key={p._id} value={p._id}>{p.name}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowNewPatient(true)}
                  className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  <Plus size={20} />
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="New patient name"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={handleCreatePatient}
                  className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Add
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewPatient(false)}
                  className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Doctor Name</label>
            <input
              type="text"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Dispense Date</label>
            <input
              type="date"
              value={dispenseDate}
              onChange={(e) => setDispenseDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold text-gray-800">Medications</h4>
            <button
              type="button"
              onClick={addLine}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700"
            >
              <Plus size={16} />
              Add Medication
            </button>
          </div>

          {lines.map((line, index) => {
            const medicine = medicines.find(m => m._id === line.medicineId);
            const totalAllocated = line.allocations.reduce((sum, a) => sum + a.quantity, 0);
            const hasShortage = line.quantity > 0 && totalAllocated < line.quantity;

            return (
              <div key={index} className="border border-gray-200 rounded-lg p-4 mb-3">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                  <div className="md:col-span-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Medicine</label>
                    <select
                      value={line.medicineId}
                      onChange={(e) => updateLine(index, 'medicineId', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select Medicine</option>
                      {medicines.map(m => (
                        <option key={m._id} value={m._id}>{m.name} ({m.code})</option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                    <input
                      type="number"
                      value={line.quantity}
                      onChange={(e) => updateLine(index, 'quantity', e.target.value)}
                      min="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="md:col-span-5">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Dosage Instructions</label>
                    <input
                      type="text"
                      value={line.dosageInstructions}
                      onChange={(e) => updateLine(index, 'dosageInstructions', e.target.value)}
                      placeholder="e.g., Take 1 tablet twice daily"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="md:col-span-1 flex items-end">
                    <button
                      type="button"
                      onClick={() => removeLine(index)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>

                {line.medicineId && line.quantity > 0 && (
                  <div className={`mt-3 p-3 rounded-lg ${hasShortage ? 'bg-red-50 border border-red-200' : 'bg-blue-50 border border-blue-200'}`}>
                    <div className="text-sm font-medium mb-2">
                      {hasShortage ? (
                        <span className="text-red-700">⚠️ Insufficient Stock - Only {totalAllocated} available</span>
                      ) : (
                        <span className="text-blue-700">FEFO Allocation Preview:</span>
                      )}
                    </div>
                    {line.allocations.length > 0 ? (
                      <div className="space-y-1">
                        {line.allocations.map((alloc, i) => {
                          const batch = batches.find(b => b._id === alloc.batchId);
                          return (
                            <div key={i} className="text-sm text-gray-700">
                              Batch {batch?.batchNumber}: {alloc.quantity} {medicine?.defaultUnit} (Expires: {new Date(batch?.expiryDate || '').toLocaleDateString()})
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-sm text-red-600">No stock available</div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {lines.length === 0 && (
            <div className="text-center py-8 text-gray-500 border-2 border-dashed border-gray-300 rounded-lg">
              Click "Add Medication" to start
            </div>
          )}
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-200">
          <button
            type="submit"
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            Complete Dispense
          </button>
          <button
            type="button"
            onClick={onComplete}
            className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
