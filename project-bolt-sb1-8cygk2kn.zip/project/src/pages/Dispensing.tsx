import { useState } from 'react';
import { Plus } from 'lucide-react';
import DispenseForm from '../components/DispenseForm';
import DispenseHistory from '../components/DispenseHistory';

export default function Dispensing() {
  const [view, setView] = useState<'history' | 'new'>('history');

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Dispensing</h2>
          <p className="text-gray-600 mt-1">Dispense medications to patients</p>
        </div>
        {view === 'history' && (
          <button
            onClick={() => setView('new')}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Plus size={20} />
            New Dispense
          </button>
        )}
      </div>

      {view === 'history' ? (
        <DispenseHistory onNewDispense={() => setView('new')} />
      ) : (
        <DispenseForm onComplete={() => setView('history')} />
      )}
    </div>
  );
}
