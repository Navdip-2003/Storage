import { DollarSign, ShoppingCart, AlertTriangle, Calendar, Plus } from 'lucide-react';
import { getAll } from '../lib/mockApi';
import { Medicine, Batch, Invoice, ClinicSettings } from '../lib/types';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const medicines = getAll<Medicine>('medicines');
  const batches = getAll<Batch>('batches');
  const invoices = getAll<Invoice>('invoices');
  const settings = getAll<ClinicSettings>('settings')[0] || { expiryWarningDays: 90 };

  const totalStockValue = batches.reduce((sum, batch) => {
    return sum + (batch.quantity * batch.unitCost);
  }, 0);

  const today = new Date().toISOString().split('T')[0];
  const todaySales = invoices
    .filter(inv => inv.invoiceDate.startsWith(today))
    .reduce((sum, inv) => sum + inv.total, 0);

  const lowStockCount = medicines.filter(med => {
    const totalQty = batches
      .filter(b => b.medicineId === med._id && b.status === 'available')
      .reduce((sum, b) => sum + b.quantity, 0);
    return totalQty <= med.defaultReorderLevel;
  }).length;

  const expiryWarningDate = new Date();
  expiryWarningDate.setDate(expiryWarningDate.getDate() + settings.expiryWarningDays);
  const expiringSoonCount = batches.filter(batch => {
    const expiry = new Date(batch.expiryDate);
    return expiry <= expiryWarningDate && batch.status === 'available';
  }).length;

  const cards = [
    {
      title: 'Total Stock Value',
      value: `$${totalStockValue.toFixed(2)}`,
      icon: DollarSign,
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
    },
    {
      title: "Today's Sales",
      value: `$${todaySales.toFixed(2)}`,
      icon: ShoppingCart,
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
    },
    {
      title: 'Low Stock Items',
      value: lowStockCount.toString(),
      icon: AlertTriangle,
      bgColor: 'bg-yellow-50',
      iconColor: 'text-yellow-600',
    },
    {
      title: 'Expiring Soon',
      value: expiringSoonCount.toString(),
      icon: Calendar,
      bgColor: 'bg-red-50',
      iconColor: 'text-red-600',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Dashboard</h2>
        <p className="text-gray-600">Welcome to your clinic management system</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.title} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`${card.bgColor} p-3 rounded-lg`}>
                  <Icon className={card.iconColor} size={24} />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-1">{card.title}</h3>
              <p className="text-3xl font-bold text-gray-800">{card.value}</p>
            </div>
          );
        })}
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigate('inventory')}
            className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-blue-500 hover:shadow-md transition-all"
          >
            <div className="bg-blue-50 p-3 rounded-lg">
              <Plus className="text-blue-600" size={20} />
            </div>
            <div className="text-left">
              <h4 className="font-semibold text-gray-800">Add Stock</h4>
              <p className="text-sm text-gray-600">Receive new inventory</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('dispensing')}
            className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-green-500 hover:shadow-md transition-all"
          >
            <div className="bg-green-50 p-3 rounded-lg">
              <Plus className="text-green-600" size={20} />
            </div>
            <div className="text-left">
              <h4 className="font-semibold text-gray-800">New Dispense</h4>
              <p className="text-sm text-gray-600">Dispense medication</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('billing')}
            className="flex items-center gap-3 p-4 bg-white rounded-lg border border-gray-200 hover:border-purple-500 hover:shadow-md transition-all"
          >
            <div className="bg-purple-50 p-3 rounded-lg">
              <Plus className="text-purple-600" size={20} />
            </div>
            <div className="text-left">
              <h4 className="font-semibold text-gray-800">New Invoice</h4>
              <p className="text-sm text-gray-600">Create invoice</p>
            </div>
          </button>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h4 className="font-semibold text-yellow-800 mb-2">Data Storage Notice</h4>
        <p className="text-sm text-yellow-700">
          This application stores data in browser cookies/localStorage. For production use with large datasets,
          please migrate to a proper backend database. Cookie storage has a limit of approximately 4KB per cookie.
        </p>
      </div>
    </div>
  );
}
