import { AlertTriangle, Calendar, Package } from 'lucide-react';
import { getAll } from '../lib/mockApi';
import { Medicine, Batch, ClinicSettings } from '../lib/types';

export default function Alerts() {
  const medicines = getAll<Medicine>('medicines');
  const batches = getAll<Batch>('batches');
  const settings = getAll<ClinicSettings>('settings')[0] || { expiryWarningDays: 90 };

  const lowStockMedicines = medicines.filter(med => {
    const totalQty = batches
      .filter(b => b.medicineId === med._id && b.status === 'available')
      .reduce((sum, b) => sum + b.quantity, 0);
    return totalQty <= med.defaultReorderLevel;
  });

  const expiryWarningDate = new Date();
  expiryWarningDate.setDate(expiryWarningDate.getDate() + settings.expiryWarningDays);

  const expiringSoonBatches = batches.filter(batch => {
    const expiry = new Date(batch.expiryDate);
    return expiry <= expiryWarningDate && batch.status === 'available';
  }).map(batch => {
    const med = medicines.find(m => m._id === batch.medicineId);
    const daysUntilExpiry = Math.floor((new Date(batch.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return { ...batch, medicine: med, daysUntilExpiry };
  }).sort((a, b) => a.daysUntilExpiry - b.daysUntilExpiry);

  const expiredBatches = expiringSoonBatches.filter(b => b.daysUntilExpiry < 0);
  const expiringBatches = expiringSoonBatches.filter(b => b.daysUntilExpiry >= 0);

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-800">Alerts & Notifications</h2>
        <p className="text-gray-600 mt-1">Monitor low stock and expiring items</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertTriangle className="text-red-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-red-900">Expired Items</h3>
              <p className="text-3xl font-bold text-red-700">{expiredBatches.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Calendar className="text-yellow-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-yellow-900">Expiring Soon</h3>
              <p className="text-3xl font-bold text-yellow-700">{expiringBatches.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-orange-100 p-3 rounded-lg">
              <Package className="text-orange-600" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-orange-900">Low Stock</h3>
              <p className="text-3xl font-bold text-orange-700">{lowStockMedicines.length}</p>
            </div>
          </div>
        </div>
      </div>

      {expiredBatches.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="bg-red-50 border-b border-red-200 px-6 py-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="text-red-600" size={20} />
              <h3 className="text-lg font-semibold text-red-900">Expired Batches - Immediate Action Required</h3>
            </div>
          </div>
          <div className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Medicine</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Batch Number</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Expired Date</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Days Overdue</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Quantity</th>
                </tr>
              </thead>
              <tbody>
                {expiredBatches.map(batch => (
                  <tr key={batch._id} className="border-b border-gray-100 bg-red-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-800">{batch.medicine?.name}</div>
                      <div className="text-sm text-gray-500">{batch.medicine?.code}</div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{batch.batchNumber}</td>
                    <td className="py-3 px-4 text-red-700 font-medium">
                      {new Date(batch.expiryDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                        {Math.abs(batch.daysUntilExpiry)} days
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{batch.quantity} {batch.medicine?.defaultUnit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {expiringBatches.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="bg-yellow-50 border-b border-yellow-200 px-6 py-4">
            <div className="flex items-center gap-2">
              <Calendar className="text-yellow-600" size={20} />
              <h3 className="text-lg font-semibold text-yellow-900">
                Expiring Soon (Within {settings.expiryWarningDays} Days)
              </h3>
            </div>
          </div>
          <div className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Medicine</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Batch Number</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Expiry Date</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Days Remaining</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Quantity</th>
                </tr>
              </thead>
              <tbody>
                {expiringBatches.map(batch => (
                  <tr key={batch._id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-800">{batch.medicine?.name}</div>
                      <div className="text-sm text-gray-500">{batch.medicine?.code}</div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{batch.batchNumber}</td>
                    <td className="py-3 px-4 text-yellow-700">
                      {new Date(batch.expiryDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-sm font-medium ${
                        batch.daysUntilExpiry <= 30
                          ? 'bg-red-100 text-red-700'
                          : batch.daysUntilExpiry <= 60
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-green-100 text-green-700'
                      }`}>
                        {batch.daysUntilExpiry} days
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{batch.quantity} {batch.medicine?.defaultUnit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {lowStockMedicines.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="bg-orange-50 border-b border-orange-200 px-6 py-4">
            <div className="flex items-center gap-2">
              <Package className="text-orange-600" size={20} />
              <h3 className="text-lg font-semibold text-orange-900">Low Stock Medicines - Reorder Needed</h3>
            </div>
          </div>
          <div className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Medicine</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Current Stock</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Reorder Level</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Unit Price</th>
                </tr>
              </thead>
              <tbody>
                {lowStockMedicines.map(med => {
                  const currentStock = batches
                    .filter(b => b.medicineId === med._id && b.status === 'available')
                    .reduce((sum, b) => sum + b.quantity, 0);

                  return (
                    <tr key={med._id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="font-medium text-gray-800">{med.name}</div>
                        <div className="text-sm text-gray-500">{med.code}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                          {currentStock} {med.defaultUnit}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-700">{med.defaultReorderLevel} {med.defaultUnit}</td>
                      <td className="py-3 px-4 text-gray-700">${med.defaultUnitPrice.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {expiredBatches.length === 0 && expiringBatches.length === 0 && lowStockMedicines.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <div className="text-green-600 mb-4">
            <Package size={48} className="mx-auto" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">All Clear!</h3>
          <p className="text-gray-600">No alerts at this time. Your inventory is in good shape.</p>
        </div>
      )}
    </div>
  );
}
