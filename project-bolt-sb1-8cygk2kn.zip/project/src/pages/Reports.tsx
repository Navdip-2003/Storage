import { useState } from 'react';
import { Download } from 'lucide-react';
import { getAll } from '../lib/mockApi';
import { Medicine, Batch, Invoice, StockAdjustment, ClinicSettings } from '../lib/types';

export default function Reports() {
  const [reportType, setReportType] = useState<'stock' | 'sales' | 'audit'>('stock');

  const medicines = getAll<Medicine>('medicines');
  const batches = getAll<Batch>('batches');
  const invoices = getAll<Invoice>('invoices');
  const adjustments = getAll<StockAdjustment>('stockAdjustments');
  const settings = getAll<ClinicSettings>('settings')[0] || { expiryWarningDays: 90 };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) return;

    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).join(',')).join('\n');
    const csv = `${headers}\n${rows}`;

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
  };

  const stockValuation = medicines.map(med => {
    const medBatches = batches.filter(b => b.medicineId === med._id && b.status === 'available');
    const totalQty = medBatches.reduce((sum, b) => sum + b.quantity, 0);
    const totalValue = medBatches.reduce((sum, b) => sum + (b.quantity * b.unitCost), 0);

    return {
      Medicine: med.name,
      Code: med.code,
      Quantity: totalQty,
      'Avg Cost': totalQty > 0 ? (totalValue / totalQty).toFixed(2) : '0.00',
      'Total Value': totalValue.toFixed(2),
    };
  });

  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + settings.expiryWarningDays);

  const expiringBatches = batches
    .filter(b => {
      const exp = new Date(b.expiryDate);
      return exp <= expiryDate && b.status === 'available';
    })
    .map(b => {
      const med = medicines.find(m => m._id === b.medicineId);
      const daysUntilExpiry = Math.floor((new Date(b.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));

      return {
        Medicine: med?.name || '',
        'Batch No': b.batchNumber,
        'Expiry Date': new Date(b.expiryDate).toLocaleDateString(),
        'Days Until Expiry': daysUntilExpiry,
        Quantity: b.quantity,
      };
    })
    .sort((a, b) => a['Days Until Expiry'] - b['Days Until Expiry']);

  const salesByMedicine = invoices.flatMap(inv =>
    inv.items.map(item => ({
      medicineId: item.medicineId,
      quantity: item.quantity,
      revenue: item.lineTotal,
    }))
  ).reduce((acc, item) => {
    const existing = acc.find(a => a.medicineId === item.medicineId);
    if (existing) {
      existing.quantity += item.quantity;
      existing.revenue += item.revenue;
    } else {
      acc.push({ ...item });
    }
    return acc;
  }, [] as { medicineId: string; quantity: number; revenue: number }[])
  .map(item => {
    const med = medicines.find(m => m._id === item.medicineId);
    return {
      Medicine: med?.name || '',
      'Units Sold': item.quantity,
      'Total Revenue': item.revenue.toFixed(2),
    };
  })
  .sort((a, b) => parseFloat(b['Total Revenue']) - parseFloat(a['Total Revenue']));

  const auditLogs = adjustments
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 100)
    .map(adj => {
      const med = medicines.find(m => m._id === adj.medicineId);
      const batch = batches.find(b => b._id === adj.batchId);

      return {
        Date: new Date(adj.createdAt).toLocaleString(),
        Medicine: med?.name || '',
        Batch: batch?.batchNumber || '',
        Type: adj.type,
        'Qty Change': adj.quantityChange,
        Reason: adj.reason || '',
        'Created By': adj.createdBy,
      };
    });

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-800">Reports</h2>
        <p className="text-gray-600 mt-1">View and export reports</p>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex">
            <button
              onClick={() => setReportType('stock')}
              className={`px-6 py-3 font-medium transition-colors ${
                reportType === 'stock'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Stock Reports
            </button>
            <button
              onClick={() => setReportType('sales')}
              className={`px-6 py-3 font-medium transition-colors ${
                reportType === 'sales'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Sales Reports
            </button>
            <button
              onClick={() => setReportType('audit')}
              className={`px-6 py-3 font-medium transition-colors ${
                reportType === 'audit'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Audit Logs
            </button>
          </nav>
        </div>

        <div className="p-6">
          {reportType === 'stock' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Stock Valuation</h3>
                  <button
                    onClick={() => exportToCSV(stockValuation, 'stock-valuation.csv')}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Download size={16} />
                    Export CSV
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        {stockValuation.length > 0 && Object.keys(stockValuation[0]).map(key => (
                          <th key={key} className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                            {key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {stockValuation.map((row, i) => (
                        <tr key={i} className="border-b border-gray-100">
                          {Object.values(row).map((val, j) => (
                            <td key={j} className="py-3 px-4 text-gray-700">{val}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Expiring Batches ({settings.expiryWarningDays} days)</h3>
                  <button
                    onClick={() => exportToCSV(expiringBatches, 'expiring-batches.csv')}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Download size={16} />
                    Export CSV
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        {expiringBatches.length > 0 && Object.keys(expiringBatches[0]).map(key => (
                          <th key={key} className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                            {key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {expiringBatches.map((row, i) => (
                        <tr key={i} className={`border-b border-gray-100 ${
                          row['Days Until Expiry'] < 0 ? 'bg-red-50' : row['Days Until Expiry'] < 30 ? 'bg-yellow-50' : ''
                        }`}>
                          {Object.values(row).map((val, j) => (
                            <td key={j} className="py-3 px-4 text-gray-700">{val}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {reportType === 'sales' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Top Selling Medicines</h3>
                <button
                  onClick={() => exportToCSV(salesByMedicine, 'sales-by-medicine.csv')}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Download size={16} />
                  Export CSV
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      {salesByMedicine.length > 0 && Object.keys(salesByMedicine[0]).map(key => (
                        <th key={key} className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {salesByMedicine.map((row, i) => (
                      <tr key={i} className="border-b border-gray-100">
                        {Object.values(row).map((val, j) => (
                          <td key={j} className="py-3 px-4 text-gray-700">{val}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {salesByMedicine.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    No sales data available
                  </div>
                )}
              </div>
            </div>
          )}

          {reportType === 'audit' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Stock Adjustment Audit Log (Last 100)</h3>
                <button
                  onClick={() => exportToCSV(auditLogs, 'audit-logs.csv')}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Download size={16} />
                  Export CSV
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      {auditLogs.length > 0 && Object.keys(auditLogs[0]).map(key => (
                        <th key={key} className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs.map((row, i) => (
                      <tr key={i} className="border-b border-gray-100">
                        {Object.values(row).map((val, j) => (
                          <td key={j} className="py-3 px-4 text-sm text-gray-700">{val}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {auditLogs.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    No audit logs available
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
