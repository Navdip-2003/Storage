import { useState } from 'react';
import { Plus, Search, CreditCard as Edit2, Trash2, Package } from 'lucide-react';
import { getAll, create, update, remove } from '../lib/mockApi';
import { Medicine, Category, DosageForm, Supplier, Batch } from '../lib/types';
import MedicineForm from '../components/MedicineForm';
import AddStockForm from '../components/AddStockForm';
import StockLevels from '../components/StockLevels';

type InventoryView = 'catalog' | 'stock-levels' | 'add-stock';

export default function Inventory() {
  const [view, setView] = useState<InventoryView>('catalog');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [showMedicineForm, setShowMedicineForm] = useState(false);

  const medicines = getAll<Medicine>('medicines');
  const categories = getAll<Category>('categories');
  const batches = getAll<Batch>('batches');

  const filteredMedicines = medicines.filter(med => {
    const matchesSearch = med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         med.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || med.categoryId === selectedCategory;
    return matchesSearch && matchesCategory && med.isActive;
  });

  const getMedicineStock = (medicineId: string) => {
    return batches
      .filter(b => b.medicineId === medicineId && b.status === 'available')
      .reduce((sum, b) => sum + b.quantity, 0);
  };

  const handleDeleteMedicine = (id: string) => {
    if (confirm('Are you sure you want to delete this medicine?')) {
      remove('medicines', id);
      window.location.reload();
    }
  };

  const handleSaveMedicine = (medicine: Partial<Medicine>) => {
    if (editingMedicine) {
      update('medicines', editingMedicine._id, medicine);
    } else {
      create('medicines', medicine);
    }
    setShowMedicineForm(false);
    setEditingMedicine(null);
    window.location.reload();
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Inventory Management</h2>
          <p className="text-gray-600 mt-1">Manage medicines, stock, and batches</p>
        </div>
        <button
          onClick={() => {
            setEditingMedicine(null);
            setShowMedicineForm(true);
            setView('catalog');
          }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Add Medicine
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
        <div className="border-b border-gray-200">
          <nav className="flex">
            <button
              onClick={() => setView('catalog')}
              className={`px-6 py-3 font-medium transition-colors ${
                view === 'catalog'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Medicine Catalog
            </button>
            <button
              onClick={() => setView('stock-levels')}
              className={`px-6 py-3 font-medium transition-colors ${
                view === 'stock-levels'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Stock Levels
            </button>
            <button
              onClick={() => setView('add-stock')}
              className={`px-6 py-3 font-medium transition-colors ${
                view === 'add-stock'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Add Stock
            </button>
          </nav>
        </div>

        {view === 'catalog' && !showMedicineForm && (
          <div className="p-6">
            <div className="flex gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search by name or code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Categories</option>
                {categories.map(cat => (
                  <option key={cat._id} value={cat._id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Name</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Code</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Category</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Unit Price</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Stock</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMedicines.map(med => {
                    const category = categories.find(c => c._id === med.categoryId);
                    const stock = getMedicineStock(med._id);
                    const isLowStock = stock <= med.defaultReorderLevel;

                    return (
                      <tr key={med._id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <div>
                            <div className="font-medium text-gray-800">{med.name}</div>
                            {med.brand && <div className="text-sm text-gray-500">{med.brand}</div>}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-gray-700">{med.code}</td>
                        <td className="py-3 px-4 text-gray-700">{category?.name}</td>
                        <td className="py-3 px-4 text-gray-700">${med.defaultUnitPrice.toFixed(2)}</td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm font-medium ${
                            isLowStock ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                          }`}>
                            <Package size={14} />
                            {stock}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                setEditingMedicine(med);
                                setShowMedicineForm(true);
                              }}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            >
                              <Edit2 size={16} />
                            </button>
                            <button
                              onClick={() => handleDeleteMedicine(med._id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filteredMedicines.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  No medicines found
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'catalog' && showMedicineForm && (
          <div className="p-6">
            <MedicineForm
              medicine={editingMedicine}
              onSave={handleSaveMedicine}
              onCancel={() => {
                setShowMedicineForm(false);
                setEditingMedicine(null);
              }}
            />
          </div>
        )}

        {view === 'stock-levels' && (
          <StockLevels />
        )}

        {view === 'add-stock' && (
          <AddStockForm onComplete={() => setView('stock-levels')} />
        )}
      </div>
    </div>
  );
}
