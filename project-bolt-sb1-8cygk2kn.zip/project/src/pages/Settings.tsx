import { useState } from 'react';
import { Download, Upload, AlertTriangle, Trash2 } from 'lucide-react';
import { exportAllData, importAllData, clearAllData, getStorageMode, setStorageMode, StorageMode } from '../lib/storage';
import { initializeSeedData } from '../lib/seedData';

export default function Settings() {
  const [activeTab, setActiveTab] = useState<'data' | 'clinic'>('data');
  const { mode, warning } = getStorageMode();
  const [storageMode, setStorageModeState] = useState<StorageMode>(mode);

  const handleExport = () => {
    const data = exportAllData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clinic-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const json = event.target?.result as string;
          const result = importAllData(json, storageMode);
          if (result.success) {
            alert('Data imported successfully!');
            window.location.reload();
          } else {
            alert(`Import failed: ${result.error}`);
          }
        } catch (err) {
          alert('Invalid JSON file');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleClearAll = () => {
    if (confirm('Are you sure you want to delete ALL data? This cannot be undone!')) {
      clearAllData();
      alert('All data cleared!');
      window.location.reload();
    }
  };

  const handleResetDemo = () => {
    if (confirm('Reset to demo data? This will replace all existing data.')) {
      clearAllData();
      initializeSeedData();
      alert('Demo data loaded!');
      window.location.reload();
    }
  };

  const handleStorageModeChange = (newMode: StorageMode) => {
    setStorageMode(newMode);
    setStorageModeState(newMode);
    alert(`Storage mode changed to ${newMode}. Changes will apply to new data.`);
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-800">Settings</h2>
        <p className="text-gray-600 mt-1">Manage application settings and data</p>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex">
            <button
              onClick={() => setActiveTab('data')}
              className={`px-6 py-3 font-medium transition-colors ${
                activeTab === 'data'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Data Management
            </button>
            <button
              onClick={() => setActiveTab('clinic')}
              className={`px-6 py-3 font-medium transition-colors ${
                activeTab === 'clinic'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Clinic Settings
            </button>
          </nav>
        </div>

        {activeTab === 'data' && (
          <div className="p-6 space-y-6">
            {warning && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="text-yellow-600 flex-shrink-0 mt-0.5" size={20} />
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-1">Storage Warning</h4>
                    <p className="text-sm text-yellow-700">{warning}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Storage Mode</h4>
              <p className="text-sm text-blue-700 mb-3">
                Current mode: <strong>{storageMode}</strong>. Choose how data is persisted in your browser.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => handleStorageModeChange('cookies')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    storageMode === 'cookies'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-blue-600 border border-blue-300 hover:bg-blue-50'
                  }`}
                >
                  Cookies
                </button>
                <button
                  onClick={() => handleStorageModeChange('localStorage')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    storageMode === 'localStorage'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-blue-600 border border-blue-300 hover:bg-blue-50'
                  }`}
                >
                  LocalStorage
                </button>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="text-red-600 flex-shrink-0 mt-0.5" size={20} />
                <div className="flex-1">
                  <h4 className="font-semibold text-red-900 mb-1">Important Notice</h4>
                  <p className="text-sm text-red-700 mb-2">
                    This application uses browser cookies and localStorage for data persistence. This is suitable for
                    demo purposes and small-scale local use only.
                  </p>
                  <ul className="text-sm text-red-700 space-y-1 list-disc list-inside">
                    <li>Cookies have a size limit of ~4KB per cookie</li>
                    <li>Data is stored locally in your browser only</li>
                    <li>Clearing browser data will delete all information</li>
                    <li>Not suitable for multi-user or production environments</li>
                    <li>For production use, migrate to a proper backend database</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Export / Import Data</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  onClick={handleExport}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Download size={20} />
                  Export All Data (JSON)
                </button>
                <button
                  onClick={handleImport}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Upload size={20} />
                  Import Data (JSON)
                </button>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Export your data as a JSON file for backup or transfer. Import previously exported data to restore.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Demo & Reset</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  onClick={handleResetDemo}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Reset to Demo Data
                </button>
                <button
                  onClick={handleClearAll}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Trash2 size={20} />
                  Clear All Data
                </button>
              </div>
              <p className="text-sm text-red-600 mt-2 font-medium">
                Warning: These actions are permanent and cannot be undone!
              </p>
            </div>
          </div>
        )}

        {activeTab === 'clinic' && (
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Clinic Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Clinic Name</label>
                <input
                  type="text"
                  defaultValue="HealthCare Clinic"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax Rate (%)</label>
                <input
                  type="number"
                  defaultValue="5"
                  min="0"
                  max="100"
                  step="0.1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="GBP">GBP - British Pound</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Expiry Warning (Days)
                </label>
                <input
                  type="number"
                  defaultValue="90"
                  min="1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-sm text-gray-600 mt-1">
                  Show alerts for items expiring within this many days
                </p>
              </div>

              <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
                Save Settings
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
