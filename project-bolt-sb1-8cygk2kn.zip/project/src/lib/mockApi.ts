import { readCollection, writeCollection } from './storage';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function getAll<T>(collection: string): T[] {
  return readCollection<T>(collection);
}

export function getById<T extends { _id: string }>(collection: string, id: string): T | null {
  const items = readCollection<T>(collection);
  return items.find(item => item._id === id) || null;
}

export function create<T extends { _id?: string; createdAt?: string; updatedAt?: string }>(
  collection: string,
  obj: T
): T {
  const items = readCollection<T>(collection);
  const newItem = {
    ...obj,
    _id: obj._id || generateId(),
    createdAt: obj.createdAt || new Date().toISOString(),
    updatedAt: obj.updatedAt || new Date().toISOString(),
  } as T;
  items.push(newItem);
  writeCollection(collection, items);
  return newItem;
}

export function update<T extends { _id: string; updatedAt?: string }>(
  collection: string,
  id: string,
  patch: Partial<T>
): T | null {
  const items = readCollection<T>(collection);
  const index = items.findIndex(item => item._id === id);
  if (index === -1) return null;

  items[index] = {
    ...items[index],
    ...patch,
    _id: id,
    updatedAt: new Date().toISOString(),
  };
  writeCollection(collection, items);
  return items[index];
}

export function remove(collection: string, id: string): boolean {
  const items = readCollection(collection);
  const filtered = items.filter((item: { _id: string }) => item._id !== id);
  if (filtered.length === items.length) return false;
  writeCollection(collection, filtered);
  return true;
}

export function query<T>(collection: string, predicate: (item: T) => boolean): T[] {
  const items = readCollection<T>(collection);
  return items.filter(predicate);
}
