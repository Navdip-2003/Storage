export interface Medicine {
  _id: string;
  name: string;
  code: string;
  brand?: string;
  categoryId: string;
  dosageFormId: string;
  defaultUnit: string;
  packSize: { qty: number; unit: string };
  defaultUnitPrice: number;
  defaultReorderLevel: number;
  defaultSupplierId?: string;
  packagingTypeId?: string;
  barcode?: string;
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Batch {
  _id: string;
  medicineId: string;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  unitCost: number;
  locationId?: string;
  supplierId?: string;
  receivedDate: string;
  status: 'available' | 'empty' | 'expired';
  createdAt: string;
}

export interface Category {
  _id: string;
  name: string;
  description?: string;
}

export interface DosageForm {
  _id: string;
  name: string;
}

export interface Supplier {
  _id: string;
  name: string;
  contact?: string;
  email?: string;
  phone?: string;
}

export interface Location {
  _id: string;
  name: string;
  description?: string;
}

export interface Patient {
  _id: string;
  name: string;
  phone?: string;
  email?: string;
  createdAt: string;
}

export interface Dispense {
  _id: string;
  patientId: string;
  doctorName?: string;
  dispenseDate: string;
  dispensedBy: string;
  items: DispenseItem[];
  linkedInvoiceId?: string;
  createdAt: string;
}

export interface DispenseItem {
  medicineId: string;
  quantity: number;
  unit: string;
  dosageInstructions?: string;
  allocations: BatchAllocation[];
}

export interface BatchAllocation {
  batchId: string;
  quantity: number;
}

export interface Invoice {
  _id: string;
  invoiceNumber: string;
  patientId?: string;
  invoiceDate: string;
  locationId?: string;
  items: InvoiceItem[];
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
  payments: Payment[];
  status: 'paid' | 'unpaid' | 'partial';
  linkedDispenseId?: string;
  createdBy: string;
  createdAt: string;
}

export interface InvoiceItem {
  medicineId: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  taxPercent: number;
  lineTotal: number;
  allocations: BatchAllocation[];
}

export interface Payment {
  method: string;
  amount: number;
  reference?: string;
  date: string;
}

export interface StockAdjustment {
  _id: string;
  medicineId: string;
  batchId: string;
  type: 'dispense' | 'sale' | 'adjustment' | 'receive' | 'return';
  quantityChange: number;
  reason?: string;
  referenceId?: string;
  referenceType?: string;
  createdBy: string;
  createdAt: string;
}

export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'admin' | 'pharmacist' | 'cashier';
}

export interface ClinicSettings {
  name: string;
  logo?: string;
  taxRate: number;
  currency: string;
  expiryWarningDays: number;
}
