import { Category, DosageForm, Supplier, Location, Medicine, Batch, User, ClinicSettings } from './types';
import { writeCollection } from './storage';

export function initializeSeedData(): void {
  const categories: Category[] = [
    { _id: 'cat-1', name: 'Analgesics', description: 'Pain relievers' },
    { _id: 'cat-2', name: 'Antibiotics', description: 'Bacterial infection treatment' },
    { _id: 'cat-3', name: 'Antacids', description: 'Stomach acid reducers' },
    { _id: 'cat-4', name: 'Antihistamines', description: 'Allergy medications' },
  ];

  const dosageForms: DosageForm[] = [
    { _id: 'form-1', name: 'Tablet' },
    { _id: 'form-2', name: 'Capsule' },
    { _id: 'form-3', name: 'Syrup' },
    { _id: 'form-4', name: 'Injection' },
    { _id: 'form-5', name: 'Cream' },
  ];

  const suppliers: Supplier[] = [
    { _id: 'sup-1', name: 'Acme Pharma', contact: 'John Doe', phone: '123-456-7890', email: 'sales@acmepharma.com' },
    { _id: 'sup-2', name: 'MediSupply Co.', contact: 'Jane Smith', phone: '098-765-4321', email: 'info@medisupply.com' },
  ];

  const locations: Location[] = [
    { _id: 'loc-1', name: 'Main Pharmacy', description: 'Ground floor storage' },
    { _id: 'loc-2', name: 'Refrigerated', description: 'Cold storage unit' },
  ];

  const medicines: Medicine[] = [
    {
      _id: 'med-1',
      name: 'Paracetamol 500mg',
      code: 'PARA500',
      brand: 'Panadol',
      categoryId: 'cat-1',
      dosageFormId: 'form-1',
      defaultUnit: 'tablet',
      packSize: { qty: 10, unit: 'tablet' },
      defaultUnitPrice: 2.50,
      defaultReorderLevel: 100,
      defaultSupplierId: 'sup-1',
      barcode: '8901234567890',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      _id: 'med-2',
      name: 'Amoxicillin 250mg',
      code: 'AMOX250',
      brand: 'Amoxil',
      categoryId: 'cat-2',
      dosageFormId: 'form-2',
      defaultUnit: 'capsule',
      packSize: { qty: 20, unit: 'capsule' },
      defaultUnitPrice: 5.00,
      defaultReorderLevel: 50,
      defaultSupplierId: 'sup-1',
      barcode: '8901234567891',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      _id: 'med-3',
      name: 'Omeprazole 20mg',
      code: 'OMEP20',
      brand: 'Losec',
      categoryId: 'cat-3',
      dosageFormId: 'form-2',
      defaultUnit: 'capsule',
      packSize: { qty: 14, unit: 'capsule' },
      defaultUnitPrice: 8.50,
      defaultReorderLevel: 30,
      defaultSupplierId: 'sup-2',
      barcode: '8901234567892',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      _id: 'med-4',
      name: 'Cetirizine 10mg',
      code: 'CETIR10',
      brand: 'Zyrtec',
      categoryId: 'cat-4',
      dosageFormId: 'form-1',
      defaultUnit: 'tablet',
      packSize: { qty: 10, unit: 'tablet' },
      defaultUnitPrice: 3.00,
      defaultReorderLevel: 20,
      defaultSupplierId: 'sup-2',
      barcode: '8901234567893',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];

  const batches: Batch[] = [
    {
      _id: 'batch-1',
      medicineId: 'med-1',
      batchNumber: 'P500-2025-01',
      expiryDate: '2026-12-31T00:00:00Z',
      quantity: 500,
      unitCost: 1.50,
      locationId: 'loc-1',
      supplierId: 'sup-1',
      receivedDate: '2025-01-15T00:00:00Z',
      status: 'available',
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'batch-2',
      medicineId: 'med-2',
      batchNumber: 'A250-2025-02',
      expiryDate: '2026-06-30T00:00:00Z',
      quantity: 200,
      unitCost: 3.50,
      locationId: 'loc-1',
      supplierId: 'sup-1',
      receivedDate: '2025-02-01T00:00:00Z',
      status: 'available',
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'batch-3',
      medicineId: 'med-3',
      batchNumber: 'O20-2025-03',
      expiryDate: '2025-12-31T00:00:00Z',
      quantity: 50,
      unitCost: 6.00,
      locationId: 'loc-1',
      supplierId: 'sup-2',
      receivedDate: '2025-03-01T00:00:00Z',
      status: 'available',
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'batch-4',
      medicineId: 'med-4',
      batchNumber: 'C10-2025-04',
      expiryDate: '2025-11-30T00:00:00Z',
      quantity: 15,
      unitCost: 2.00,
      locationId: 'loc-1',
      supplierId: 'sup-2',
      receivedDate: '2025-04-01T00:00:00Z',
      status: 'available',
      createdAt: new Date().toISOString(),
    },
  ];

  const users: User[] = [
    { _id: 'user-1', name: 'Admin User', email: 'admin@clinic.com', role: 'admin' },
    { _id: 'user-2', name: 'Pharmacist', email: 'pharmacist@clinic.com', role: 'pharmacist' },
  ];

  const settings: ClinicSettings[] = [
    {
      name: 'HealthCare Clinic',
      taxRate: 5,
      currency: 'USD',
      expiryWarningDays: 90,
    },
  ];

  writeCollection('categories', categories);
  writeCollection('dosageForms', dosageForms);
  writeCollection('suppliers', suppliers);
  writeCollection('locations', locations);
  writeCollection('medicines', medicines);
  writeCollection('batches', batches);
  writeCollection('users', users);
  writeCollection('settings', settings);
  writeCollection('patients', []);
  writeCollection('dispenses', []);
  writeCollection('invoices', []);
  writeCollection('stockAdjustments', []);
}
