const COOKIE_PREFIX = 'va_';
const COOKIE_MAX_AGE = 2592000;
const MAX_COOKIE_SIZE = 3000;

export type StorageMode = 'cookies' | 'localStorage';

let currentMode: StorageMode = 'cookies';
let modeWarning = '';

export function getStorageMode(): { mode: StorageMode; warning: string } {
  return { mode: currentMode, warning: modeWarning };
}

export function setStorageMode(mode: StorageMode): void {
  currentMode = mode;
}

function getCookieValue(name: string): string | null {
  const nameEQ = name + '=';
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) {
      return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
  }
  return null;
}

function setCookieValue(name: string, value: string): boolean {
  try {
    const encoded = encodeURIComponent(value);
    if (encoded.length > MAX_COOKIE_SIZE) {
      return false;
    }
    document.cookie = `${name}=${encoded}; path=/; max-age=${COOKIE_MAX_AGE}`;
    return true;
  } catch (e) {
    return false;
  }
}

export function readCollection<T>(name: string): T[] {
  const key = COOKIE_PREFIX + name;

  try {
    let data: string | null = null;

    if (currentMode === 'cookies') {
      data = getCookieValue(key);
      if (!data) {
        data = localStorage.getItem(key);
      }
    } else {
      data = localStorage.getItem(key);
    }

    if (!data) return [];
    return JSON.parse(data) as T[];
  } catch (e) {
    console.error(`Error reading collection ${name}:`, e);
    return [];
  }
}

export function writeCollection<T>(name: string, data: T[]): { success: boolean; mode: StorageMode; warning?: string } {
  const key = COOKIE_PREFIX + name;
  const json = JSON.stringify(data);

  try {
    if (currentMode === 'cookies') {
      const success = setCookieValue(key, json);
      if (success) {
        localStorage.removeItem(key);
        return { success: true, mode: 'cookies' };
      } else {
        localStorage.setItem(key, json);
        const warning = `Collection "${name}" exceeded cookie size limit and was stored in localStorage instead.`;
        modeWarning = warning;
        return { success: true, mode: 'localStorage', warning };
      }
    } else {
      localStorage.setItem(key, json);
      return { success: true, mode: 'localStorage' };
    }
  } catch (e) {
    console.error(`Error writing collection ${name}:`, e);
    return { success: false, mode: currentMode, warning: 'Failed to write data' };
  }
}

export function clearAllData(): void {
  const collections = [
    'medicines', 'batches', 'categories', 'dosageForms', 'suppliers',
    'locations', 'patients', 'dispenses', 'invoices', 'stockAdjustments',
    'users', 'settings'
  ];

  collections.forEach(name => {
    const key = COOKIE_PREFIX + name;
    document.cookie = `${key}=; path=/; max-age=0`;
    localStorage.removeItem(key);
  });

  modeWarning = '';
}

export function exportAllData(): string {
  const collections = [
    'medicines', 'batches', 'categories', 'dosageForms', 'suppliers',
    'locations', 'patients', 'dispenses', 'invoices', 'stockAdjustments',
    'users', 'settings'
  ];

  const exportData: Record<string, unknown[]> = {};
  collections.forEach(name => {
    exportData[name] = readCollection(name);
  });

  return JSON.stringify(exportData, null, 2);
}

export function importAllData(json: string, mode: StorageMode): { success: boolean; error?: string } {
  try {
    const data = JSON.parse(json);
    const oldMode = currentMode;
    currentMode = mode;

    for (const [collectionName, items] of Object.entries(data)) {
      if (Array.isArray(items)) {
        writeCollection(collectionName, items);
      }
    }

    return { success: true };
  } catch (e) {
    return { success: false, error: (e as Error).message };
  }
}
