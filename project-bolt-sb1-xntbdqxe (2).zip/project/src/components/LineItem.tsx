import React, { useState } from 'react';
import { Trash2, Package, Edit3, Calendar } from 'lucide-react';
import { LineItemData } from '../types';

interface LineItemProps {
  item: LineItemData;
  onUpdate: (updates: Partial<LineItemData>) => void;
  onRemove: () => void;
  onBatchSelect: () => void;
  lineTotal: number;
}

const LineItem: React.FC<LineItemProps> = ({ 
  item, 
  onUpdate, 
  onRemove, 
  onBatchSelect, 
  lineTotal 
}) => {
  const [isEditing, setIsEditing] = useState(false);

  const handleQuantityChange = (quantity: number) => {
    if (quantity > 0 && quantity <= item.medicine.availableQty) {
      onUpdate({ quantity });
    }
  };

  const handleDiscountChange = (discount: number, discountType: 'amount' | 'percent') => {
    onUpdate({ discount, discountType });
  };

  const getBatchInfo = () => {
    if (item.selectedBatches.length === 0) {
      return 'Auto (FEFO)';
    }
    return item.selectedBatches.map(b => `${b.batch} (${b.quantity})`).join(', ');
  };

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
      <div className="grid grid-cols-12 gap-4 items-start">
        {/* Medicine Info */}
        <div className="col-span-12 md:col-span-4">
          <div className="flex items-start gap-3">
            <Package className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="min-w-0 flex-1">
              <h4 className="font-medium text-gray-900 truncate">{item.medicine.name}</h4>
              <p className="text-sm text-gray-600 truncate">{item.medicine.strength}</p>
              <p className="text-xs text-gray-500">{item.medicine.manufacturer}</p>
              <button
                onClick={onBatchSelect}
                className="text-xs text-blue-600 hover:text-blue-700 mt-1 flex items-center gap-1"
              >
                <Calendar className="h-3 w-3" />
                {getBatchInfo()}
              </button>
            </div>
          </div>
        </div>

        {/* Quantity */}
        <div className="col-span-6 md:col-span-1">
          <label className="block text-xs text-gray-500 mb-1">Qty</label>
          <input
            type="number"
            min="1"
            max={item.medicine.availableQty}
            value={item.quantity}
            onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
            className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
          />
        </div>

        {/* Unit Price */}
        <div className="col-span-6 md:col-span-1">
          <label className="block text-xs text-gray-500 mb-1">Price</label>
          <div className="relative">
            {isEditing ? (
              <input
                type="number"
                step="0.01"
                value={item.unitPrice}
                onChange={(e) => onUpdate({ unitPrice: parseFloat(e.target.value) || 0 })}
                onBlur={() => setIsEditing(false)}
                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500"
                autoFocus
              />
            ) : (
              <div 
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-1 cursor-pointer hover:bg-gray-100 px-2 py-1 rounded"
              >
                <span className="text-sm">₹{item.unitPrice}</span>
                <Edit3 className="h-3 w-3 text-gray-400" />
              </div>
            )}
          </div>
        </div>

        {/* Discount */}
        <div className="col-span-6 md:col-span-2">
          <label className="block text-xs text-gray-500 mb-1">Discount</label>
          <div className="flex">
            <input
              type="number"
              step="0.01"
              value={item.discount}
              onChange={(e) => handleDiscountChange(parseFloat(e.target.value) || 0, item.discountType)}
              className="w-20 px-2 py-1 text-sm border border-gray-300 rounded-l focus:ring-1 focus:ring-blue-500"
            />
            <select
              value={item.discountType}
              onChange={(e) => handleDiscountChange(item.discount, e.target.value as 'amount' | 'percent')}
              className="px-2 py-1 text-sm border-t border-r border-b border-gray-300 rounded-r focus:ring-1 focus:ring-blue-500"
            >
              <option value="amount">₹</option>
              <option value="percent">%</option>
            </select>
          </div>
        </div>

        {/* Tax */}
        <div className="col-span-6 md:col-span-1">
          <label className="block text-xs text-gray-500 mb-1">Tax %</label>
          <input
            type="number"
            step="0.01"
            value={item.tax}
            onChange={(e) => onUpdate({ tax: parseFloat(e.target.value) || 0 })}
            className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500"
          />
        </div>

        {/* Total */}
        <div className="col-span-8 md:col-span-2">
          <label className="block text-xs text-gray-500 mb-1">Total</label>
          <div className="text-sm font-semibold text-blue-600 py-1">
            ₹{lineTotal.toFixed(2)}
          </div>
        </div>

        {/* Remove */}
        <div className="col-span-4 md:col-span-1 flex justify-end">
          <button
            onClick={onRemove}
            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default LineItem;