import React, { useState, useEffect } from 'react';
import { X, Calendar, Package, AlertTriangle, CheckCircle } from 'lucide-react';
import { Medicine, Batch, BatchSelection } from '../types';

interface BatchModalProps {
  medicine: Medicine;
  batches: Batch[];
  requiredQuantity: number;
  currentSelection: BatchSelection[];
  onSave: (batches: BatchSelection[]) => void;
  onClose: () => void;
}

const BatchModal: React.FC<BatchModalProps> = ({
  medicine,
  batches,
  requiredQuantity,
  currentSelection,
  onSave,
  onClose,
}) => {
  const [selectedBatches, setSelectedBatches] = useState<BatchSelection[]>(currentSelection);
  const [useAutoSelection, setUseAutoSelection] = useState(currentSelection.length === 0);

  // Sort batches by expiry date for FEFO
  const sortedBatches = [...batches].sort((a, b) => 
    new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()
  );

  useEffect(() => {
    if (useAutoSelection) {
      autoSelectBatches();
    }
  }, [useAutoSelection, requiredQuantity]);

  const autoSelectBatches = () => {
    const selections: BatchSelection[] = [];
    let remainingQty = requiredQuantity;

    for (const batch of sortedBatches) {
      if (remainingQty <= 0) break;
      
      const qtyFromBatch = Math.min(remainingQty, batch.availableQty);
      if (qtyFromBatch > 0) {
        selections.push({
          batch: batch.batchNumber,
          quantity: qtyFromBatch,
          expiryDate: batch.expiryDate,
        });
        remainingQty -= qtyFromBatch;
      }
    }

    setSelectedBatches(selections);
  };

  const updateBatchQuantity = (batchNumber: string, quantity: number) => {
    const batch = batches.find(b => b.batchNumber === batchNumber);
    if (!batch) return;

    const maxQty = batch.availableQty;
    const validQty = Math.max(0, Math.min(quantity, maxQty));

    if (validQty === 0) {
      setSelectedBatches(prev => prev.filter(s => s.batch !== batchNumber));
    } else {
      setSelectedBatches(prev => {
        const existing = prev.find(s => s.batch === batchNumber);
        if (existing) {
          return prev.map(s => 
            s.batch === batchNumber 
              ? { ...s, quantity: validQty }
              : s
          );
        } else {
          return [...prev, {
            batch: batchNumber,
            quantity: validQty,
            expiryDate: batch.expiryDate,
          }];
        }
      });
    }
  };

  const getTotalSelected = () => {
    return selectedBatches.reduce((total, selection) => total + selection.quantity, 0);
  };

  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate);
    const today = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30;
  };

  const isExpired = (expiryDate: string) => {
    const expiry = new Date(expiryDate);
    const today = new Date();
    return expiry < today;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            Select Batches - {medicine.name}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-gray-600">Required Quantity: {requiredQuantity}</p>
                <p className="text-sm text-gray-600">Selected: {getTotalSelected()}</p>
                {getTotalSelected() !== requiredQuantity && (
                  <p className="text-sm text-red-600">
                    Remaining: {Math.max(0, requiredQuantity - getTotalSelected())}
                  </p>
                )}
              </div>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={useAutoSelection}
                  onChange={(e) => setUseAutoSelection(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                />
                <span className="text-sm text-gray-700">Auto-select (FEFO)</span>
              </label>
            </div>

            {getTotalSelected() === requiredQuantity && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="text-sm text-green-700">Batch selection complete</span>
              </div>
            )}
          </div>

          <div className="space-y-3">
            {sortedBatches.map((batch) => {
              const selection = selectedBatches.find(s => s.batch === batch.batchNumber);
              const selectedQty = selection?.quantity || 0;
              const isExpiredBatch = isExpired(batch.expiryDate);
              const isExpiringSoonBatch = isExpiringSoon(batch.expiryDate);

              return (
                <div
                  key={batch.batchNumber}
                  className={`border rounded-lg p-4 ${
                    isExpiredBatch 
                      ? 'bg-red-50 border-red-200' 
                      : isExpiringSoonBatch 
                        ? 'bg-amber-50 border-amber-200'
                        : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4 text-gray-600" />
                        <h4 className="font-medium text-gray-900">Batch {batch.batchNumber}</h4>
                        {isExpiredBatch && (
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                        )}
                        {isExpiringSoonBatch && !isExpiredBatch && (
                          <AlertTriangle className="h-4 w-4 text-amber-600" />
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>Exp: {new Date(batch.expiryDate).toLocaleDateString()}</span>
                        </div>
                        <span>Available: {batch.availableQty}</span>
                        <span>Price: ₹{batch.unitPrice}</span>
                      </div>

                      {isExpiredBatch && (
                        <p className="text-xs text-red-600 mt-1">⚠️ This batch has expired</p>
                      )}
                      {isExpiringSoonBatch && !isExpiredBatch && (
                        <p className="text-xs text-amber-600 mt-1">⚠️ Expires within 30 days</p>
                      )}
                    </div>

                    <div className="ml-4">
                      <input
                        type="number"
                        min="0"
                        max={batch.availableQty}
                        value={selectedQty}
                        onChange={(e) => updateBatchQuantity(batch.batchNumber, parseInt(e.target.value) || 0)}
                        disabled={useAutoSelection || isExpiredBatch}
                        className="w-20 px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex justify-end gap-2 p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(selectedBatches)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Save Selection
          </button>
        </div>
      </div>
    </div>
  );
};

export default BatchModal;