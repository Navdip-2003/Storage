import React, { useState } from 'react';
import { Plus, Search, Calendar, MapPin, CreditCard, FileText, Printer, Save, X } from 'lucide-react';
import MedicineSearch from './MedicineSearch';
import LineItem from './LineItem';
import PatientSearch from './PatientSearch';
import BatchModal from './BatchModal';
import { Medicine, Patient, LineItemData, Batch } from '../types';
import { mockMedicines, mockPatients, mockBatches } from '../data/mockData';

const BillingApp: React.FC = () => {
  const [lineItems, setLineItems] = useState<LineItemData[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().slice(0, 16));
  const [location, setLocation] = useState('Main Store');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [currentLineIndex, setCurrentLineIndex] = useState(-1);
  const [isSaving, setIsSaving] = useState(false);

  const addLineItem = (medicine: Medicine) => {
    const newItem: LineItemData = {
      id: Date.now(),
      medicine,
      quantity: 1,
      unitPrice: medicine.defaultUnitPrice,
      discount: 0,
      discountType: 'amount',
      tax: medicine.tax,
      selectedBatches: [],
    };
    setLineItems([...lineItems, newItem]);
  };

  const updateLineItem = (id: number, updates: Partial<LineItemData>) => {
    setLineItems(lineItems.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const removeLineItem = (id: number) => {
    setLineItems(lineItems.filter(item => item.id !== id));
  };

  const openBatchModal = (lineIndex: number) => {
    setCurrentLineIndex(lineIndex);
    setShowBatchModal(true);
  };

  const calculateLineTotal = (item: LineItemData) => {
    const baseAmount = item.quantity * item.unitPrice;
    const discountAmount = item.discountType === 'percent' 
      ? (baseAmount * item.discount / 100)
      : item.discount;
    const afterDiscount = baseAmount - discountAmount;
    const taxAmount = afterDiscount * item.tax / 100;
    return afterDiscount + taxAmount;
  };

  const subtotal = lineItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const totalDiscount = lineItems.reduce((sum, item) => {
    const baseAmount = item.quantity * item.unitPrice;
    return sum + (item.discountType === 'percent' 
      ? (baseAmount * item.discount / 100)
      : item.discount);
  }, 0);
  const totalTax = lineItems.reduce((sum, item) => {
    const baseAmount = item.quantity * item.unitPrice;
    const discountAmount = item.discountType === 'percent' 
      ? (baseAmount * item.discount / 100)
      : item.discount;
    const afterDiscount = baseAmount - discountAmount;
    return sum + (afterDiscount * item.tax / 100);
  }, 0);
  const grandTotal = subtotal - totalDiscount + totalTax;

  const handleSaveAndPrint = async () => {
    if (lineItems.length === 0) {
      alert('Please add at least one medicine to the bill');
      return;
    }

    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const billData = {
      patient: selectedPatient,
      items: lineItems,
      invoiceDate,
      location,
      paymentMethod,
      paymentAmount: paymentAmount || grandTotal.toString(),
      notes,
      subtotal,
      totalDiscount,
      totalTax,
      grandTotal,
      status: 'paid'
    };
    
    console.log('Saving and printing bill:', billData);
    
    // Simulate printing
    window.print();
    
    // Reset form after successful save
    resetForm();
    setIsSaving(false);
    alert('Bill saved and sent to printer successfully!');
  };

  const handleSaveUnpaid = async () => {
    if (lineItems.length === 0) {
      alert('Please add at least one medicine to the bill');
      return;
    }

    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const billData = {
      patient: selectedPatient,
      items: lineItems,
      invoiceDate,
      location,
      paymentMethod,
      paymentAmount: paymentAmount || '0',
      notes,
      subtotal,
      totalDiscount,
      totalTax,
      grandTotal,
      status: 'unpaid'
    };
    
    console.log('Saving unpaid bill:', billData);
    
    // Reset form after successful save
    resetForm();
    setIsSaving(false);
    alert('Bill saved as unpaid successfully!');
  };

  const handleCancel = () => {
    if (lineItems.length > 0 || selectedPatient || notes) {
      const confirmCancel = window.confirm('Are you sure you want to cancel? All unsaved changes will be lost.');
      if (!confirmCancel) return;
    }
    
    resetForm();
  };

  const resetForm = () => {
    setLineItems([]);
    setSelectedPatient(null);
    setInvoiceDate(new Date().toISOString().slice(0, 16));
    setLocation('Main Store');
    setPaymentMethod('cash');
    setPaymentAmount('');
    setNotes('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Create New Bill</h1>
          <p className="text-gray-600">Add medicines, select patient, and process payment</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Medicine Search */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Search className="h-5 w-5 mr-2 text-blue-600" />
                Add Medicine
              </h2>
              <MedicineSearch medicines={mockMedicines} onSelect={addLineItem} />
            </div>

            {/* Line Items */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <FileText className="h-5 w-5 mr-2 text-blue-600" />
                Bill Items
              </h2>
              
              {lineItems.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>No items added yet. Search and add medicines above.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {lineItems.map((item, index) => (
                    <LineItem
                      key={item.id}
                      item={item}
                      onUpdate={(updates) => updateLineItem(item.id, updates)}
                      onRemove={() => removeLineItem(item.id)}
                      onBatchSelect={() => openBatchModal(index)}
                      lineTotal={calculateLineTotal(item)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Patient & Invoice Details */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Invoice Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Patient
                  </label>
                  <PatientSearch
                    patients={mockPatients}
                    selectedPatient={selectedPatient}
                    onSelect={setSelectedPatient}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Calendar className="inline h-4 w-4 mr-1" />
                    Invoice Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <MapPin className="inline h-4 w-4 mr-1" />
                    Location
                  </label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="Main Store">Main Store</option>
                    <option value="Branch 1">Branch 1</option>
                    <option value="Branch 2">Branch 2</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <CreditCard className="inline h-4 w-4 mr-1" />
                    Payment Method
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="insurance">Insurance</option>
                    <option value="upi">UPI</option>
                  </select>
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Payment Amount
                </label>
                <input
                  type="number"
                  step="0.01"
                  placeholder={`₹${grandTotal.toFixed(2)} (Full Amount)`}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">Leave empty for full payment</p>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes
                </label>
                <textarea
                  rows={3}
                  placeholder="Additional notes or instructions..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Bill Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Bill Summary</h2>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">₹{subtotal.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Discount</span>
                  <span className="font-medium text-green-600">-₹{totalDiscount.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Tax</span>
                  <span className="font-medium">₹{totalTax.toFixed(2)}</span>
                </div>
                
                <hr className="my-3" />
                
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total</span>
                  <span className="text-blue-600">₹{grandTotal.toFixed(2)}</span>
                </div>

                {paymentAmount && parseFloat(paymentAmount) < grandTotal && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-700">Paid</span>
                      <span className="font-medium text-amber-700">₹{parseFloat(paymentAmount).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-700">Balance</span>
                      <span className="font-medium text-amber-700">₹{(grandTotal - parseFloat(paymentAmount)).toFixed(2)}</span>
                    </div>
                  </div>
                )}

                {selectedPatient && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-4">
                    <h4 className="font-medium text-blue-900">Patient Info</h4>
                    <p className="text-sm text-blue-700">{selectedPatient.name}</p>
                    <p className="text-xs text-blue-600">{selectedPatient.phone}</p>
                  </div>
                )}
              </div>

              <div className="mt-6 space-y-2">
                <button 
                  onClick={handleSaveAndPrint}
                  disabled={isSaving || lineItems.length === 0}
                  className="w-full bg-blue-600 text-white py-2.5 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                >
                  <Printer className="h-4 w-4 mr-2" />
                  {isSaving ? 'Saving...' : 'Save & Print'}
                </button>
                
                <button 
                  onClick={handleSaveUnpaid}
                  disabled={isSaving || lineItems.length === 0}
                  className="w-full bg-gray-600 text-white py-2.5 px-4 rounded-lg font-medium hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {isSaving ? 'Saving...' : 'Save (Unpaid)'}
                </button>
                
                <button 
                  onClick={handleCancel}
                  disabled={isSaving}
                  className="w-full bg-white text-gray-700 py-2.5 px-4 rounded-lg font-medium hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors border border-gray-300 flex items-center justify-center"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Batch Selection Modal */}
      {showBatchModal && currentLineIndex >= 0 && (
        <BatchModal
          medicine={lineItems[currentLineIndex].medicine}
          batches={mockBatches.filter(b => b.medicineId === lineItems[currentLineIndex].medicine.id)}
          requiredQuantity={lineItems[currentLineIndex].quantity}
          currentSelection={lineItems[currentLineIndex].selectedBatches}
          onSave={(batches) => {
            updateLineItem(lineItems[currentLineIndex].id, { selectedBatches: batches });
            setShowBatchModal(false);
          }}
          onClose={() => setShowBatchModal(false)}
        />
      )}
    </div>
  );
};

export default BillingApp;