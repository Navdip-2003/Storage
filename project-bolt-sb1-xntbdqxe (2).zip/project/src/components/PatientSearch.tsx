import React, { useState, useRef, useEffect } from 'react';
import { Search, User, Plus, Phone } from 'lucide-react';
import { Patient } from '../types';

interface PatientSearchProps {
  patients: Patient[];
  selectedPatient: Patient | null;
  onSelect: (patient: Patient | null) => void;
}

const PatientSearch: React.FC<PatientSearchProps> = ({ 
  patients, 
  selectedPatient, 
  onSelect 
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPatient, setNewPatient] = useState({ name: '', phone: '', email: '', address: '' });
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(query.toLowerCase()) ||
    patient.phone.includes(query) ||
    patient.email.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex(prev => 
            prev < filteredPatients.length - 1 ? prev + 1 : prev
          );
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex(prev => prev > 0 ? prev - 1 : prev);
          break;
        case 'Enter':
          e.preventDefault();
          if (selectedIndex >= 0) {
            handleSelect(filteredPatients[selectedIndex]);
          }
          break;
        case 'Escape':
          setIsOpen(false);
          setSelectedIndex(-1);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, filteredPatients]);

  const handleSelect = (patient: Patient) => {
    onSelect(patient);
    setQuery(patient.name);
    setIsOpen(false);
    setSelectedIndex(-1);
  };

  const handleAddPatient = () => {
    const patient: Patient = {
      id: Date.now(),
      name: newPatient.name,
      phone: newPatient.phone,
      email: newPatient.email,
      address: newPatient.address,
    };
    onSelect(patient);
    setQuery(patient.name);
    setShowAddForm(false);
    setNewPatient({ name: '', phone: '', email: '', address: '' });
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <User className="h-4 w-4 text-gray-400" />
        </div>
        <input
          ref={inputRef}
          type="text"
          placeholder="Search patient by name, phone, or email..."
          value={selectedPatient ? selectedPatient.name : query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
            setSelectedIndex(-1);
            if (selectedPatient && e.target.value !== selectedPatient.name) {
              onSelect(null);
            }
          }}
          onFocus={() => {
            setIsOpen(true);
            if (selectedPatient) {
              setQuery('');
              onSelect(null);
            }
          }}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      {isOpen && !selectedPatient && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto">
          {!showAddForm ? (
            <>
              <button
                onClick={() => setShowAddForm(true)}
                className="w-full p-3 text-left hover:bg-gray-50 border-b border-gray-100 flex items-center gap-2 text-blue-600"
              >
                <Plus className="h-4 w-4" />
                Add New Patient
              </button>
              
              {filteredPatients.length > 0 ? (
                filteredPatients.map((patient, index) => (
                  <div
                    key={patient.id}
                    onClick={() => handleSelect(patient)}
                    className={`p-3 cursor-pointer border-b border-gray-100 last:border-b-0 hover:bg-gray-50 ${
                      index === selectedIndex ? 'bg-blue-50 border-blue-200' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-gray-900">{patient.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Phone className="h-3 w-3 text-gray-400" />
                          <span className="text-sm text-gray-600">{patient.phone}</span>
                        </div>
                        {patient.email && (
                          <p className="text-xs text-gray-500 mt-1">{patient.email}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : query && (
                <div className="p-4 text-center text-gray-500">
                  No patients found matching your search
                </div>
              )}
            </>
          ) : (
            <div className="p-4">
              <h4 className="font-medium text-gray-900 mb-3">Add New Patient</h4>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Full Name *"
                  value={newPatient.name}
                  onChange={(e) => setNewPatient({ ...newPatient, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="tel"
                  placeholder="Phone Number *"
                  value={newPatient.phone}
                  onChange={(e) => setNewPatient({ ...newPatient, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="email"
                  placeholder="Email (Optional)"
                  value={newPatient.email}
                  onChange={(e) => setNewPatient({ ...newPatient, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <textarea
                  placeholder="Address (Optional)"
                  rows={2}
                  value={newPatient.address}
                  onChange={(e) => setNewPatient({ ...newPatient, address: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex gap-2">
                  <button
                    onClick={handleAddPatient}
                    disabled={!newPatient.name || !newPatient.phone}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Add Patient
                  </button>
                  <button
                    onClick={() => {
                      setShowAddForm(false);
                      setNewPatient({ name: '', phone: '', email: '', address: '' });
                    }}
                    className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PatientSearch;