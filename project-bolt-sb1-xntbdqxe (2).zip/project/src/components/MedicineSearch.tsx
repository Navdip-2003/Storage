import React, { useState, useRef, useEffect } from 'react';
import { Search, Scan, Package } from 'lucide-react';
import { Medicine } from '../types';

interface MedicineSearchProps {
  medicines: Medicine[];
  onSelect: (medicine: Medicine) => void;
}

const MedicineSearch: React.FC<MedicineSearchProps> = ({ medicines, onSelect }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredMedicines = medicines.filter(medicine =>
    medicine.name.toLowerCase().includes(query.toLowerCase()) ||
    medicine.genericName.toLowerCase().includes(query.toLowerCase()) ||
    medicine.manufacturer.toLowerCase().includes(query.toLowerCase()) ||
    medicine.barcode.includes(query)
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex(prev => 
            prev < filteredMedicines.length - 1 ? prev + 1 : prev
          );
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex(prev => prev > 0 ? prev - 1 : prev);
          break;
        case 'Enter':
          e.preventDefault();
          if (selectedIndex >= 0) {
            handleSelect(filteredMedicines[selectedIndex]);
          }
          break;
        case 'Escape':
          setIsOpen(false);
          setSelectedIndex(-1);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, filteredMedicines]);

  const handleSelect = (medicine: Medicine) => {
    onSelect(medicine);
    setQuery('');
    setIsOpen(false);
    setSelectedIndex(-1);
    inputRef.current?.focus();
  };

  const simulateBarcodeScan = () => {
    const randomMedicine = medicines[Math.floor(Math.random() * medicines.length)];
    setQuery(randomMedicine.barcode);
    setTimeout(() => {
      handleSelect(randomMedicine);
    }, 500);
  };

  return (
    <div className="relative">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            ref={inputRef}
            type="text"
            placeholder="Search medicine by name, generic, manufacturer, or scan barcode..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setIsOpen(true);
              setSelectedIndex(-1);
            }}
            onFocus={() => setIsOpen(true)}
            className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <button
          onClick={simulateBarcodeScan}
          className="px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
        >
          <Scan className="h-4 w-4" />
          Scan
        </button>
      </div>

      {isOpen && query && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto">
          {filteredMedicines.length > 0 ? (
            filteredMedicines.map((medicine, index) => (
              <div
                key={medicine.id}
                onClick={() => handleSelect(medicine)}
                className={`p-3 cursor-pointer border-b border-gray-100 last:border-b-0 hover:bg-gray-50 ${
                  index === selectedIndex ? 'bg-blue-50 border-blue-200' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-blue-600" />
                      <h4 className="font-medium text-gray-900">{medicine.name}</h4>
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                        {medicine.strength}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{medicine.genericName}</p>
                    <p className="text-xs text-gray-500">{medicine.manufacturer}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <span className="text-xs text-gray-500">Stock: {medicine.availableQty}</span>
                      <span className="text-xs text-gray-500">Barcode: {medicine.barcode}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-blue-600">₹{medicine.defaultUnitPrice}</p>
                    <p className="text-xs text-gray-500">per {medicine.unit}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">
              No medicines found matching your search
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MedicineSearch;