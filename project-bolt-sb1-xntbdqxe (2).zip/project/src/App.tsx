import React from 'react';
import BillingApp from './components/BillingApp';

function App() {
  return <BillingApp />;
}

export default App;