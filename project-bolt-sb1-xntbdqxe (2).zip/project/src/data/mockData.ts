import { Medicine, Patient, Batch } from '../types';

export const mockMedicines: Medicine[] = [
  {
    id: 1,
    name: "Paracetamol",
    genericName: "Acetaminophen",
    strength: "500mg",
    manufacturer: "Cipla Ltd",
    unit: "tablet",
    defaultUnitPrice: 2.50,
    availableQty: 500,
    tax: 5,
    barcode: "8901234567890"
  },
  {
    id: 2,
    name: "Amoxicillin",
    genericName: "Amoxicillin Trihydrate",
    strength: "250mg",
    manufacturer: "Sun Pharma",
    unit: "capsule",
    defaultUnitPrice: 8.75,
    availableQty: 200,
    tax: 12,
    barcode: "8901234567891"
  },
  {
    id: 3,
    name: "Cetirizine",
    genericName: "Cetirizine Hydrochloride",
    strength: "10mg",
    manufacturer: "Dr. Reddy's",
    unit: "tablet",
    defaultUnitPrice: 3.25,
    availableQty: 300,
    tax: 5,
    barcode: "8901234567892"
  },
  {
    id: 4,
    name: "Omeprazole",
    genericName: "Omeprazole Magnesium",
    strength: "20mg",
    manufacturer: "Lupin",
    unit: "capsule",
    defaultUnitPrice: 12.00,
    availableQty: 150,
    tax: 12,
    barcode: "8901234567893"
  },
  {
    id: 5,
    name: "Ibuprofen",
    genericName: "Ibuprofen",
    strength: "400mg",
    manufacturer: "Ranbaxy",
    unit: "tablet",
    defaultUnitPrice: 4.50,
    availableQty: 250,
    tax: 5,
    barcode: "8901234567894"
  },
  {
    id: 6,
    name: "Metformin",
    genericName: "Metformin Hydrochloride",
    strength: "500mg",
    manufacturer: "Torrent Pharma",
    unit: "tablet",
    defaultUnitPrice: 6.25,
    availableQty: 400,
    tax: 5,
    barcode: "8901234567895"
  },
  {
    id: 7,
    name: "Azithromycin",
    genericName: "Azithromycin Dihydrate",
    strength: "250mg",
    manufacturer: "Zydus Cadila",
    unit: "tablet",
    defaultUnitPrice: 15.50,
    availableQty: 100,
    tax: 12,
    barcode: "8901234567896"
  },
  {
    id: 8,
    name: "Losartan",
    genericName: "Losartan Potassium",
    strength: "50mg",
    manufacturer: "Aurobindo Pharma",
    unit: "tablet",
    defaultUnitPrice: 9.75,
    availableQty: 180,
    tax: 5,
    barcode: "8901234567897"
  }
];

export const mockPatients: Patient[] = [
  {
    id: 1,
    name: "Rajesh Kumar",
    phone: "+91 9876543210",
    email: "rajesh.kumar@email.com",
    address: "123 MG Road, Bangalore, Karnataka"
  },
  {
    id: 2,
    name: "Priya Sharma",
    phone: "+91 9876543211",
    email: "priya.sharma@email.com",
    address: "456 Park Street, Kolkata, West Bengal"
  },
  {
    id: 3,
    name: "Mohammed Ali",
    phone: "+91 9876543212",
    email: "mohammed.ali@email.com",
    address: "789 Linking Road, Mumbai, Maharashtra"
  },
  {
    id: 4,
    name: "Sunita Devi",
    phone: "+91 9876543213",
    email: "sunita.devi@email.com",
    address: "321 CP Road, New Delhi"
  },
  {
    id: 5,
    name: "Arjun Reddy",
    phone: "+91 9876543214",
    email: "arjun.reddy@email.com",
    address: "654 Tank Bund Road, Hyderabad, Telangana"
  }
];

export const mockBatches: Batch[] = [
  // Paracetamol batches
  {
    id: 1,
    medicineId: 1,
    batchNumber: "PAR001",
    expiryDate: "2025-12-31",
    availableQty: 200,
    unitPrice: 2.50
  },
  {
    id: 2,
    medicineId: 1,
    batchNumber: "PAR002",
    expiryDate: "2026-06-30",
    availableQty: 300,
    unitPrice: 2.50
  },
  // Amoxicillin batches
  {
    id: 3,
    medicineId: 2,
    batchNumber: "AMX001",
    expiryDate: "2025-08-15",
    availableQty: 100,
    unitPrice: 8.75
  },
  {
    id: 4,
    medicineId: 2,
    batchNumber: "AMX002",
    expiryDate: "2026-02-28",
    availableQty: 100,
    unitPrice: 8.75
  },
  // Cetirizine batches
  {
    id: 5,
    medicineId: 3,
    batchNumber: "CET001",
    expiryDate: "2025-10-20",
    availableQty: 150,
    unitPrice: 3.25
  },
  {
    id: 6,
    medicineId: 3,
    batchNumber: "CET002",
    expiryDate: "2026-04-15",
    availableQty: 150,
    unitPrice: 3.25
  },
  // Omeprazole batches
  {
    id: 7,
    medicineId: 4,
    batchNumber: "OME001",
    expiryDate: "2025-09-30",
    availableQty: 75,
    unitPrice: 12.00
  },
  {
    id: 8,
    medicineId: 4,
    batchNumber: "OME002",
    expiryDate: "2026-03-31",
    availableQty: 75,
    unitPrice: 12.00
  },
  // Ibuprofen batches with one expiring soon
  {
    id: 9,
    medicineId: 5,
    batchNumber: "IBU001",
    expiryDate: "2025-02-28",
    availableQty: 100,
    unitPrice: 4.50
  },
  {
    id: 10,
    medicineId: 5,
    batchNumber: "IBU002",
    expiryDate: "2026-08-31",
    availableQty: 150,
    unitPrice: 4.50
  }
];