export interface Medicine {
  id: number;
  name: string;
  genericName: string;
  strength: string;
  manufacturer: string;
  unit: string;
  defaultUnitPrice: number;
  availableQty: number;
  tax: number;
  barcode: string;
}

export interface Patient {
  id: number;
  name: string;
  phone: string;
  email: string;
  address: string;
}

export interface Batch {
  id: number;
  medicineId: number;
  batchNumber: string;
  expiryDate: string;
  availableQty: number;
  unitPrice: number;
}

export interface BatchSelection {
  batch: string;
  quantity: number;
  expiryDate: string;
}

export interface LineItemData {
  id: number;
  medicine: Medicine;
  quantity: number;
  unitPrice: number;
  discount: number;
  discountType: 'amount' | 'percent';
  tax: number;
  selectedBatches: BatchSelection[];
}