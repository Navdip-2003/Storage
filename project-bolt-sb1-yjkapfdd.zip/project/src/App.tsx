import React, { useState } from 'react';
import { BillTemplate } from './types';
import { mockTemplates } from './data/mockData';
import { useLocalStorage } from './hooks/useLocalStorage';
import { TemplateManager } from './components/TemplateManager/TemplateManager';
import { BillGenerator } from './components/BillGenerator/BillGenerator';
import { Button } from './components/ui/Button';
import { FileText, Settings, Activity } from 'lucide-react';

type ActiveTab = 'generator' | 'templates';

function App() {
  const [templates, setTemplates] = useLocalStorage<BillTemplate[]>('medicalBillTemplates', mockTemplates);
  const [activeTab, setActiveTab] = useState<ActiveTab>('generator');

  const activeTemplate = templates.find(t => t.isActive) || templates[0];

  const handleSaveTemplate = (template: BillTemplate) => {
    const existingIndex = templates.findIndex(t => t.id === template.id);
    
    if (existingIndex >= 0) {
      const updatedTemplates = [...templates];
      updatedTemplates[existingIndex] = template;
      setTemplates(updatedTemplates);
    } else {
      setTemplates([...templates, template]);
    }
  };

  const handleDeleteTemplate = (templateId: string) => {
    if (templates.length <= 1) {
      alert('Cannot delete the last template. At least one template is required.');
      return;
    }
    
    const templateToDelete = templates.find(t => t.id === templateId);
    if (templateToDelete?.isActive) {
      alert('Cannot delete the active template. Please set another template as active first.');
      return;
    }
    
    setTemplates(templates.filter(t => t.id !== templateId));
  };

  const handleSetActiveTemplate = (templateId: string) => {
    const updatedTemplates = templates.map(t => ({
      ...t,
      isActive: t.id === templateId
    }));
    setTemplates(updatedTemplates);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Activity className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">MedBill Pro</h1>
                <p className="text-xs text-gray-500">Medical Billing System</p>
              </div>
            </div>
            
            <nav className="flex items-center gap-2">
              <Button
                variant={activeTab === 'generator' ? 'primary' : 'ghost'}
                onClick={() => setActiveTab('generator')}
                icon={FileText}
              >
                Generate Bill
              </Button>
              <Button
                variant={activeTab === 'templates' ? 'primary' : 'ghost'}
                onClick={() => setActiveTab('templates')}
                icon={Settings}
              >
                Templates
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Status Bar */}
      <div className="bg-blue-50 border-b border-blue-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-4">
              <span className="text-blue-800">
                <span className="font-medium">Active Template:</span> {activeTemplate?.name || 'None'}
              </span>
              <span className="text-blue-600">
                Total Templates: {templates.length}
              </span>
            </div>
            <div className="text-blue-600">
              {activeTab === 'generator' ? 'Bill Generation Mode' : 'Template Management Mode'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto">
        {activeTab === 'generator' ? (
          <div className="h-[calc(100vh-120px)]">
            {activeTemplate ? (
              <BillGenerator activeTemplate={activeTemplate} />
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <Settings size={48} className="mx-auto text-gray-400 mb-4" />
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">No Active Template</h2>
                  <p className="text-gray-500 mb-6">Please create and set an active template first</p>
                  <Button
                    onClick={() => setActiveTab('templates')}
                    icon={Settings}
                  >
                    Go to Templates
                  </Button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-6">
            <TemplateManager
              templates={templates}
              onSave={handleSaveTemplate}
              onDelete={handleDeleteTemplate}
              onSetActive={handleSetActiveTemplate}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;