import { Medicine, Patient, Doctor, BillTemplate, TemplateField } from '../types';

export const mockMedicines: Medicine[] = [
  { id: '1', name: 'Paracetamol 500mg', price: 2.50, unit: 'tablet', category: 'Analgesic' },
  { id: '2', name: 'Amoxicillin 250mg', price: 12.00, unit: 'capsule', category: 'Antibiotic' },
  { id: '3', name: 'Ibuprofen 400mg', price: 3.75, unit: 'tablet', category: 'Anti-inflammatory' },
  { id: '4', name: 'Cetirizine 10mg', price: 1.25, unit: 'tablet', category: 'Antihistamine' },
  { id: '5', name: 'Metformin 500mg', price: 4.50, unit: 'tablet', category: 'Antidiabetic' },
  { id: '6', name: 'Amlodipine 5mg', price: 6.00, unit: 'tablet', category: 'Antihypertensive' },
  { id: '7', name: 'Omeprazole 20mg', price: 8.25, unit: 'capsule', category: 'Proton Pump Inhibitor' },
  { id: '8', name: 'Salbutamol Inhaler', price: 25.00, unit: 'inhaler', category: 'Bronchodilator' },
];

export const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'John Smith',
    phone: '+1-555-0123',
    email: 'john.smith@email.com',
    address: '123 Main St, Anytown, ST 12345',
    age: 35,
    gender: 'Male'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    phone: '+1-555-0456',
    email: 'sarah.j@email.com',
    address: '456 Oak Ave, Springfield, ST 67890',
    age: 28,
    gender: 'Female'
  }
];

export const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Emily Wilson',
    qualification: 'MBBS, MD',
    specialization: 'Internal Medicine',
    phone: '+1-555-0789',
    email: 'dr.wilson@clinic.com',
    registrationNumber: 'MED12345'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    qualification: 'MBBS, MS',
    specialization: 'General Surgery',
    phone: '+1-555-0321',
    email: 'dr.chen@clinic.com',
    registrationNumber: 'MED67890'
  }
];

const defaultFields: TemplateField[] = [
  {
    id: 'header',
    type: 'header',
    label: 'Header',
    visible: true,
    order: 0,
    config: { fontSize: 'xl', alignment: 'center', color: '#1f2937' }
  },
  {
    id: 'patient-info',
    type: 'patient-info',
    label: 'Patient Information',
    visible: true,
    order: 1
  },
  {
    id: 'doctor-info',
    type: 'doctor-info',
    label: 'Doctor Information',
    visible: true,
    order: 2
  },
  {
    id: 'medicine-table',
    type: 'medicine-table',
    label: 'Medicine Details',
    visible: true,
    order: 3
  },
  {
    id: 'totals',
    type: 'totals',
    label: 'Bill Summary',
    visible: true,
    order: 4
  },
  {
    id: 'footer',
    type: 'footer',
    label: 'Footer',
    visible: true,
    order: 5,
    config: { fontSize: 'sm', alignment: 'center', color: '#6b7280' }
  }
];

export const mockTemplates: BillTemplate[] = [
  {
    id: '1',
    name: 'Professional Template',
    fields: defaultFields,
    colorTheme: {
      primary: '#2563eb',
      secondary: '#0d9488',
      accent: '#059669',
      background: '#ffffff',
      text: '#1f2937'
    },
    branding: {
      clinicName: 'HealthCare Medical Center',
      address: '789 Medical Plaza, Healthcare City, HC 12345',
      phone: '+1-555-HEALTH',
      email: 'info@healthcare.com'
    },
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    name: 'Simple Template',
    fields: defaultFields.map(f => ({ ...f, id: f.id + '_2' })),
    colorTheme: {
      primary: '#7c3aed',
      secondary: '#db2777',
      accent: '#ea580c',
      background: '#fefefe',
      text: '#374151'
    },
    branding: {
      clinicName: 'City Medical Clinic',
      address: '456 Health Street, Medical District, MD 67890',
      phone: '+1-555-MEDICAL',
      email: 'contact@citymedical.com'
    },
    isActive: false,
    createdAt: new Date(),
    updatedAt: new Date()
  }
];