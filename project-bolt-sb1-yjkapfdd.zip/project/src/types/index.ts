export interface Medicine {
  id: string;
  name: string;
  price: number;
  unit: string;
  category: string;
}

export interface BillMedicine {
  id: string;
  medicine: Medicine;
  quantity: number;
  discount: number;
  tax: number;
  subtotal: number;
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
}

export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  specialization: string;
  phone: string;
  email: string;
  registrationNumber: string;
}

export interface TemplateField {
  id: string;
  type: 'patient-info' | 'doctor-info' | 'medicine-table' | 'totals' | 'custom-text' | 'header' | 'footer';
  label: string;
  visible: boolean;
  order: number;
  config?: {
    text?: string;
    fontSize?: 'sm' | 'base' | 'lg' | 'xl';
    color?: string;
    alignment?: 'left' | 'center' | 'right';
  };
}

export interface BillTemplate {
  id: string;
  name: string;
  fields: TemplateField[];
  colorTheme: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  branding: {
    logo?: string;
    clinicName: string;
    address: string;
    phone: string;
    email: string;
  };
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Bill {
  id: string;
  billNumber: string;
  patient: Patient;
  doctor: Doctor;
  medicines: BillMedicine[];
  template: BillTemplate;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  createdAt: Date;
}