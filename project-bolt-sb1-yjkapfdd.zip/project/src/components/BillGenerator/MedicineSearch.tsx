import React, { useState, useMemo } from 'react';
import { Medicine } from '../../types';
import { Search, Plus } from 'lucide-react';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

interface MedicineSearchProps {
  medicines: Medicine[];
  onSelect: (medicine: Medicine) => void;
}

export function MedicineSearch({ medicines, onSelect }: MedicineSearchProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const filteredMedicines = useMemo(() => {
    if (!searchTerm.trim()) return medicines;
    
    return medicines.filter(medicine =>
      medicine.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      medicine.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [medicines, searchTerm]);

  const handleSelect = (medicine: Medicine) => {
    onSelect(medicine);
    setSearchTerm('');
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search medicines..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors duration-200"
        />
      </div>

      {isOpen && searchTerm && (
        <>
          <div
            className="fixed inset-0 z-10"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute top-full left-0 right-0 z-20 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
            {filteredMedicines.length > 0 ? (
              <div className="py-1">
                {filteredMedicines.slice(0, 10).map((medicine) => (
                  <button
                    key={medicine.id}
                    onClick={() => handleSelect(medicine)}
                    className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-150 border-b border-gray-100 last:border-b-0"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">{medicine.name}</div>
                        <div className="text-sm text-gray-500">
                          {medicine.category} • ${medicine.price.toFixed(2)}/{medicine.unit}
                        </div>
                      </div>
                      <Plus size={16} className="text-gray-400" />
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="px-4 py-3 text-sm text-gray-500 text-center">
                No medicines found
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}