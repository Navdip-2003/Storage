import React, { useState } from 'react';
import { Bill, Patient, Doctor, BillMedicine, Medicine, BillTemplate } from '../../types';
import { mockPatients, mockDoctors, mockMedicines } from '../../data/mockData';
import { MedicineSearch } from './MedicineSearch';
import { BillPreview } from './BillPreview';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Card } from '../ui/Card';
import { FileText, Download, Plus, Trash2 } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface BillGeneratorProps {
  activeTemplate: BillTemplate;
}

export function BillGenerator({ activeTemplate }: BillGeneratorProps) {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [billMedicines, setBillMedicines] = useState<BillMedicine[]>([]);
  const [billNumber, setBillNumber] = useState(() => `BILL-${Date.now()}`);

  const addMedicine = (medicine: Medicine) => {
    const existingIndex = billMedicines.findIndex(bm => bm.medicine.id === medicine.id);
    
    if (existingIndex >= 0) {
      const updatedMedicines = [...billMedicines];
      updatedMedicines[existingIndex].quantity += 1;
      updatedMedicines[existingIndex].subtotal = calculateSubtotal(updatedMedicines[existingIndex]);
      setBillMedicines(updatedMedicines);
    } else {
      const newBillMedicine: BillMedicine = {
        id: `bm-${Date.now()}`,
        medicine,
        quantity: 1,
        discount: 0,
        tax: 18,
        subtotal: medicine.price
      };
      setBillMedicines([...billMedicines, newBillMedicine]);
    }
  };

  const updateMedicine = (id: string, updates: Partial<BillMedicine>) => {
    const updatedMedicines = billMedicines.map(bm => {
      if (bm.id === id) {
        const updated = { ...bm, ...updates };
        updated.subtotal = calculateSubtotal(updated);
        return updated;
      }
      return bm;
    });
    setBillMedicines(updatedMedicines);
  };

  const removeMedicine = (id: string) => {
    setBillMedicines(billMedicines.filter(bm => bm.id !== id));
  };

  const calculateSubtotal = (billMedicine: BillMedicine) => {
    const baseAmount = billMedicine.medicine.price * billMedicine.quantity;
    const discountAmount = baseAmount * (billMedicine.discount / 100);
    const taxableAmount = baseAmount - discountAmount;
    const taxAmount = taxableAmount * (billMedicine.tax / 100);
    return taxableAmount + taxAmount;
  };

  const calculateTotals = () => {
    const subtotal = billMedicines.reduce((sum, bm) => sum + (bm.medicine.price * bm.quantity), 0);
    const totalDiscount = billMedicines.reduce((sum, bm) => sum + (bm.medicine.price * bm.quantity * bm.discount / 100), 0);
    const taxableAmount = subtotal - totalDiscount;
    const totalTax = billMedicines.reduce((sum, bm) => {
      const baseAmount = bm.medicine.price * bm.quantity;
      const discountAmount = baseAmount * (bm.discount / 100);
      const taxableAmount = baseAmount - discountAmount;
      return sum + (taxableAmount * bm.tax / 100);
    }, 0);
    const total = taxableAmount + totalTax;

    return { subtotal, totalDiscount, totalTax, total };
  };

  const generatePDF = async () => {
    const element = document.getElementById('bill-preview');
    if (!element || !selectedPatient || !selectedDoctor) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`${billNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const patientOptions = mockPatients.map(p => ({ value: p.id, label: p.name }));
  const doctorOptions = mockDoctors.map(d => ({ value: d.id, label: d.name }));
  const totals = calculateTotals();

  const currentBill: Bill = {
    id: billNumber,
    billNumber,
    patient: selectedPatient!,
    doctor: selectedDoctor!,
    medicines: billMedicines,
    template: activeTemplate,
    subtotal: totals.subtotal,
    discount: totals.totalDiscount,
    tax: totals.totalTax,
    total: totals.total,
    createdAt: new Date()
  };

  return (
    <div className="h-full flex">
      {/* Bill Form */}
      <div className="w-1/3 border-r border-gray-200 p-6 overflow-y-auto bg-gray-50">
        <div className="space-y-6">
          {/* Bill Details */}
          <Card>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileText size={18} />
              Bill Details
            </h3>
            <div className="space-y-4">
              <Input
                label="Bill Number"
                value={billNumber}
                onChange={setBillNumber}
                required
              />
              
              <Select
                label="Patient"
                value={selectedPatient?.id || ''}
                onChange={(value) => setSelectedPatient(mockPatients.find(p => p.id === value) || null)}
                options={patientOptions}
                placeholder="Select a patient"
                required
              />
              
              <Select
                label="Doctor"
                value={selectedDoctor?.id || ''}
                onChange={(value) => setSelectedDoctor(mockDoctors.find(d => d.id === value) || null)}
                options={doctorOptions}
                placeholder="Select a doctor"
                required
              />
            </div>
          </Card>

          {/* Medicine Selection */}
          <Card>
            <h3 className="text-lg font-semibold mb-4">Add Medicines</h3>
            <MedicineSearch
              medicines={mockMedicines}
              onSelect={addMedicine}
            />
          </Card>

          {/* Selected Medicines */}
          {billMedicines.length > 0 && (
            <Card>
              <h3 className="text-lg font-semibold mb-4">Selected Medicines</h3>
              <div className="space-y-3">
                {billMedicines.map((billMedicine) => (
                  <div key={billMedicine.id} className="bg-white p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{billMedicine.medicine.name}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMedicine(billMedicine.id)}
                        icon={Trash2}
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <Input
                        label="Qty"
                        type="number"
                        value={billMedicine.quantity.toString()}
                        onChange={(value) => updateMedicine(billMedicine.id, { quantity: parseInt(value) || 0 })}
                      />
                      <Input
                        label="Discount %"
                        type="number"
                        value={billMedicine.discount.toString()}
                        onChange={(value) => updateMedicine(billMedicine.id, { discount: parseInt(value) || 0 })}
                      />
                      <Input
                        label="Tax %"
                        type="number"
                        value={billMedicine.tax.toString()}
                        onChange={(value) => updateMedicine(billMedicine.id, { tax: parseInt(value) || 0 })}
                      />
                    </div>
                    <div className="mt-2 text-sm text-right">
                      Subtotal: <span className="font-medium">${billMedicine.subtotal.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals Summary */}
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${totals.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-${totals.totalDiscount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax:</span>
                    <span>${totals.totalTax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-base pt-1 border-t border-blue-200">
                    <span>Total:</span>
                    <span className="text-blue-600">${totals.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={generatePDF}
              disabled={!selectedPatient || !selectedDoctor || billMedicines.length === 0}
              icon={Download}
              className="w-full"
            >
              Download PDF
            </Button>
          </div>
        </div>
      </div>

      {/* Bill Preview */}
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
          <div className="flex items-center gap-2">
            <FileText size={18} className="text-gray-600" />
            <span className="font-medium">Bill Preview</span>
          </div>
          <span className="text-sm text-gray-500">
            Template: {activeTemplate.name}
          </span>
        </div>
        
        <div className="flex-1 p-6 bg-gray-100 overflow-y-auto">
          {selectedPatient && selectedDoctor ? (
            <BillPreview bill={currentBill} />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-gray-500">
                <FileText size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium mb-2">Select Patient & Doctor</p>
                <p>Choose a patient and doctor to start creating the bill</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}