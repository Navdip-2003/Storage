import React from 'react';
import { Bill } from '../../types';

interface BillPreviewProps {
  bill: Bill;
}

export function BillPreview({ bill }: BillPreviewProps) {
  const { patient, doctor, medicines, template } = bill;
  
  const visibleFields = template.fields
    .filter(field => field.visible)
    .sort((a, b) => a.order - b.order);

  const getFontSizeClass = (size?: string) => {
    switch (size) {
      case 'sm': return 'text-sm';
      case 'lg': return 'text-lg';
      case 'xl': return 'text-xl';
      default: return 'text-base';
    }
  };

  const getAlignmentClass = (alignment?: string) => {
    switch (alignment) {
      case 'center': return 'text-center';
      case 'right': return 'text-right';
      default: return 'text-left';
    }
  };

  const renderField = (field: any) => {
    switch (field.type) {
      case 'header':
        return (
          <div 
            key={field.id}
            className={`${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)} font-bold border-b-2 pb-4 mb-6`}
            style={{ 
              color: field.config?.color || template.colorTheme.text,
              borderColor: template.colorTheme.primary
            }}
          >
            <h1 className="text-2xl font-bold" style={{ color: template.colorTheme.primary }}>
              {template.branding.clinicName}
            </h1>
            <p className="text-sm mt-2">{template.branding.address}</p>
            <p className="text-sm">Phone: {template.branding.phone} | Email: {template.branding.email}</p>
            <p className="text-sm mt-2 font-medium">Bill No: {bill.billNumber}</p>
            <p className="text-sm">Date: {bill.createdAt.toLocaleDateString()}</p>
          </div>
        );

      case 'patient-info':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Patient Information
            </h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Name:</span> {patient.name}
              </div>
              <div>
                <span className="font-medium">Age:</span> {patient.age}
              </div>
              <div>
                <span className="font-medium">Gender:</span> {patient.gender}
              </div>
              <div>
                <span className="font-medium">Phone:</span> {patient.phone}
              </div>
              <div className="col-span-2">
                <span className="font-medium">Address:</span> {patient.address}
              </div>
            </div>
          </div>
        );

      case 'doctor-info':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Doctor Information
            </h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Name:</span> {doctor.name}
              </div>
              <div>
                <span className="font-medium">Qualification:</span> {doctor.qualification}
              </div>
              <div>
                <span className="font-medium">Specialization:</span> {doctor.specialization}
              </div>
              <div>
                <span className="font-medium">Reg. No:</span> {doctor.registrationNumber}
              </div>
            </div>
          </div>
        );

      case 'medicine-table':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Medicine Details
            </h2>
            <div className="overflow-hidden rounded-lg border border-gray-200">
              <table className="w-full text-sm">
                <thead style={{ backgroundColor: template.colorTheme.primary, color: 'white' }}>
                  <tr>
                    <th className="px-4 py-3 text-left">Medicine</th>
                    <th className="px-4 py-3 text-right">Qty</th>
                    <th className="px-4 py-3 text-right">Price</th>
                    <th className="px-4 py-3 text-right">Discount</th>
                    <th className="px-4 py-3 text-right">Tax</th>
                    <th className="px-4 py-3 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {medicines.map((item, index) => (
                    <tr key={item.id} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-4 py-3">{item.medicine.name}</td>
                      <td className="px-4 py-3 text-right">{item.quantity}</td>
                      <td className="px-4 py-3 text-right">${item.medicine.price.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right">{item.discount}%</td>
                      <td className="px-4 py-3 text-right">{item.tax}%</td>
                      <td className="px-4 py-3 text-right font-medium">${item.subtotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'totals':
        return (
          <div key={field.id} className="mb-6">
            <div className="flex justify-end">
              <div className="w-80 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal:</span>
                  <span>${bill.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Discount:</span>
                  <span>-${bill.discount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax:</span>
                  <span>${bill.tax.toFixed(2)}</span>
                </div>
                <div 
                  className="flex justify-between text-lg font-bold pt-2 border-t"
                  style={{ borderColor: template.colorTheme.primary }}
                >
                  <span>Total:</span>
                  <span style={{ color: template.colorTheme.primary }}>${bill.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'custom-text':
        return (
          <div 
            key={field.id}
            className={`mb-4 ${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)}`}
            style={{ color: field.config?.color || template.colorTheme.text }}
          >
            {field.config?.text || 'Custom text will appear here...'}
          </div>
        );

      case 'footer':
        return (
          <div 
            key={field.id}
            className={`${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)} border-t pt-4 mt-6`}
            style={{ 
              color: field.config?.color || template.colorTheme.text,
              borderColor: template.colorTheme.primary
            }}
          >
            <p>Thank you for choosing {template.branding.clinicName}</p>
            <p className="text-xs mt-1">This is a computer generated bill</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div 
      id="bill-preview"
      className="bg-white p-8 rounded-lg shadow-sm border min-h-[800px] max-w-4xl mx-auto"
      style={{ 
        backgroundColor: template.colorTheme.background,
        color: template.colorTheme.text
      }}
    >
      {visibleFields.map(renderField)}
    </div>
  );
}