import React from 'react';
import { BillTemplate, Patient, Doctor, BillMedicine } from '../../types';
import { mockPatients, mockDoctors, mockMedicines } from '../../data/mockData';

interface TemplatePreviewProps {
  template: BillTemplate;
}

export function TemplatePreview({ template }: TemplatePreviewProps) {
  const samplePatient = mockPatients[0];
  const sampleDoctor = mockDoctors[0];
  const sampleMedicines: BillMedicine[] = [
    {
      id: '1',
      medicine: mockMedicines[0],
      quantity: 10,
      discount: 0,
      tax: 18,
      subtotal: 25.00
    },
    {
      id: '2',
      medicine: mockMedicines[1],
      quantity: 5,
      discount: 5,
      tax: 18,
      subtotal: 60.00
    }
  ];

  const subtotal = sampleMedicines.reduce((sum, item) => sum + item.subtotal, 0);
  const totalDiscount = sampleMedicines.reduce((sum, item) => sum + (item.medicine.price * item.quantity * item.discount / 100), 0);
  const totalTax = sampleMedicines.reduce((sum, item) => sum + (item.subtotal * item.tax / 100), 0);
  const grandTotal = subtotal + totalTax - totalDiscount;

  const visibleFields = template.fields
    .filter(field => field.visible)
    .sort((a, b) => a.order - b.order);

  const getFontSizeClass = (size?: string) => {
    switch (size) {
      case 'sm': return 'text-sm';
      case 'lg': return 'text-lg';
      case 'xl': return 'text-xl';
      default: return 'text-base';
    }
  };

  const getAlignmentClass = (alignment?: string) => {
    switch (alignment) {
      case 'center': return 'text-center';
      case 'right': return 'text-right';
      default: return 'text-left';
    }
  };

  const renderField = (field: any) => {
    switch (field.type) {
      case 'header':
        return (
          <div 
            key={field.id}
            className={`${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)} font-bold border-b-2 pb-4 mb-6`}
            style={{ 
              color: field.config?.color || template.colorTheme.text,
              borderColor: template.colorTheme.primary
            }}
          >
            <h1 className="text-2xl font-bold" style={{ color: template.colorTheme.primary }}>
              {template.branding.clinicName}
            </h1>
            <p className="text-sm mt-2">{template.branding.address}</p>
            <p className="text-sm">Phone: {template.branding.phone} | Email: {template.branding.email}</p>
          </div>
        );

      case 'patient-info':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Patient Information
            </h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Name:</span> {samplePatient.name}
              </div>
              <div>
                <span className="font-medium">Age:</span> {samplePatient.age}
              </div>
              <div>
                <span className="font-medium">Gender:</span> {samplePatient.gender}
              </div>
              <div>
                <span className="font-medium">Phone:</span> {samplePatient.phone}
              </div>
              <div className="col-span-2">
                <span className="font-medium">Address:</span> {samplePatient.address}
              </div>
            </div>
          </div>
        );

      case 'doctor-info':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Doctor Information
            </h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Name:</span> {sampleDoctor.name}
              </div>
              <div>
                <span className="font-medium">Qualification:</span> {sampleDoctor.qualification}
              </div>
              <div>
                <span className="font-medium">Specialization:</span> {sampleDoctor.specialization}
              </div>
              <div>
                <span className="font-medium">Reg. No:</span> {sampleDoctor.registrationNumber}
              </div>
            </div>
          </div>
        );

      case 'medicine-table':
        return (
          <div key={field.id} className="mb-6">
            <h2 className="text-lg font-semibold mb-3" style={{ color: template.colorTheme.primary }}>
              Medicine Details
            </h2>
            <div className="overflow-hidden rounded-lg border border-gray-200">
              <table className="w-full text-sm">
                <thead style={{ backgroundColor: template.colorTheme.primary, color: 'white' }}>
                  <tr>
                    <th className="px-4 py-3 text-left">Medicine</th>
                    <th className="px-4 py-3 text-right">Qty</th>
                    <th className="px-4 py-3 text-right">Price</th>
                    <th className="px-4 py-3 text-right">Discount</th>
                    <th className="px-4 py-3 text-right">Tax</th>
                    <th className="px-4 py-3 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {sampleMedicines.map((item, index) => (
                    <tr key={item.id} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-4 py-3">{item.medicine.name}</td>
                      <td className="px-4 py-3 text-right">{item.quantity}</td>
                      <td className="px-4 py-3 text-right">${item.medicine.price.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right">{item.discount}%</td>
                      <td className="px-4 py-3 text-right">{item.tax}%</td>
                      <td className="px-4 py-3 text-right font-medium">${item.subtotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'totals':
        return (
          <div key={field.id} className="mb-6">
            <div className="flex justify-end">
              <div className="w-80 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal:</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Discount:</span>
                  <span>-${totalDiscount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax:</span>
                  <span>${totalTax.toFixed(2)}</span>
                </div>
                <div 
                  className="flex justify-between text-lg font-bold pt-2 border-t"
                  style={{ borderColor: template.colorTheme.primary }}
                >
                  <span>Total:</span>
                  <span style={{ color: template.colorTheme.primary }}>${grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'custom-text':
        return (
          <div 
            key={field.id}
            className={`mb-4 ${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)}`}
            style={{ color: field.config?.color || template.colorTheme.text }}
          >
            {field.config?.text || 'Custom text will appear here...'}
          </div>
        );

      case 'footer':
        return (
          <div 
            key={field.id}
            className={`${getFontSizeClass(field.config?.fontSize)} ${getAlignmentClass(field.config?.alignment)} border-t pt-4 mt-6`}
            style={{ 
              color: field.config?.color || template.colorTheme.text,
              borderColor: template.colorTheme.primary
            }}
          >
            <p>Thank you for choosing {template.branding.clinicName}</p>
            <p className="text-xs mt-1">This is a computer generated bill</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div 
      className="bg-white p-8 rounded-lg shadow-sm border min-h-[800px]"
      style={{ 
        backgroundColor: template.colorTheme.background,
        color: template.colorTheme.text
      }}
    >
      <div className="max-w-4xl mx-auto">
        {visibleFields.map(renderField)}
      </div>
    </div>
  );
}