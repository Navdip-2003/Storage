import React from 'react';
import { TemplateField } from '../../types';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Eye, EyeOff, GripVertical } from 'lucide-react';

interface FieldEditorProps {
  field: TemplateField;
  onUpdate: (field: TemplateField) => void;
  onToggleVisibility: (fieldId: string) => void;
}

export function FieldEditor({ field, onUpdate, onToggleVisibility }: FieldEditorProps) {
  const handleConfigUpdate = (key: string, value: any) => {
    const updatedField = {
      ...field,
      config: {
        ...field.config,
        [key]: value
      }
    };
    onUpdate(updatedField);
  };

  const fontSizeOptions = [
    { value: 'sm', label: 'Small' },
    { value: 'base', label: 'Medium' },
    { value: 'lg', label: 'Large' },
    { value: 'xl', label: 'Extra Large' }
  ];

  const alignmentOptions = [
    { value: 'left', label: 'Left' },
    { value: 'center', label: 'Center' },
    { value: 'right', label: 'Right' }
  ];

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GripVertical className="h-4 w-4 text-gray-400 cursor-move" />
          <span className="font-medium text-gray-900">{field.label}</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onToggleVisibility(field.id)}
          icon={field.visible ? Eye : EyeOff}
        >
          {field.visible ? 'Visible' : 'Hidden'}
        </Button>
      </div>

      {field.visible && (field.type === 'custom-text' || field.type === 'header' || field.type === 'footer') && (
        <div className="space-y-3">
          {field.type === 'custom-text' && (
            <Input
              label="Custom Text"
              value={field.config?.text || ''}
              onChange={(value) => handleConfigUpdate('text', value)}
              placeholder="Enter custom text"
            />
          )}
          
          <div className="grid grid-cols-2 gap-3">
            <Select
              label="Font Size"
              value={field.config?.fontSize || 'base'}
              onChange={(value) => handleConfigUpdate('fontSize', value)}
              options={fontSizeOptions}
            />
            <Select
              label="Alignment"
              value={field.config?.alignment || 'left'}
              onChange={(value) => handleConfigUpdate('alignment', value)}
              options={alignmentOptions}
            />
          </div>
          
          <Input
            label="Text Color"
            type="color"
            value={field.config?.color || '#1f2937'}
            onChange={(value) => handleConfigUpdate('color', value)}
          />
        </div>
      )}
    </div>
  );
}