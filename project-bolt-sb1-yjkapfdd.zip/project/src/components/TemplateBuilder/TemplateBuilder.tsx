import React, { useState } from 'react';
import { BillTemplate, TemplateField } from '../../types';
import { FieldEditor } from './FieldEditor';
import { TemplatePreview } from './TemplatePreview';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { Save, Eye, Settings, Plus } from 'lucide-react';

interface TemplateBuilderProps {
  template: BillTemplate;
  onSave: (template: BillTemplate) => void;
}

export function TemplateBuilder({ template, onSave }: TemplateBuilderProps) {
  const [currentTemplate, setCurrentTemplate] = useState<BillTemplate>(template);
  const [showPreview, setShowPreview] = useState(true);

  const handleFieldUpdate = (updatedField: TemplateField) => {
    const updatedFields = currentTemplate.fields.map(field =>
      field.id === updatedField.id ? updatedField : field
    );
    
    setCurrentTemplate(prev => ({
      ...prev,
      fields: updatedFields,
      updatedAt: new Date()
    }));
  };

  const handleToggleVisibility = (fieldId: string) => {
    const updatedFields = currentTemplate.fields.map(field =>
      field.id === fieldId ? { ...field, visible: !field.visible } : field
    );
    
    setCurrentTemplate(prev => ({
      ...prev,
      fields: updatedFields,
      updatedAt: new Date()
    }));
  };

  const handleBrandingUpdate = (key: string, value: string) => {
    setCurrentTemplate(prev => ({
      ...prev,
      branding: {
        ...prev.branding,
        [key]: value
      },
      updatedAt: new Date()
    }));
  };

  const handleColorThemeUpdate = (key: string, value: string) => {
    setCurrentTemplate(prev => ({
      ...prev,
      colorTheme: {
        ...prev.colorTheme,
        [key]: value
      },
      updatedAt: new Date()
    }));
  };

  const handleAddCustomField = () => {
    const newField: TemplateField = {
      id: `custom-${Date.now()}`,
      type: 'custom-text',
      label: 'Custom Field',
      visible: true,
      order: currentTemplate.fields.length,
      config: {
        text: 'Custom text',
        fontSize: 'base',
        alignment: 'left',
        color: currentTemplate.colorTheme.text
      }
    };

    setCurrentTemplate(prev => ({
      ...prev,
      fields: [...prev.fields, newField],
      updatedAt: new Date()
    }));
  };

  const handleSave = () => {
    onSave(currentTemplate);
  };

  return (
    <div className="h-full flex">
      {/* Settings Panel */}
      <div className="w-1/3 border-r border-gray-200 p-6 overflow-y-auto bg-gray-50">
        <div className="space-y-6">
          {/* Template Settings */}
          <Card>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Settings size={18} />
              Template Settings
            </h3>
            <div className="space-y-4">
              <Input
                label="Template Name"
                value={currentTemplate.name}
                onChange={(value) => setCurrentTemplate(prev => ({ ...prev, name: value }))}
              />
            </div>
          </Card>

          {/* Branding */}
          <Card>
            <h3 className="text-lg font-semibold mb-4">Branding</h3>
            <div className="space-y-4">
              <Input
                label="Clinic Name"
                value={currentTemplate.branding.clinicName}
                onChange={(value) => handleBrandingUpdate('clinicName', value)}
              />
              <Input
                label="Address"
                value={currentTemplate.branding.address}
                onChange={(value) => handleBrandingUpdate('address', value)}
              />
              <Input
                label="Phone"
                value={currentTemplate.branding.phone}
                onChange={(value) => handleBrandingUpdate('phone', value)}
              />
              <Input
                label="Email"
                value={currentTemplate.branding.email}
                onChange={(value) => handleBrandingUpdate('email', value)}
              />
            </div>
          </Card>

          {/* Color Theme */}
          <Card>
            <h3 className="text-lg font-semibold mb-4">Color Theme</h3>
            <div className="space-y-4">
              <Input
                label="Primary Color"
                type="color"
                value={currentTemplate.colorTheme.primary}
                onChange={(value) => handleColorThemeUpdate('primary', value)}
              />
              <Input
                label="Secondary Color"
                type="color"
                value={currentTemplate.colorTheme.secondary}
                onChange={(value) => handleColorThemeUpdate('secondary', value)}
              />
              <Input
                label="Accent Color"
                type="color"
                value={currentTemplate.colorTheme.accent}
                onChange={(value) => handleColorThemeUpdate('accent', value)}
              />
              <Input
                label="Text Color"
                type="color"
                value={currentTemplate.colorTheme.text}
                onChange={(value) => handleColorThemeUpdate('text', value)}
              />
            </div>
          </Card>

          {/* Fields Configuration */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Fields Configuration</h3>
              <Button
                size="sm"
                onClick={handleAddCustomField}
                icon={Plus}
              >
                Add Field
              </Button>
            </div>
            <div className="space-y-3">
              {currentTemplate.fields
                .sort((a, b) => a.order - b.order)
                .map((field) => (
                  <FieldEditor
                    key={field.id}
                    field={field}
                    onUpdate={handleFieldUpdate}
                    onToggleVisibility={handleToggleVisibility}
                  />
                ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Preview Panel */}
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
          <div className="flex items-center gap-2">
            <Eye size={18} className="text-gray-600" />
            <span className="font-medium">Live Preview</span>
          </div>
          <Button onClick={handleSave} icon={Save}>
            Save Template
          </Button>
        </div>
        
        <div className="flex-1 p-6 bg-gray-100 overflow-y-auto">
          <TemplatePreview template={currentTemplate} />
        </div>
      </div>
    </div>
  );
}