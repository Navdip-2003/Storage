import React, { useState } from 'react';
import { BillTemplate } from '../../types';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Modal } from '../ui/Modal';
import { TemplateBuilder } from '../TemplateBuilder/TemplateBuilder';
import { Plus, Edit, Trash2, Star, Copy } from 'lucide-react';

interface TemplateManagerProps {
  templates: BillTemplate[];
  onSave: (template: BillTemplate) => void;
  onDelete: (templateId: string) => void;
  onSetActive: (templateId: string) => void;
}

export function TemplateManager({ templates, onSave, onDelete, onSetActive }: TemplateManagerProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<BillTemplate | null>(null);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);

  const createNewTemplate = () => {
    const newTemplate: BillTemplate = {
      id: `template-${Date.now()}`,
      name: 'New Template',
      fields: [
        {
          id: 'header',
          type: 'header',
          label: 'Header',
          visible: true,
          order: 0,
          config: { fontSize: 'xl', alignment: 'center', color: '#1f2937' }
        },
        {
          id: 'patient-info',
          type: 'patient-info',
          label: 'Patient Information',
          visible: true,
          order: 1
        },
        {
          id: 'doctor-info',
          type: 'doctor-info',
          label: 'Doctor Information',
          visible: true,
          order: 2
        },
        {
          id: 'medicine-table',
          type: 'medicine-table',
          label: 'Medicine Details',
          visible: true,
          order: 3
        },
        {
          id: 'totals',
          type: 'totals',
          label: 'Bill Summary',
          visible: true,
          order: 4
        },
        {
          id: 'footer',
          type: 'footer',
          label: 'Footer',
          visible: true,
          order: 5,
          config: { fontSize: 'sm', alignment: 'center', color: '#6b7280' }
        }
      ],
      colorTheme: {
        primary: '#2563eb',
        secondary: '#0d9488',
        accent: '#059669',
        background: '#ffffff',
        text: '#1f2937'
      },
      branding: {
        clinicName: 'Medical Center',
        address: 'Address Here',
        phone: 'Phone Number',
        email: 'email@example.com'
      },
      isActive: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setSelectedTemplate(newTemplate);
    setIsBuilderOpen(true);
  };

  const duplicateTemplate = (template: BillTemplate) => {
    const duplicated: BillTemplate = {
      ...template,
      id: `template-${Date.now()}`,
      name: `${template.name} (Copy)`,
      isActive: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      fields: template.fields.map(field => ({
        ...field,
        id: `${field.id}-${Date.now()}`
      }))
    };

    setSelectedTemplate(duplicated);
    setIsBuilderOpen(true);
  };

  const handleSave = (template: BillTemplate) => {
    onSave(template);
    setIsBuilderOpen(false);
    setSelectedTemplate(null);
  };

  const handleEdit = (template: BillTemplate) => {
    setSelectedTemplate(template);
    setIsBuilderOpen(true);
  };

  const closeBuilder = () => {
    setIsBuilderOpen(false);
    setSelectedTemplate(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Template Manager</h2>
        <Button
          onClick={createNewTemplate}
          icon={Plus}
        >
          Create New Template
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template) => (
          <Card key={template.id} className="relative" hover>
            {template.isActive && (
              <div className="absolute top-3 right-3">
                <div className="flex items-center gap-1 bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                  <Star size={12} fill="currentColor" />
                  Active
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {template.name}
                </h3>
                <div className="text-sm text-gray-500 space-y-1">
                  <p>Fields: {template.fields.filter(f => f.visible).length} visible</p>
                  <p>Updated: {template.updatedAt.toLocaleDateString()}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: template.colorTheme.primary }}
                  title="Primary color"
                />
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: template.colorTheme.secondary }}
                  title="Secondary color"
                />
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: template.colorTheme.accent }}
                  title="Accent color"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEdit(template)}
                  icon={Edit}
                >
                  Edit
                </Button>
                
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => duplicateTemplate(template)}
                  icon={Copy}
                >
                  Duplicate
                </Button>
                
                {!template.isActive && (
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => onSetActive(template.id)}
                    icon={Star}
                  >
                    Set Active
                  </Button>
                )}
                
                <Button
                  size="sm"
                  variant="danger"
                  onClick={() => onDelete(template.id)}
                  icon={Trash2}
                  disabled={template.isActive}
                >
                  Delete
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {templates.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <Edit size={48} className="mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No templates yet</h3>
          <p className="text-gray-500 mb-6">Create your first bill template to get started</p>
          <Button onClick={createNewTemplate} icon={Plus}>
            Create Template
          </Button>
        </div>
      )}

      <Modal
        isOpen={isBuilderOpen}
        onClose={closeBuilder}
        title={selectedTemplate ? `Edit ${selectedTemplate.name}` : 'Create Template'}
        size="xl"
      >
        {selectedTemplate && (
          <div className="h-[800px]">
            <TemplateBuilder
              template={selectedTemplate}
              onSave={handleSave}
            />
          </div>
        )}
      </Modal>
    </div>
  );
}