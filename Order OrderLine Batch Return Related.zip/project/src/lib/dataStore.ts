import {
  Item,
  Batch,
  Order,
  OrderLine,
  BatchAllocation,
  OrderReturn,
  ReturnLine,
  InventoryTransaction,
  OrderStatus,
  BatchStatus,
} from '../types';

const STORAGE_KEYS = {
  ITEMS: 'medical_inventory_items',
  BATCHES: 'medical_inventory_batches',
  ORDERS: 'medical_inventory_orders',
  ORDER_LINES: 'medical_inventory_order_lines',
  BATCH_ALLOCATIONS: 'medical_inventory_batch_allocations',
  ORDER_RETURNS: 'medical_inventory_order_returns',
  RETURN_LINES: 'medical_inventory_return_lines',
  INVENTORY_TRANSACTIONS: 'medical_inventory_inventory_transactions',
  ORDER_COUNTER: 'medical_inventory_order_counter',
  RETURN_COUNTER: 'medical_inventory_return_counter',
};

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function getFromStorage<T>(key: string): T[] {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function saveToStorage<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

function getCounter(key: string): number {
  const counter = localStorage.getItem(key);
  return counter ? parseInt(counter, 10) : 0;
}

function incrementCounter(key: string): number {
  const counter = getCounter(key) + 1;
  localStorage.setItem(key, counter.toString());
  return counter;
}

export const generateOrderNumber = (): string => {
  const counter = incrementCounter(STORAGE_KEYS.ORDER_COUNTER);
  return `ORD-${counter.toString().padStart(6, '0')}`;
};

export const generateReturnNumber = (): string => {
  const counter = incrementCounter(STORAGE_KEYS.RETURN_COUNTER);
  return `RET-${counter.toString().padStart(6, '0')}`;
};

export const itemStore = {
  getAll: (): Item[] => getFromStorage<Item>(STORAGE_KEYS.ITEMS),

  getById: (id: string): Item | undefined => {
    const items = getFromStorage<Item>(STORAGE_KEYS.ITEMS);
    return items.find(item => item.item_id === id);
  },

  create: (item: Omit<Item, 'item_id' | 'created_at' | 'updated_at'>): Item => {
    const items = getFromStorage<Item>(STORAGE_KEYS.ITEMS);
    const newItem: Item = {
      ...item,
      item_id: generateId(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    items.push(newItem);
    saveToStorage(STORAGE_KEYS.ITEMS, items);
    return newItem;
  },

  update: (id: string, updates: Partial<Item>): Item | null => {
    const items = getFromStorage<Item>(STORAGE_KEYS.ITEMS);
    const index = items.findIndex(item => item.item_id === id);
    if (index === -1) return null;

    items[index] = {
      ...items[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    saveToStorage(STORAGE_KEYS.ITEMS, items);
    return items[index];
  },

  delete: (id: string): boolean => {
    const items = getFromStorage<Item>(STORAGE_KEYS.ITEMS);
    const filtered = items.filter(item => item.item_id !== id);
    if (filtered.length === items.length) return false;
    saveToStorage(STORAGE_KEYS.ITEMS, filtered);
    return true;
  },
};

export const batchStore = {
  getAll: (): Batch[] => getFromStorage<Batch>(STORAGE_KEYS.BATCHES),

  getById: (id: string): Batch | undefined => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    return batches.find(batch => batch.batch_id === id);
  },

  getByItemId: (itemId: string): Batch[] => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    return batches.filter(batch => batch.item_id === itemId);
  },

  getAvailableBatchesFEFO: (itemId: string, quantityNeeded: number): Batch[] => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    const today = new Date().toISOString().split('T')[0];

    const availableBatches = batches
      .filter(batch =>
        batch.item_id === itemId &&
        batch.status === 'Active' &&
        batch.quantity_available > 0 &&
        batch.expiry_date > today
      )
      .sort((a, b) => a.expiry_date.localeCompare(b.expiry_date));

    return availableBatches;
  },

  create: (batch: Omit<Batch, 'batch_id' | 'created_at' | 'updated_at'>): Batch => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    const newBatch: Batch = {
      ...batch,
      batch_id: generateId(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    batches.push(newBatch);
    saveToStorage(STORAGE_KEYS.BATCHES, batches);

    createInventoryTransaction({
      txn_type: 'Receipt',
      ref_number: newBatch.batch_number,
      item_id: newBatch.item_id,
      batch_id: newBatch.batch_id,
      quantity: newBatch.quantity_received,
      unit_cost: newBatch.unit_cost,
      warehouse_id: newBatch.warehouse_id,
    });

    return newBatch;
  },

  update: (id: string, updates: Partial<Batch>): Batch | null => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    const index = batches.findIndex(batch => batch.batch_id === id);
    if (index === -1) return null;

    batches[index] = {
      ...batches[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    saveToStorage(STORAGE_KEYS.BATCHES, batches);
    return batches[index];
  },

  updateQuantities: (id: string, quantityChanges: Partial<Pick<Batch, 'quantity_available' | 'quantity_reserved' | 'quantity_allocated'>>): Batch | null => {
    return batchStore.update(id, quantityChanges);
  },

  getExpiringBatches: (daysAhead: number): Batch[] => {
    const batches = getFromStorage<Batch>(STORAGE_KEYS.BATCHES);
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysAhead);
    const futureDateStr = futureDate.toISOString().split('T')[0];

    return batches.filter(batch =>
      batch.status === 'Active' &&
      batch.expiry_date <= futureDateStr &&
      batch.quantity_available > 0
    );
  },
};

export const orderStore = {
  getAll: (): Order[] => getFromStorage<Order>(STORAGE_KEYS.ORDERS),

  getById: (id: string): Order | undefined => {
    const orders = getFromStorage<Order>(STORAGE_KEYS.ORDERS);
    return orders.find(order => order.order_id === id);
  },

  create: (order: Omit<Order, 'order_id' | 'order_number' | 'created_at' | 'updated_at'>): Order => {
    const orders = getFromStorage<Order>(STORAGE_KEYS.ORDERS);
    const newOrder: Order = {
      ...order,
      order_id: generateId(),
      order_number: generateOrderNumber(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    orders.push(newOrder);
    saveToStorage(STORAGE_KEYS.ORDERS, orders);
    return newOrder;
  },

  update: (id: string, updates: Partial<Order>): Order | null => {
    const orders = getFromStorage<Order>(STORAGE_KEYS.ORDERS);
    const index = orders.findIndex(order => order.order_id === id);
    if (index === -1) return null;

    orders[index] = {
      ...orders[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    saveToStorage(STORAGE_KEYS.ORDERS, orders);
    return orders[index];
  },

  updateStatus: (id: string, status: OrderStatus): Order | null => {
    return orderStore.update(id, { status });
  },
};

export const orderLineStore = {
  getAll: (): OrderLine[] => getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES),

  getByOrderId: (orderId: string): OrderLine[] => {
    const lines = getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES);
    return lines.filter(line => line.order_id === orderId);
  },

  getById: (id: string): OrderLine | undefined => {
    const lines = getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES);
    return lines.find(line => line.order_line_id === id);
  },

  create: (line: Omit<OrderLine, 'order_line_id' | 'created_at'>): OrderLine => {
    const lines = getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES);
    const newLine: OrderLine = {
      ...line,
      order_line_id: generateId(),
      created_at: new Date().toISOString(),
    };
    lines.push(newLine);
    saveToStorage(STORAGE_KEYS.ORDER_LINES, lines);
    return newLine;
  },

  update: (id: string, updates: Partial<OrderLine>): OrderLine | null => {
    const lines = getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES);
    const index = lines.findIndex(line => line.order_line_id === id);
    if (index === -1) return null;

    lines[index] = { ...lines[index], ...updates };
    saveToStorage(STORAGE_KEYS.ORDER_LINES, lines);
    return lines[index];
  },

  delete: (id: string): boolean => {
    const lines = getFromStorage<OrderLine>(STORAGE_KEYS.ORDER_LINES);
    const filtered = lines.filter(line => line.order_line_id !== id);
    if (filtered.length === lines.length) return false;
    saveToStorage(STORAGE_KEYS.ORDER_LINES, filtered);
    return true;
  },
};

export const batchAllocationStore = {
  getAll: (): BatchAllocation[] => getFromStorage<BatchAllocation>(STORAGE_KEYS.BATCH_ALLOCATIONS),

  getByOrderLineId: (orderLineId: string): BatchAllocation[] => {
    const allocations = getFromStorage<BatchAllocation>(STORAGE_KEYS.BATCH_ALLOCATIONS);
    return allocations.filter(alloc => alloc.order_line_id === orderLineId);
  },

  create: (allocation: Omit<BatchAllocation, 'allocation_id' | 'allocation_date'>): BatchAllocation => {
    const allocations = getFromStorage<BatchAllocation>(STORAGE_KEYS.BATCH_ALLOCATIONS);
    const newAllocation: BatchAllocation = {
      ...allocation,
      allocation_id: generateId(),
      allocation_date: new Date().toISOString(),
    };
    allocations.push(newAllocation);
    saveToStorage(STORAGE_KEYS.BATCH_ALLOCATIONS, allocations);

    const batch = batchStore.getById(allocation.batch_id);
    if (batch) {
      batchStore.updateQuantities(allocation.batch_id, {
        quantity_allocated: batch.quantity_allocated + allocation.quantity_allocated,
        quantity_available: batch.quantity_available - allocation.quantity_allocated,
      });
    }

    return newAllocation;
  },

  update: (id: string, updates: Partial<BatchAllocation>): BatchAllocation | null => {
    const allocations = getFromStorage<BatchAllocation>(STORAGE_KEYS.BATCH_ALLOCATIONS);
    const index = allocations.findIndex(alloc => alloc.allocation_id === id);
    if (index === -1) return null;

    allocations[index] = { ...allocations[index], ...updates };
    saveToStorage(STORAGE_KEYS.BATCH_ALLOCATIONS, allocations);
    return allocations[index];
  },
};

export const orderReturnStore = {
  getAll: (): OrderReturn[] => getFromStorage<OrderReturn>(STORAGE_KEYS.ORDER_RETURNS),

  getById: (id: string): OrderReturn | undefined => {
    const returns = getFromStorage<OrderReturn>(STORAGE_KEYS.ORDER_RETURNS);
    return returns.find(ret => ret.return_id === id);
  },

  create: (orderReturn: Omit<OrderReturn, 'return_id' | 'return_number' | 'created_at' | 'updated_at'>): OrderReturn => {
    const returns = getFromStorage<OrderReturn>(STORAGE_KEYS.ORDER_RETURNS);
    const newReturn: OrderReturn = {
      ...orderReturn,
      return_id: generateId(),
      return_number: generateReturnNumber(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    returns.push(newReturn);
    saveToStorage(STORAGE_KEYS.ORDER_RETURNS, returns);
    return newReturn;
  },

  update: (id: string, updates: Partial<OrderReturn>): OrderReturn | null => {
    const returns = getFromStorage<OrderReturn>(STORAGE_KEYS.ORDER_RETURNS);
    const index = returns.findIndex(ret => ret.return_id === id);
    if (index === -1) return null;

    returns[index] = {
      ...returns[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    saveToStorage(STORAGE_KEYS.ORDER_RETURNS, returns);
    return returns[index];
  },
};

export const returnLineStore = {
  getAll: (): ReturnLine[] => getFromStorage<ReturnLine>(STORAGE_KEYS.RETURN_LINES),

  getByReturnId: (returnId: string): ReturnLine[] => {
    const lines = getFromStorage<ReturnLine>(STORAGE_KEYS.RETURN_LINES);
    return lines.filter(line => line.return_id === returnId);
  },

  create: (line: Omit<ReturnLine, 'return_line_id' | 'created_at'>): ReturnLine => {
    const lines = getFromStorage<ReturnLine>(STORAGE_KEYS.RETURN_LINES);
    const newLine: ReturnLine = {
      ...line,
      return_line_id: generateId(),
      created_at: new Date().toISOString(),
    };
    lines.push(newLine);
    saveToStorage(STORAGE_KEYS.RETURN_LINES, lines);

    if (newLine.restock && newLine.batch_id && newLine.qc_outcome === 'Restock') {
      const batch = batchStore.getById(newLine.batch_id);
      if (batch) {
        batchStore.updateQuantities(newLine.batch_id, {
          quantity_available: batch.quantity_available + newLine.quantity_returned,
        });

        createInventoryTransaction({
          txn_type: 'Return',
          ref_number: `Return ${newLine.return_line_id}`,
          item_id: newLine.item_id,
          batch_id: newLine.batch_id,
          quantity: newLine.quantity_returned,
          unit_cost: batch.unit_cost,
        });
      }
    }

    return newLine;
  },

  update: (id: string, updates: Partial<ReturnLine>): ReturnLine | null => {
    const lines = getFromStorage<ReturnLine>(STORAGE_KEYS.RETURN_LINES);
    const index = lines.findIndex(line => line.return_line_id === id);
    if (index === -1) return null;

    lines[index] = { ...lines[index], ...updates };
    saveToStorage(STORAGE_KEYS.RETURN_LINES, lines);
    return lines[index];
  },
};

export const inventoryTransactionStore = {
  getAll: (): InventoryTransaction[] => getFromStorage<InventoryTransaction>(STORAGE_KEYS.INVENTORY_TRANSACTIONS),

  getByItemId: (itemId: string): InventoryTransaction[] => {
    const transactions = getFromStorage<InventoryTransaction>(STORAGE_KEYS.INVENTORY_TRANSACTIONS);
    return transactions.filter(txn => txn.item_id === itemId);
  },

  getByBatchId: (batchId: string): InventoryTransaction[] => {
    const transactions = getFromStorage<InventoryTransaction>(STORAGE_KEYS.INVENTORY_TRANSACTIONS);
    return transactions.filter(txn => txn.batch_id === batchId);
  },
};

export function createInventoryTransaction(
  transaction: Omit<InventoryTransaction, 'txn_id' | 'created_at'>
): InventoryTransaction {
  const transactions = getFromStorage<InventoryTransaction>(STORAGE_KEYS.INVENTORY_TRANSACTIONS);
  const newTransaction: InventoryTransaction = {
    ...transaction,
    txn_id: generateId(),
    created_at: new Date().toISOString(),
  };
  transactions.push(newTransaction);
  saveToStorage(STORAGE_KEYS.INVENTORY_TRANSACTIONS, transactions);
  return newTransaction;
}

export function allocateBatchesForOrderLine(orderLineId: string): boolean {
  const orderLine = orderLineStore.getById(orderLineId);
  if (!orderLine) return false;

  const quantityNeeded = orderLine.quantity_ordered - orderLine.quantity_allocated;
  if (quantityNeeded <= 0) return true;

  const availableBatches = batchStore.getAvailableBatchesFEFO(orderLine.item_id, quantityNeeded);

  let remainingQty = quantityNeeded;

  for (const batch of availableBatches) {
    if (remainingQty <= 0) break;

    const qtyToAllocate = Math.min(remainingQty, batch.quantity_available);

    batchAllocationStore.create({
      order_line_id: orderLineId,
      batch_id: batch.batch_id,
      quantity_allocated: qtyToAllocate,
      status: 'Allocated',
    });

    remainingQty -= qtyToAllocate;
  }

  orderLineStore.update(orderLineId, {
    quantity_allocated: orderLine.quantity_ordered - remainingQty,
  });

  return remainingQty === 0;
}

export function calculateOrderLineTotals(
  quantity: number,
  unitPrice: number,
  discount: number,
  taxRate: number
): { lineNetAmount: number; lineTaxAmount: number; lineTotal: number } {
  const lineNetAmount = quantity * unitPrice - discount;
  const lineTaxAmount = lineNetAmount * (taxRate / 100);
  const lineTotal = lineNetAmount + lineTaxAmount;

  return {
    lineNetAmount: Math.round(lineNetAmount * 100) / 100,
    lineTaxAmount: Math.round(lineTaxAmount * 100) / 100,
    lineTotal: Math.round(lineTotal * 100) / 100,
  };
}

export function calculateOrderTotals(orderId: string): void {
  const lines = orderLineStore.getByOrderId(orderId);

  const subtotal = lines.reduce((sum, line) => sum + line.line_net_amount, 0);
  const totalTax = lines.reduce((sum, line) => sum + line.line_tax_amount, 0);

  const order = orderStore.getById(orderId);
  if (!order) return;

  const grandTotal = subtotal + totalTax + order.shipping_charges + order.other_charges - order.total_discount;

  orderStore.update(orderId, {
    subtotal: Math.round(subtotal * 100) / 100,
    total_tax: Math.round(totalTax * 100) / 100,
    grand_total: Math.round(grandTotal * 100) / 100,
  });
}
