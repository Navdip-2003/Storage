export type OrderType = 'Sales' | 'Purchase' | 'Transfer' | 'Return';
export type OrderStatus = 'Draft' | 'Confirmed' | 'Allocated' | 'Picking' | 'Packed' | 'Shipped' | 'Delivered' | 'Closed' | 'Cancelled';
export type BatchStatus = 'Active' | 'Quarantined' | 'Expired' | 'Disposed' | 'Blocked';
export type ReturnStatus = 'Requested' | 'Received' | 'QC' | 'Approved' | 'Rejected' | 'Processed' | 'Closed';
export type ItemForm = 'Tablet' | 'Syrup' | 'Injection' | 'Ointment' | 'Capsule' | 'Cream' | 'Drops' | 'Powder' | 'Other';
export type ItemCondition = 'Sealed' | 'Opened' | 'Damaged';
export type QCOutcome = 'Restock' | 'Dispose' | 'Quarantine';
export type AllocationStatus = 'Allocated' | 'Picked' | 'Packed' | 'Shipped' | 'Cancelled';
export type TransactionType = 'Receipt' | 'Issue' | 'Adjustment' | 'Return' | 'Dispose';

export interface Item {
  item_id: string;
  sku: string;
  barcode?: string;
  generic_name: string;
  brand_name?: string;
  form: ItemForm;
  strength?: string;
  pack_size: number;
  base_unit: string;
  reorder_level: number;
  taxable: boolean;
  tax_category?: string;
  is_prescription_required: boolean;
  controlled_substance_flag: boolean;
  default_unit_cost: number;
  default_selling_price: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Batch {
  batch_id: string;
  batch_number: string;
  item_id: string;
  manufacture_date?: string;
  expiry_date: string;
  warehouse_id?: string;
  quantity_received: number;
  quantity_available: number;
  quantity_reserved: number;
  quantity_allocated: number;
  unit_cost: number;
  unit_selling_price: number;
  supplier_batch_ref?: string;
  status: BatchStatus;
  created_at: string;
  updated_at: string;
}

export interface Order {
  order_id: string;
  order_number: string;
  order_type: OrderType;
  status: OrderStatus;
  customer_id?: string;
  supplier_id?: string;
  order_date: string;
  requested_delivery_date?: string;
  payment_terms?: string;
  currency: string;
  exchange_rate: number;
  subtotal: number;
  total_discount: number;
  total_tax: number;
  shipping_charges: number;
  other_charges: number;
  grand_total: number;
  reference_number?: string;
  notes?: string;
  is_backorder_allowed: boolean;
  created_by?: string;
  created_at: string;
  updated_by?: string;
  updated_at: string;
}

export interface OrderLine {
  order_line_id: string;
  order_id: string;
  line_number: number;
  item_id: string;
  item_name: string;
  uom: string;
  quantity_ordered: number;
  quantity_allocated: number;
  quantity_picked: number;
  unit_price: number;
  line_discount: number;
  tax_rate: number;
  line_net_amount: number;
  line_tax_amount: number;
  line_total: number;
  batch_requirement: boolean;
  prescription_required: boolean;
  returnable: boolean;
  notes?: string;
  created_at: string;
}

export interface BatchAllocation {
  allocation_id: string;
  order_line_id: string;
  batch_id: string;
  quantity_allocated: number;
  allocation_date: string;
  picked_by?: string;
  picked_at?: string;
  status: AllocationStatus;
}

export interface OrderReturn {
  return_id: string;
  return_number: string;
  original_order_id?: string;
  return_date: string;
  status: ReturnStatus;
  return_reason?: string;
  refund_type?: string;
  total_refund_amount: number;
  notes?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface ReturnLine {
  return_line_id: string;
  return_id: string;
  original_order_line_id?: string;
  item_id: string;
  batch_id?: string;
  quantity_returned: number;
  condition: ItemCondition;
  qc_outcome?: QCOutcome;
  refund_amount: number;
  restock: boolean;
  created_at: string;
}

export interface InventoryTransaction {
  txn_id: string;
  txn_type: TransactionType;
  ref_number?: string;
  item_id: string;
  batch_id?: string;
  quantity: number;
  unit_cost: number;
  warehouse_id?: string;
  created_at: string;
  created_by?: string;
}
