import { useState, useEffect } from 'react';
import { Plus, Search, Eye, X, AlertCircle, Check } from 'lucide-react';
import {
  orderStore,
  orderLineStore,
  itemStore,
  batchAllocationStore,
  allocateBatchesForOrderLine,
  calculateOrderLineTotals,
  calculateOrderTotals,
} from '../lib/dataStore';
import { Order, OrderStatus, OrderType, Item, OrderLine, BatchAllocation } from '../types';

const ORDER_TYPES: OrderType[] = ['Sales', 'Purchase', 'Transfer', 'Return'];
const ORDER_STATUSES: OrderStatus[] = ['Draft', 'Confirmed', 'Allocated', 'Picking', 'Packed', 'Shipped', 'Delivered', 'Closed', 'Cancelled'];

export default function OrdersManager() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'All'>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = () => {
    setOrders(orderStore.getAll());
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch =
      order.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.reference_number?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || order.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Orders</h1>
          <p className="mt-2 text-slate-600">Manage sales, purchase, and transfer orders</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Order
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by order number or reference..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as OrderStatus | 'All')}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="All">All Statuses</option>
            {ORDER_STATUSES.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Order Number</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grand Total</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-slate-500">
                    No orders found. Create your first order to get started.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => (
                  <tr key={order.order_id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{order.order_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{order.order_type}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{order.order_date}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        order.status === 'Draft' ? 'bg-slate-100 text-slate-800' :
                        order.status === 'Confirmed' ? 'bg-blue-100 text-blue-800' :
                        order.status === 'Delivered' ? 'bg-green-100 text-green-800' :
                        order.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                      ${order.grand_total.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => setViewingOrder(order)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <OrderModal
          onClose={() => setIsModalOpen(false)}
          onSave={() => {
            loadOrders();
            setIsModalOpen(false);
          }}
        />
      )}

      {viewingOrder && (
        <OrderDetailsModal
          order={viewingOrder}
          onClose={() => setViewingOrder(null)}
          onUpdate={() => {
            loadOrders();
            setViewingOrder(null);
          }}
        />
      )}
    </div>
  );
}

interface OrderModalProps {
  onClose: () => void;
  onSave: () => void;
}

function OrderModal({ onClose, onSave }: OrderModalProps) {
  const [items, setItems] = useState<Item[]>([]);
  const [orderData, setOrderData] = useState({
    order_type: 'Sales' as OrderType,
    order_date: new Date().toISOString().split('T')[0],
    requested_delivery_date: '',
    payment_terms: '',
    currency: 'USD',
    exchange_rate: 1.0,
    shipping_charges: 0,
    other_charges: 0,
    total_discount: 0,
    reference_number: '',
    notes: '',
    is_backorder_allowed: false,
  });

  const [lines, setLines] = useState<Array<{
    item_id: string;
    quantity_ordered: number;
    unit_price: number;
    line_discount: number;
    tax_rate: number;
  }>>([]);

  useEffect(() => {
    setItems(itemStore.getAll().filter(i => i.is_active));
  }, []);

  const addLine = () => {
    setLines([...lines, {
      item_id: items[0]?.item_id || '',
      quantity_ordered: 1,
      unit_price: 0,
      line_discount: 0,
      tax_rate: 0,
    }]);
  };

  const removeLine = (index: number) => {
    setLines(lines.filter((_, i) => i !== index));
  };

  const updateLine = (index: number, updates: Partial<typeof lines[0]>) => {
    const newLines = [...lines];
    newLines[index] = { ...newLines[index], ...updates };
    setLines(newLines);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (lines.length === 0) {
      alert('Please add at least one order line');
      return;
    }

    const order = orderStore.create({
      ...orderData,
      status: 'Draft',
      subtotal: 0,
      total_tax: 0,
      grand_total: 0,
    });

    lines.forEach((line, index) => {
      const item = items.find(i => i.item_id === line.item_id);
      if (!item) return;

      const { lineNetAmount, lineTaxAmount, lineTotal } = calculateOrderLineTotals(
        line.quantity_ordered,
        line.unit_price,
        line.line_discount,
        line.tax_rate
      );

      orderLineStore.create({
        order_id: order.order_id,
        line_number: index + 1,
        item_id: line.item_id,
        item_name: item.generic_name,
        uom: item.base_unit,
        quantity_ordered: line.quantity_ordered,
        quantity_allocated: 0,
        quantity_picked: 0,
        unit_price: line.unit_price,
        line_discount: line.line_discount,
        tax_rate: line.tax_rate,
        line_net_amount: lineNetAmount,
        line_tax_amount: lineTaxAmount,
        line_total: lineTotal,
        batch_requirement: true,
        prescription_required: item.is_prescription_required,
        returnable: true,
      });
    });

    calculateOrderTotals(order.order_id);

    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-900">Create New Order</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Order Type</label>
              <select
                value={orderData.order_type}
                onChange={(e) => setOrderData({ ...orderData, order_type: e.target.value as OrderType })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {ORDER_TYPES.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Order Date</label>
              <input
                type="date"
                value={orderData.order_date}
                onChange={(e) => setOrderData({ ...orderData, order_date: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Requested Delivery Date</label>
              <input
                type="date"
                value={orderData.requested_delivery_date}
                onChange={(e) => setOrderData({ ...orderData, requested_delivery_date: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Payment Terms</label>
              <input
                type="text"
                value={orderData.payment_terms}
                onChange={(e) => setOrderData({ ...orderData, payment_terms: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Reference Number</label>
              <input
                type="text"
                value={orderData.reference_number}
                onChange={(e) => setOrderData({ ...orderData, reference_number: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Currency</label>
              <input
                type="text"
                value={orderData.currency}
                onChange={(e) => setOrderData({ ...orderData, currency: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
            <textarea
              rows={2}
              value={orderData.notes}
              onChange={(e) => setOrderData({ ...orderData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold text-slate-900">Order Lines</h3>
              <button
                type="button"
                onClick={addLine}
                className="inline-flex items-center px-3 py-1 border border-transparent rounded-md text-sm font-medium text-white bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Line
              </button>
            </div>

            {lines.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-lg">
                <p className="text-slate-500">No order lines yet. Click "Add Line" to start.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {lines.map((line, index) => {
                  const selectedItem = items.find(i => i.item_id === line.item_id);
                  return (
                    <div key={index} className="p-4 border border-slate-200 rounded-lg bg-slate-50">
                      <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
                        <div className="md:col-span-2">
                          <label className="block text-xs font-medium text-slate-700 mb-1">Item</label>
                          <select
                            value={line.item_id}
                            onChange={(e) => {
                              const item = items.find(i => i.item_id === e.target.value);
                              updateLine(index, {
                                item_id: e.target.value,
                                unit_price: item?.default_selling_price || 0,
                                tax_rate: item?.taxable ? 10 : 0,
                              });
                            }}
                            className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                          >
                            {items.map(item => (
                              <option key={item.item_id} value={item.item_id}>
                                {item.generic_name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">Quantity</label>
                          <input
                            type="number"
                            min="1"
                            value={line.quantity_ordered}
                            onChange={(e) => updateLine(index, { quantity_ordered: parseInt(e.target.value) })}
                            className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">Unit Price</label>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={line.unit_price}
                            onChange={(e) => updateLine(index, { unit_price: parseFloat(e.target.value) })}
                            className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">Discount</label>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={line.line_discount}
                            onChange={(e) => updateLine(index, { line_discount: parseFloat(e.target.value) })}
                            className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                          />
                        </div>

                        <div className="flex items-end">
                          <button
                            type="button"
                            onClick={() => removeLine(index)}
                            className="w-full px-2 py-1 text-sm text-red-600 hover:text-red-800 border border-red-300 rounded-md hover:bg-red-50"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      {selectedItem && (
                        <div className="mt-2 text-xs text-slate-600">
                          Stock: {selectedItem.base_unit} | Cost: ${selectedItem.default_unit_cost.toFixed(2)}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              Create Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface OrderDetailsModalProps {
  order: Order;
  onClose: () => void;
  onUpdate: () => void;
}

function OrderDetailsModal({ order, onClose, onUpdate }: OrderDetailsModalProps) {
  const [lines, setLines] = useState<OrderLine[]>([]);
  const [allocations, setAllocations] = useState<Record<string, BatchAllocation[]>>({});

  useEffect(() => {
    loadOrderDetails();
  }, [order.order_id]);

  const loadOrderDetails = () => {
    const orderLines = orderLineStore.getByOrderId(order.order_id);
    setLines(orderLines);

    const allocs: Record<string, BatchAllocation[]> = {};
    orderLines.forEach(line => {
      allocs[line.order_line_id] = batchAllocationStore.getByOrderLineId(line.order_line_id);
    });
    setAllocations(allocs);
  };

  const handleStatusChange = (newStatus: OrderStatus) => {
    orderStore.updateStatus(order.order_id, newStatus);

    if (newStatus === 'Confirmed') {
      lines.forEach(line => {
        allocateBatchesForOrderLine(line.order_line_id);
      });
      loadOrderDetails();
    }

    onUpdate();
  };

  const canTransitionTo = (status: OrderStatus): boolean => {
    const transitions: Record<OrderStatus, OrderStatus[]> = {
      Draft: ['Confirmed', 'Cancelled'],
      Confirmed: ['Allocated', 'Cancelled'],
      Allocated: ['Picking', 'Cancelled'],
      Picking: ['Packed', 'Cancelled'],
      Packed: ['Shipped', 'Cancelled'],
      Shipped: ['Delivered', 'Cancelled'],
      Delivered: ['Closed'],
      Closed: [],
      Cancelled: [],
    };

    return transitions[order.status]?.includes(status) || false;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Order {order.order_number}</h2>
            <p className="text-sm text-slate-600 mt-1">{order.order_type} Order</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-sm text-slate-500">Status</div>
              <div className="mt-1 font-semibold text-slate-900">{order.status}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Order Date</div>
              <div className="mt-1 font-semibold text-slate-900">{order.order_date}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Grand Total</div>
              <div className="mt-1 font-semibold text-slate-900">${order.grand_total.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Reference</div>
              <div className="mt-1 font-semibold text-slate-900">{order.reference_number || '-'}</div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Status Workflow</h3>
            <div className="flex flex-wrap gap-2">
              {ORDER_STATUSES.map(status => (
                <button
                  key={status}
                  onClick={() => canTransitionTo(status) && handleStatusChange(status)}
                  disabled={!canTransitionTo(status)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    order.status === status
                      ? 'bg-blue-600 text-white'
                      : canTransitionTo(status)
                      ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      : 'bg-slate-50 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {order.status === status && <Check className="inline h-3 w-3 mr-1" />}
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Order Lines</h3>
            <div className="space-y-4">
              {lines.map(line => {
                const lineAllocations = allocations[line.order_line_id] || [];
                const fullyAllocated = line.quantity_ordered === line.quantity_allocated;

                return (
                  <div key={line.order_line_id} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold text-slate-900">{line.item_name}</h4>
                        <p className="text-sm text-slate-600">
                          Quantity: {line.quantity_ordered} {line.uom} | Unit Price: ${line.unit_price.toFixed(2)}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-slate-900">${line.line_total.toFixed(2)}</div>
                        <div className={`text-xs flex items-center justify-end mt-1 ${
                          fullyAllocated ? 'text-green-600' : 'text-amber-600'
                        }`}>
                          {fullyAllocated ? (
                            <>
                              <Check className="h-3 w-3 mr-1" />
                              Fully Allocated
                            </>
                          ) : (
                            <>
                              <AlertCircle className="h-3 w-3 mr-1" />
                              {line.quantity_allocated}/{line.quantity_ordered} Allocated
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {lineAllocations.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-200">
                        <div className="text-xs font-medium text-slate-700 mb-2">Batch Allocations:</div>
                        <div className="space-y-1">
                          {lineAllocations.map(alloc => (
                            <div key={alloc.allocation_id} className="text-xs text-slate-600 flex justify-between">
                              <span>Batch: {alloc.batch_id.substring(0, 8)}... - Qty: {alloc.quantity_allocated}</span>
                              <span className="text-slate-500">{alloc.status}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4">
            <div className="flex justify-end space-y-2">
              <div className="text-right space-y-1">
                <div className="flex justify-between gap-8">
                  <span className="text-slate-600">Subtotal:</span>
                  <span className="font-semibold">${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between gap-8">
                  <span className="text-slate-600">Tax:</span>
                  <span className="font-semibold">${order.total_tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between gap-8">
                  <span className="text-slate-600">Shipping:</span>
                  <span className="font-semibold">${order.shipping_charges.toFixed(2)}</span>
                </div>
                <div className="flex justify-between gap-8 text-lg pt-2 border-t">
                  <span className="font-semibold text-slate-900">Grand Total:</span>
                  <span className="font-bold text-slate-900">${order.grand_total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
