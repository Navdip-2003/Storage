import { useEffect, useState } from 'react';
import { AlertTriangle, Package, ShoppingCart, RotateCcw, TrendingUp } from 'lucide-react';
import { itemStore, batchStore, orderStore, orderReturnStore } from '../lib/dataStore';
import { Batch } from '../types';

export default function Dashboard() {
  const [expiringBatches30, setExpiringBatches30] = useState<Batch[]>([]);
  const [expiringBatches90, setExpiringBatches90] = useState<Batch[]>([]);
  const [stats, setStats] = useState({
    totalItems: 0,
    activeBatches: 0,
    openOrders: 0,
    pendingReturns: 0,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    const batches30 = batchStore.getExpiringBatches(30);
    const batches90 = batchStore.getExpiringBatches(90);
    setExpiringBatches30(batches30);
    setExpiringBatches90(batches90);

    const items = itemStore.getAll();
    const batches = batchStore.getAll();
    const orders = orderStore.getAll();
    const returns = orderReturnStore.getAll();

    setStats({
      totalItems: items.filter(i => i.is_active).length,
      activeBatches: batches.filter(b => b.status === 'Active' && b.quantity_available > 0).length,
      openOrders: orders.filter(o => !['Closed', 'Cancelled', 'Delivered'].includes(o.status)).length,
      pendingReturns: returns.filter(r => !['Closed', 'Rejected'].includes(r.status)).length,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="mt-2 text-slate-600">Overview of your medical inventory system</p>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Items"
          value={stats.totalItems}
          icon={<Package className="h-6 w-6" />}
          color="blue"
        />
        <StatCard
          title="Active Batches"
          value={stats.activeBatches}
          icon={<TrendingUp className="h-6 w-6" />}
          color="green"
        />
        <StatCard
          title="Open Orders"
          value={stats.openOrders}
          icon={<ShoppingCart className="h-6 w-6" />}
          color="amber"
        />
        <StatCard
          title="Pending Returns"
          value={stats.pendingReturns}
          icon={<RotateCcw className="h-6 w-6" />}
          color="red"
        />
      </div>

      {expiringBatches30.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-semibold text-red-900">
                Critical: {expiringBatches30.length} batch(es) expiring within 30 days
              </h3>
              <div className="mt-2 text-sm text-red-700">
                <ul className="list-disc list-inside space-y-1">
                  {expiringBatches30.slice(0, 5).map(batch => {
                    const item = itemStore.getById(batch.item_id);
                    return (
                      <li key={batch.batch_id}>
                        {item?.generic_name} - Batch {batch.batch_number} - Expires: {batch.expiry_date} - Qty: {batch.quantity_available}
                      </li>
                    );
                  })}
                </ul>
                {expiringBatches30.length > 5 && (
                  <p className="mt-2 text-xs">and {expiringBatches30.length - 5} more...</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {expiringBatches90.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-semibold text-amber-900">
                Warning: {expiringBatches90.length} batch(es) expiring within 90 days
              </h3>
              <div className="mt-2 text-sm text-amber-700">
                <ul className="list-disc list-inside space-y-1">
                  {expiringBatches90.slice(0, 5).map(batch => {
                    const item = itemStore.getById(batch.item_id);
                    return (
                      <li key={batch.batch_id}>
                        {item?.generic_name} - Batch {batch.batch_number} - Expires: {batch.expiry_date} - Qty: {batch.quantity_available}
                      </li>
                    );
                  })}
                </ul>
                {expiringBatches90.length > 5 && (
                  <p className="mt-2 text-xs">and {expiringBatches90.length - 5} more...</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-left">
            <Package className="h-6 w-6 text-blue-600 mb-2" />
            <div className="font-medium text-slate-900">Add New Item</div>
            <div className="text-sm text-slate-500">Register medicine</div>
          </button>
          <button className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-left">
            <TrendingUp className="h-6 w-6 text-green-600 mb-2" />
            <div className="font-medium text-slate-900">Receive Batch</div>
            <div className="text-sm text-slate-500">Add inventory</div>
          </button>
          <button className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-left">
            <ShoppingCart className="h-6 w-6 text-amber-600 mb-2" />
            <div className="font-medium text-slate-900">Create Order</div>
            <div className="text-sm text-slate-500">New sales order</div>
          </button>
          <button className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-left">
            <RotateCcw className="h-6 w-6 text-red-600 mb-2" />
            <div className="font-medium text-slate-900">Process Return</div>
            <div className="text-sm text-slate-500">Handle returns</div>
          </button>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'amber' | 'red';
}

function StatCard({ title, value, icon, color }: StatCardProps) {
  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    amber: 'bg-amber-500',
    red: 'bg-red-500',
  };

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${colorClasses[color]} rounded-md p-3 text-white`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-slate-500 truncate">{title}</dt>
              <dd className="text-3xl font-semibold text-slate-900">{value}</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}
