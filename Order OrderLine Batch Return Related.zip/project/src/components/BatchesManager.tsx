import { useState, useEffect } from 'react';
import { Plus, Search, AlertCircle, X } from 'lucide-react';
import { batchStore, itemStore } from '../lib/dataStore';
import { Batch, BatchStatus, Item } from '../types';

const BATCH_STATUSES: BatchStatus[] = ['Active', 'Quarantined', 'Expired', 'Disposed', 'Blocked'];

export default function BatchesManager() {
  const [batches, setBatches] = useState<Batch[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<BatchStatus | 'All'>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setBatches(batchStore.getAll());
    setItems(itemStore.getAll());
  };

  const filteredBatches = batches.filter(batch => {
    const item = items.find(i => i.item_id === batch.item_id);
    const matchesSearch =
      batch.batch_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item?.generic_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item?.brand_name?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || batch.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getItemName = (itemId: string) => {
    const item = items.find(i => i.item_id === itemId);
    return item ? item.generic_name : 'Unknown Item';
  };

  const isExpiringSoon = (expiryDate: string) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays <= 90 && diffDays > 0;
  };

  const isExpired = (expiryDate: string) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    return expiry < today;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Batch Management</h1>
          <p className="mt-2 text-slate-600">Track and manage inventory batches with FEFO allocation</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add Batch
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by batch number or item name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as BatchStatus | 'All')}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="All">All Statuses</option>
            {BATCH_STATUSES.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Batch Number</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Item</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Expiry Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Received</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Available</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Allocated</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Unit Cost</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredBatches.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-8 text-center text-slate-500">
                    No batches found. Add your first batch to get started.
                  </td>
                </tr>
              ) : (
                filteredBatches.map((batch) => (
                  <tr
                    key={batch.batch_id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isExpired(batch.expiry_date) ? 'bg-red-50' : isExpiringSoon(batch.expiry_date) ? 'bg-amber-50' : ''
                    }`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-slate-900">{batch.batch_number}</span>
                        {(isExpired(batch.expiry_date) || isExpiringSoon(batch.expiry_date)) && (
                          <AlertCircle className={`ml-2 h-4 w-4 ${isExpired(batch.expiry_date) ? 'text-red-500' : 'text-amber-500'}`} />
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">{getItemName(batch.item_id)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{batch.expiry_date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{batch.quantity_received}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{batch.quantity_available}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{batch.quantity_allocated}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">${batch.unit_cost.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        batch.status === 'Active' ? 'bg-green-100 text-green-800' :
                        batch.status === 'Quarantined' ? 'bg-amber-100 text-amber-800' :
                        batch.status === 'Expired' ? 'bg-red-100 text-red-800' :
                        batch.status === 'Disposed' ? 'bg-slate-100 text-slate-800' :
                        'bg-orange-100 text-orange-800'
                      }`}>
                        {batch.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <BatchModal
          items={items}
          onClose={() => setIsModalOpen(false)}
          onSave={() => {
            loadData();
            setIsModalOpen(false);
          }}
        />
      )}
    </div>
  );
}

interface BatchModalProps {
  items: Item[];
  onClose: () => void;
  onSave: () => void;
}

function BatchModal({ items, onClose, onSave }: BatchModalProps) {
  const activeItems = items.filter(i => i.is_active);
  const [formData, setFormData] = useState({
    batch_number: '',
    item_id: activeItems[0]?.item_id || '',
    manufacture_date: '',
    expiry_date: '',
    warehouse_id: '',
    quantity_received: 0,
    unit_cost: 0,
    unit_selling_price: 0,
    supplier_batch_ref: '',
    status: 'Active' as BatchStatus,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.item_id) {
      alert('Please select an item');
      return;
    }

    batchStore.create({
      ...formData,
      quantity_available: formData.quantity_received,
      quantity_reserved: 0,
      quantity_allocated: 0,
    });

    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-900">Add New Batch</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Batch Number <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.batch_number}
                onChange={(e) => setFormData({ ...formData, batch_number: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Item <span className="text-red-500">*</span>
              </label>
              <select
                required
                value={formData.item_id}
                onChange={(e) => {
                  const selectedItem = items.find(i => i.item_id === e.target.value);
                  setFormData({
                    ...formData,
                    item_id: e.target.value,
                    unit_cost: selectedItem?.default_unit_cost || 0,
                    unit_selling_price: selectedItem?.default_selling_price || 0,
                  });
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select an item</option>
                {activeItems.map(item => (
                  <option key={item.item_id} value={item.item_id}>
                    {item.generic_name} {item.brand_name ? `(${item.brand_name})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Manufacture Date</label>
              <input
                type="date"
                value={formData.manufacture_date}
                onChange={(e) => setFormData({ ...formData, manufacture_date: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Expiry Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={formData.expiry_date}
                onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Warehouse ID</label>
              <input
                type="text"
                value={formData.warehouse_id}
                onChange={(e) => setFormData({ ...formData, warehouse_id: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Quantity Received <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                required
                min="1"
                value={formData.quantity_received}
                onChange={(e) => setFormData({ ...formData, quantity_received: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Unit Cost</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.unit_cost}
                onChange={(e) => setFormData({ ...formData, unit_cost: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Unit Selling Price</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.unit_selling_price}
                onChange={(e) => setFormData({ ...formData, unit_selling_price: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Supplier Batch Reference</label>
              <input
                type="text"
                value={formData.supplier_batch_ref}
                onChange={(e) => setFormData({ ...formData, supplier_batch_ref: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as BatchStatus })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {BATCH_STATUSES.map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              Create Batch
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
