import { useState, useEffect } from 'react';
import { Plus, Search, Eye, X } from 'lucide-react';
import {
  orderReturnStore,
  returnLineStore,
  orderStore,
  orderLineStore,
  itemStore,
  batchStore,
} from '../lib/dataStore';
import { OrderReturn, ReturnStatus, ReturnLine, ItemCondition, QCOutcome, Order, Item } from '../types';

const RETURN_STATUSES: ReturnStatus[] = ['Requested', 'Received', 'QC', 'Approved', 'Rejected', 'Processed', 'Closed'];
const ITEM_CONDITIONS: ItemCondition[] = ['Sealed', 'Opened', 'Damaged'];
const QC_OUTCOMES: QCOutcome[] = ['Restock', 'Dispose', 'Quarantine'];

export default function ReturnsManager() {
  const [returns, setReturns] = useState<OrderReturn[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<ReturnStatus | 'All'>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewingReturn, setViewingReturn] = useState<OrderReturn | null>(null);

  useEffect(() => {
    loadReturns();
  }, []);

  const loadReturns = () => {
    setReturns(orderReturnStore.getAll());
  };

  const filteredReturns = returns.filter(ret => {
    const matchesSearch = ret.return_number.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || ret.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Returns Management</h1>
          <p className="mt-2 text-slate-600">Process and track product returns</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Return
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by return number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as ReturnStatus | 'All')}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="All">All Statuses</option>
            {RETURN_STATUSES.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Return Number</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Return Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Refund Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Reason</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredReturns.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-slate-500">
                    No returns found. Create your first return to get started.
                  </td>
                </tr>
              ) : (
                filteredReturns.map((ret) => (
                  <tr key={ret.return_id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{ret.return_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{ret.return_date}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        ret.status === 'Requested' ? 'bg-slate-100 text-slate-800' :
                        ret.status === 'Approved' ? 'bg-green-100 text-green-800' :
                        ret.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                        ret.status === 'Closed' ? 'bg-blue-100 text-blue-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {ret.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                      ${ret.total_refund_amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{ret.return_reason || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => setViewingReturn(ret)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <ReturnModal
          onClose={() => setIsModalOpen(false)}
          onSave={() => {
            loadReturns();
            setIsModalOpen(false);
          }}
        />
      )}

      {viewingReturn && (
        <ReturnDetailsModal
          orderReturn={viewingReturn}
          onClose={() => setViewingReturn(null)}
          onUpdate={() => {
            loadReturns();
            setViewingReturn(null);
          }}
        />
      )}
    </div>
  );
}

interface ReturnModalProps {
  onClose: () => void;
  onSave: () => void;
}

function ReturnModal({ onClose, onSave }: ReturnModalProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [returnData, setReturnData] = useState({
    original_order_id: '',
    return_date: new Date().toISOString().split('T')[0],
    return_reason: '',
    refund_type: 'Full Refund',
    notes: '',
  });

  const [lines, setLines] = useState<Array<{
    item_id: string;
    batch_id: string;
    quantity_returned: number;
    condition: ItemCondition;
    qc_outcome: QCOutcome;
    refund_amount: number;
    restock: boolean;
  }>>([]);

  useEffect(() => {
    setOrders(orderStore.getAll().filter(o => o.status === 'Delivered'));
    setItems(itemStore.getAll());
  }, []);

  const addLine = () => {
    setLines([...lines, {
      item_id: items[0]?.item_id || '',
      batch_id: '',
      quantity_returned: 1,
      condition: 'Sealed',
      qc_outcome: 'Restock',
      refund_amount: 0,
      restock: true,
    }]);
  };

  const removeLine = (index: number) => {
    setLines(lines.filter((_, i) => i !== index));
  };

  const updateLine = (index: number, updates: Partial<typeof lines[0]>) => {
    const newLines = [...lines];
    newLines[index] = { ...newLines[index], ...updates };

    if (updates.qc_outcome) {
      newLines[index].restock = updates.qc_outcome === 'Restock';
    }

    setLines(newLines);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (lines.length === 0) {
      alert('Please add at least one return line');
      return;
    }

    const totalRefundAmount = lines.reduce((sum, line) => sum + line.refund_amount, 0);

    const orderReturn = orderReturnStore.create({
      original_order_id: returnData.original_order_id || undefined,
      return_date: returnData.return_date,
      status: 'Requested',
      return_reason: returnData.return_reason,
      refund_type: returnData.refund_type,
      total_refund_amount: totalRefundAmount,
      notes: returnData.notes,
    });

    lines.forEach(line => {
      returnLineStore.create({
        return_id: orderReturn.return_id,
        item_id: line.item_id,
        batch_id: line.batch_id || undefined,
        quantity_returned: line.quantity_returned,
        condition: line.condition,
        qc_outcome: line.qc_outcome,
        refund_amount: line.refund_amount,
        restock: line.restock,
      });
    });

    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-900">Create Return</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Original Order (Optional)</label>
              <select
                value={returnData.original_order_id}
                onChange={(e) => setReturnData({ ...returnData, original_order_id: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select an order</option>
                {orders.map(order => (
                  <option key={order.order_id} value={order.order_id}>
                    {order.order_number} - {order.order_date}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Return Date</label>
              <input
                type="date"
                value={returnData.return_date}
                onChange={(e) => setReturnData({ ...returnData, return_date: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Return Reason</label>
              <input
                type="text"
                value={returnData.return_reason}
                onChange={(e) => setReturnData({ ...returnData, return_reason: e.target.value })}
                placeholder="e.g., Damaged, Wrong item, Expired"
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Refund Type</label>
              <input
                type="text"
                value={returnData.refund_type}
                onChange={(e) => setReturnData({ ...returnData, refund_type: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
            <textarea
              rows={2}
              value={returnData.notes}
              onChange={(e) => setReturnData({ ...returnData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold text-slate-900">Return Lines</h3>
              <button
                type="button"
                onClick={addLine}
                className="inline-flex items-center px-3 py-1 border border-transparent rounded-md text-sm font-medium text-white bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Line
              </button>
            </div>

            {lines.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-lg">
                <p className="text-slate-500">No return lines yet. Click "Add Line" to start.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {lines.map((line, index) => (
                  <div key={index} className="p-4 border border-slate-200 rounded-lg bg-slate-50">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Item</label>
                        <select
                          value={line.item_id}
                          onChange={(e) => updateLine(index, { item_id: e.target.value })}
                          className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                        >
                          {items.map(item => (
                            <option key={item.item_id} value={item.item_id}>
                              {item.generic_name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Quantity</label>
                        <input
                          type="number"
                          min="1"
                          value={line.quantity_returned}
                          onChange={(e) => updateLine(index, { quantity_returned: parseInt(e.target.value) })}
                          className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Condition</label>
                        <select
                          value={line.condition}
                          onChange={(e) => updateLine(index, { condition: e.target.value as ItemCondition })}
                          className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                        >
                          {ITEM_CONDITIONS.map(cond => (
                            <option key={cond} value={cond}>{cond}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">QC Outcome</label>
                        <select
                          value={line.qc_outcome}
                          onChange={(e) => updateLine(index, { qc_outcome: e.target.value as QCOutcome })}
                          className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                        >
                          {QC_OUTCOMES.map(outcome => (
                            <option key={outcome} value={outcome}>{outcome}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Refund Amount</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={line.refund_amount}
                          onChange={(e) => updateLine(index, { refund_amount: parseFloat(e.target.value) })}
                          className="w-full px-2 py-1 text-sm border border-slate-300 rounded-md"
                        />
                      </div>

                      <div className="flex items-end">
                        <button
                          type="button"
                          onClick={() => removeLine(index)}
                          className="w-full px-2 py-1 text-sm text-red-600 hover:text-red-800 border border-red-300 rounded-md hover:bg-red-50"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center">
                      <input
                        type="checkbox"
                        checked={line.restock}
                        onChange={(e) => updateLine(index, { restock: e.target.checked })}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2 text-xs text-slate-700">Restock to inventory</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              Create Return
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface ReturnDetailsModalProps {
  orderReturn: OrderReturn;
  onClose: () => void;
  onUpdate: () => void;
}

function ReturnDetailsModal({ orderReturn, onClose, onUpdate }: ReturnDetailsModalProps) {
  const [lines, setLines] = useState<ReturnLine[]>([]);

  useEffect(() => {
    loadReturnDetails();
  }, [orderReturn.return_id]);

  const loadReturnDetails = () => {
    setLines(returnLineStore.getByReturnId(orderReturn.return_id));
  };

  const handleStatusChange = (newStatus: ReturnStatus) => {
    orderReturnStore.update(orderReturn.return_id, { status: newStatus });
    onUpdate();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Return {orderReturn.return_number}</h2>
            <p className="text-sm text-slate-600 mt-1">Return Date: {orderReturn.return_date}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <div className="text-sm text-slate-500">Status</div>
              <div className="mt-1 font-semibold text-slate-900">{orderReturn.status}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Refund Amount</div>
              <div className="mt-1 font-semibold text-slate-900">${orderReturn.total_refund_amount.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Reason</div>
              <div className="mt-1 font-semibold text-slate-900">{orderReturn.return_reason || '-'}</div>
            </div>
          </div>

          {orderReturn.notes && (
            <div>
              <div className="text-sm text-slate-500">Notes</div>
              <div className="mt-1 text-slate-900">{orderReturn.notes}</div>
            </div>
          )}

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Status Actions</h3>
            <div className="flex flex-wrap gap-2">
              {RETURN_STATUSES.map(status => (
                <button
                  key={status}
                  onClick={() => handleStatusChange(status)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    orderReturn.status === status
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Return Lines</h3>
            <div className="space-y-3">
              {lines.map(line => {
                const item = itemStore.getById(line.item_id);
                const batch = line.batch_id ? batchStore.getById(line.batch_id) : null;

                return (
                  <div key={line.return_line_id} className="border border-slate-200 rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-slate-900">{item?.generic_name || 'Unknown Item'}</h4>
                        <p className="text-sm text-slate-600 mt-1">
                          Quantity: {line.quantity_returned} | Condition: {line.condition}
                        </p>
                        {batch && (
                          <p className="text-sm text-slate-600">Batch: {batch.batch_number}</p>
                        )}
                        <p className="text-sm text-slate-600">QC Outcome: {line.qc_outcome}</p>
                        {line.restock && (
                          <span className="inline-flex items-center px-2 py-1 mt-2 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            Restocked
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-slate-900">${line.refund_amount.toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
