import { useState } from 'react';
import { Package, ShoppingCart, RotateCcw, Home, PackageOpen } from 'lucide-react';
import Dashboard from './components/Dashboard';
import ItemsManager from './components/ItemsManager';
import BatchesManager from './components/BatchesManager';
import OrdersManager from './components/OrdersManager';
import ReturnsManager from './components/ReturnsManager';

type View = 'dashboard' | 'items' | 'batches' | 'orders' | 'returns';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'items':
        return <ItemsManager />;
      case 'batches':
        return <BatchesManager />;
      case 'orders':
        return <OrdersManager />;
      case 'returns':
        return <ReturnsManager />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Package className="h-8 w-8 text-blue-600" />
                <span className="ml-2 text-xl font-bold text-slate-900">Medical Inventory</span>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                    currentView === 'dashboard'
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </button>
                <button
                  onClick={() => setCurrentView('items')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                    currentView === 'items'
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <Package className="h-4 w-4 mr-2" />
                  Items
                </button>
                <button
                  onClick={() => setCurrentView('batches')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                    currentView === 'batches'
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <PackageOpen className="h-4 w-4 mr-2" />
                  Batches
                </button>
                <button
                  onClick={() => setCurrentView('orders')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                    currentView === 'orders'
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Orders
                </button>
                <button
                  onClick={() => setCurrentView('returns')}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors ${
                    currentView === 'returns'
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Returns
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>
    </div>
  );
}

export default App;
