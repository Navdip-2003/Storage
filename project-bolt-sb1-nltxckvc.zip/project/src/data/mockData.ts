export interface Medicine {
  id: string;
  name: string;
  category: string;
  dosageForm: string;
  strength: string;
  manufacturer: string;
  unitPrice: number;
  reorderLevel: number;
  supplier: string;
  barcode: string;
  unit: string;
}

export interface StockBatch {
  id: string;
  medicineId: string;
  medicineName: string;
  batchNo: string;
  expiryDate: string;
  quantity: number;
  unitPrice: number;
  supplier: string;
  location: string;
  status: 'normal' | 'low' | 'expired' | 'near-expiry';
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  phone: string;
  address: string;
}

export interface Dispense {
  id: string;
  date: string;
  patientId: string;
  patientName: string;
  doctor: string;
  items: {
    medicineId: string;
    medicineName: string;
    quantity: number;
    batchNo: string;
    dosage: string;
  }[];
  dispensedBy: string;
  totalQuantity: number;
}

export interface Invoice {
  id: string;
  invoiceNo: string;
  date: string;
  patientId: string;
  patientName: string;
  items: {
    medicineId: string;
    medicineName: string;
    quantity: number;
    unitPrice: number;
    tax: number;
    discount: number;
    lineTotal: number;
  }[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'paid' | 'pending';
  paymentMethod?: string;
}

export interface Alert {
  id: string;
  type: 'low-stock' | 'expired' | 'near-expiry';
  medicineId: string;
  medicineName: string;
  batchNo?: string;
  message: string;
  date: string;
  acknowledged: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'pharmacist' | 'cashier';
  status: 'active' | 'inactive';
}

export const categories = ['Antibiotics', 'Analgesics', 'Antivirals', 'Vitamins', 'Cardiac', 'Diabetes', 'Respiratory'];
export const dosageForms = ['Tablet', 'Capsule', 'Syrup', 'Injection', 'Cream', 'Drops'];
export const units = ['Strip', 'Bottle', 'Vial', 'Tube', 'Box'];
export const suppliers = ['MedSupply Co.', 'PharmaDirect', 'HealthCare Wholesale', 'Global Meds'];

export const mockMedicines: Medicine[] = [
  {
    id: '1',
    name: 'Amoxicillin',
    category: 'Antibiotics',
    dosageForm: 'Capsule',
    strength: '500mg',
    manufacturer: 'PharmaCorp',
    unitPrice: 15.50,
    reorderLevel: 50,
    supplier: 'MedSupply Co.',
    barcode: 'MED001',
    unit: 'Strip'
  },
  {
    id: '2',
    name: 'Paracetamol',
    category: 'Analgesics',
    dosageForm: 'Tablet',
    strength: '500mg',
    manufacturer: 'HealthGen',
    unitPrice: 5.00,
    reorderLevel: 100,
    supplier: 'PharmaDirect',
    barcode: 'MED002',
    unit: 'Strip'
  },
  {
    id: '3',
    name: 'Ibuprofen',
    category: 'Analgesics',
    dosageForm: 'Tablet',
    strength: '400mg',
    manufacturer: 'MediCore',
    unitPrice: 8.75,
    reorderLevel: 75,
    supplier: 'HealthCare Wholesale',
    barcode: 'MED003',
    unit: 'Strip'
  },
  {
    id: '4',
    name: 'Azithromycin',
    category: 'Antibiotics',
    dosageForm: 'Tablet',
    strength: '250mg',
    manufacturer: 'PharmaCorp',
    unitPrice: 22.00,
    reorderLevel: 40,
    supplier: 'Global Meds',
    barcode: 'MED004',
    unit: 'Strip'
  },
  {
    id: '5',
    name: 'Vitamin C',
    category: 'Vitamins',
    dosageForm: 'Tablet',
    strength: '1000mg',
    manufacturer: 'VitaHealth',
    unitPrice: 12.50,
    reorderLevel: 60,
    supplier: 'MedSupply Co.',
    barcode: 'MED005',
    unit: 'Bottle'
  },
  {
    id: '6',
    name: 'Metformin',
    category: 'Diabetes',
    dosageForm: 'Tablet',
    strength: '500mg',
    manufacturer: 'DiabCare',
    unitPrice: 18.00,
    reorderLevel: 80,
    supplier: 'PharmaDirect',
    barcode: 'MED006',
    unit: 'Strip'
  },
  {
    id: '7',
    name: 'Salbutamol Inhaler',
    category: 'Respiratory',
    dosageForm: 'Inhaler',
    strength: '100mcg',
    manufacturer: 'RespiraMed',
    unitPrice: 45.00,
    reorderLevel: 20,
    supplier: 'Global Meds',
    barcode: 'MED007',
    unit: 'Box'
  },
  {
    id: '8',
    name: 'Atorvastatin',
    category: 'Cardiac',
    dosageForm: 'Tablet',
    strength: '20mg',
    manufacturer: 'CardioHealth',
    unitPrice: 32.00,
    reorderLevel: 50,
    supplier: 'HealthCare Wholesale',
    barcode: 'MED008',
    unit: 'Strip'
  }
];

export const mockStockBatches: StockBatch[] = [
  {
    id: 'B1',
    medicineId: '1',
    medicineName: 'Amoxicillin',
    batchNo: 'BATCH001',
    expiryDate: '2025-12-31',
    quantity: 120,
    unitPrice: 15.50,
    supplier: 'MedSupply Co.',
    location: 'Shelf A1',
    status: 'normal'
  },
  {
    id: 'B2',
    medicineId: '2',
    medicineName: 'Paracetamol',
    batchNo: 'BATCH002',
    expiryDate: '2025-08-15',
    quantity: 45,
    unitPrice: 5.00,
    supplier: 'PharmaDirect',
    location: 'Shelf A2',
    status: 'low'
  },
  {
    id: 'B3',
    medicineId: '3',
    medicineName: 'Ibuprofen',
    batchNo: 'BATCH003',
    expiryDate: '2025-03-20',
    quantity: 200,
    unitPrice: 8.75,
    supplier: 'HealthCare Wholesale',
    location: 'Shelf B1',
    status: 'near-expiry'
  },
  {
    id: 'B4',
    medicineId: '4',
    medicineName: 'Azithromycin',
    batchNo: 'BATCH004',
    expiryDate: '2024-12-01',
    quantity: 30,
    unitPrice: 22.00,
    supplier: 'Global Meds',
    location: 'Shelf B2',
    status: 'expired'
  },
  {
    id: 'B5',
    medicineId: '5',
    medicineName: 'Vitamin C',
    batchNo: 'BATCH005',
    expiryDate: '2026-06-30',
    quantity: 150,
    unitPrice: 12.50,
    supplier: 'MedSupply Co.',
    location: 'Shelf C1',
    status: 'normal'
  },
  {
    id: 'B6',
    medicineId: '6',
    medicineName: 'Metformin',
    batchNo: 'BATCH006',
    expiryDate: '2025-11-15',
    quantity: 180,
    unitPrice: 18.00,
    supplier: 'PharmaDirect',
    location: 'Shelf C2',
    status: 'normal'
  },
  {
    id: 'B7',
    medicineId: '7',
    medicineName: 'Salbutamol Inhaler',
    batchNo: 'BATCH007',
    expiryDate: '2025-09-30',
    quantity: 15,
    unitPrice: 45.00,
    supplier: 'Global Meds',
    location: 'Shelf D1',
    status: 'low'
  },
  {
    id: 'B8',
    medicineId: '8',
    medicineName: 'Atorvastatin',
    batchNo: 'BATCH008',
    expiryDate: '2025-07-20',
    quantity: 95,
    unitPrice: 32.00,
    supplier: 'HealthCare Wholesale',
    location: 'Shelf D2',
    status: 'normal'
  }
];

export const mockPatients: Patient[] = [
  { id: 'P1', name: 'John Smith', age: 45, gender: 'Male', phone: '555-0101', address: '123 Main St' },
  { id: 'P2', name: 'Sarah Johnson', age: 32, gender: 'Female', phone: '555-0102', address: '456 Oak Ave' },
  { id: 'P3', name: 'Michael Brown', age: 58, gender: 'Male', phone: '555-0103', address: '789 Pine Rd' },
  { id: 'P4', name: 'Emily Davis', age: 28, gender: 'Female', phone: '555-0104', address: '321 Elm St' },
  { id: 'P5', name: 'Robert Wilson', age: 65, gender: 'Male', phone: '555-0105', address: '654 Maple Dr' }
];

export const mockDispenses: Dispense[] = [
  {
    id: 'D1',
    date: '2025-10-08',
    patientId: 'P1',
    patientName: 'John Smith',
    doctor: 'Dr. Anderson',
    items: [
      { medicineId: '1', medicineName: 'Amoxicillin', quantity: 2, batchNo: 'BATCH001', dosage: '3 times daily' },
      { medicineId: '2', medicineName: 'Paracetamol', quantity: 1, batchNo: 'BATCH002', dosage: 'As needed' }
    ],
    dispensedBy: 'Pharmacist Alice',
    totalQuantity: 3
  },
  {
    id: 'D2',
    date: '2025-10-09',
    patientId: 'P2',
    patientName: 'Sarah Johnson',
    doctor: 'Dr. Martinez',
    items: [
      { medicineId: '5', medicineName: 'Vitamin C', quantity: 1, batchNo: 'BATCH005', dosage: '1 daily' }
    ],
    dispensedBy: 'Pharmacist Bob',
    totalQuantity: 1
  }
];

export const mockInvoices: Invoice[] = [
  {
    id: 'INV1',
    invoiceNo: 'INV-2025-001',
    date: '2025-10-08',
    patientId: 'P1',
    patientName: 'John Smith',
    items: [
      { medicineId: '1', medicineName: 'Amoxicillin', quantity: 2, unitPrice: 15.50, tax: 2.48, discount: 0, lineTotal: 33.48 },
      { medicineId: '2', medicineName: 'Paracetamol', quantity: 1, unitPrice: 5.00, tax: 0.40, discount: 0, lineTotal: 5.40 }
    ],
    subtotal: 36.00,
    tax: 2.88,
    total: 38.88,
    status: 'paid',
    paymentMethod: 'Cash'
  },
  {
    id: 'INV2',
    invoiceNo: 'INV-2025-002',
    date: '2025-10-09',
    patientId: 'P2',
    patientName: 'Sarah Johnson',
    items: [
      { medicineId: '5', medicineName: 'Vitamin C', quantity: 1, unitPrice: 12.50, tax: 1.00, discount: 1.25, lineTotal: 12.25 }
    ],
    subtotal: 12.50,
    tax: 1.00,
    total: 12.25,
    status: 'pending'
  },
  {
    id: 'INV3',
    invoiceNo: 'INV-2025-003',
    date: '2025-10-10',
    patientId: 'P3',
    patientName: 'Michael Brown',
    items: [
      { medicineId: '6', medicineName: 'Metformin', quantity: 3, unitPrice: 18.00, tax: 4.32, discount: 0, lineTotal: 58.32 }
    ],
    subtotal: 54.00,
    tax: 4.32,
    total: 58.32,
    status: 'paid',
    paymentMethod: 'Card'
  }
];

export const mockAlerts: Alert[] = [
  {
    id: 'A1',
    type: 'expired',
    medicineId: '4',
    medicineName: 'Azithromycin',
    batchNo: 'BATCH004',
    message: 'Batch BATCH004 has expired',
    date: '2025-10-10',
    acknowledged: false
  },
  {
    id: 'A2',
    type: 'low-stock',
    medicineId: '2',
    medicineName: 'Paracetamol',
    batchNo: 'BATCH002',
    message: 'Stock level is below reorder point (45 units)',
    date: '2025-10-09',
    acknowledged: false
  },
  {
    id: 'A3',
    type: 'near-expiry',
    medicineId: '3',
    medicineName: 'Ibuprofen',
    batchNo: 'BATCH003',
    message: 'Batch BATCH003 expires in 5 months',
    date: '2025-10-08',
    acknowledged: false
  },
  {
    id: 'A4',
    type: 'low-stock',
    medicineId: '7',
    medicineName: 'Salbutamol Inhaler',
    batchNo: 'BATCH007',
    message: 'Stock level is below reorder point (15 units)',
    date: '2025-10-07',
    acknowledged: true
  }
];

export const mockUsers: User[] = [
  { id: 'U1', name: 'Admin User', email: 'admin@clinic.com', role: 'admin', status: 'active' },
  { id: 'U2', name: 'Alice Pharmacist', email: 'alice@clinic.com', role: 'pharmacist', status: 'active' },
  { id: 'U3', name: 'Bob Pharmacist', email: 'bob@clinic.com', role: 'pharmacist', status: 'active' },
  { id: 'U4', name: 'Carol Cashier', email: 'carol@clinic.com', role: 'cashier', status: 'active' }
];

export const salesData = {
  monthly: [
    { month: 'Apr', sales: 12500 },
    { month: 'May', sales: 15800 },
    { month: 'Jun', sales: 14200 },
    { month: 'Jul', sales: 17900 },
    { month: 'Aug', sales: 19500 },
    { month: 'Sep', sales: 21000 },
    { month: 'Oct', sales: 18200 }
  ],
  byCategory: [
    { category: 'Antibiotics', value: 28 },
    { category: 'Analgesics', value: 22 },
    { category: 'Vitamins', value: 18 },
    { category: 'Cardiac', value: 12 },
    { category: 'Diabetes', value: 10 },
    { category: 'Respiratory', value: 6 },
    { category: 'Antivirals', value: 4 }
  ],
  expiryDistribution: [
    { status: 'Expired', count: 5 },
    { status: 'Near Expiry (3 months)', count: 12 },
    { status: 'Normal', count: 156 }
  ]
};
