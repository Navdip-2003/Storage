import { DollarSign, Package, AlertTriangle, Calendar, TrendingUp, Plus } from 'lucide-react';
import { mockStockBatches, mockInvoices, salesData } from '../data/mockData';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const totalStockValue = mockStockBatches.reduce((sum, batch) => sum + (batch.quantity * batch.unitPrice), 0);
  const todaysSales = mockInvoices
    .filter(inv => inv.date === '2025-10-10')
    .reduce((sum, inv) => sum + inv.total, 0);
  const lowStockCount = mockStockBatches.filter(b => b.status === 'low').length;
  const expiringCount = mockStockBatches.filter(b => b.status === 'near-expiry' || b.status === 'expired').length;

  const stats = [
    {
      name: 'Total Stock Value',
      value: `$${totalStockValue.toFixed(2)}`,
      icon: DollarSign,
      color: 'from-blue-500 to-blue-600',
      change: '+12.5%',
      changeType: 'increase'
    },
    {
      name: "Today's Sales",
      value: `$${todaysSales.toFixed(2)}`,
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      change: '+8.2%',
      changeType: 'increase'
    },
    {
      name: 'Low Stock Items',
      value: lowStockCount.toString(),
      icon: Package,
      color: 'from-orange-500 to-orange-600',
      change: '2 items',
      changeType: 'warning'
    },
    {
      name: 'Expiring Batches',
      value: expiringCount.toString(),
      icon: AlertTriangle,
      color: 'from-red-500 to-red-600',
      change: 'Next 90 days',
      changeType: 'alert'
    }
  ];

  const quickActions = [
    { label: 'Add Medicine', icon: Plus, action: () => onNavigate('inventory') },
    { label: 'Receive Stock', icon: Package, action: () => onNavigate('inventory') },
    { label: 'New Dispense', icon: Calendar, action: () => onNavigate('dispensing') },
    { label: 'Generate Invoice', icon: DollarSign, action: () => onNavigate('billing') }
  ];

  const maxMonthlySales = Math.max(...salesData.monthly.map(d => d.sales));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">Welcome back! Here's your overview</p>
        </div>
        <div className="mt-4 sm:mt-0 text-sm text-gray-500">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <p className={`text-xs mt-2 ${
                    stat.changeType === 'increase' ? 'text-green-600' :
                    stat.changeType === 'warning' ? 'text-orange-600' :
                    'text-red-600'
                  }`}>
                    {stat.change}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Monthly Sales</h2>
            <select className="text-sm border border-gray-300 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option>Last 7 months</option>
              <option>Last 12 months</option>
            </select>
          </div>
          <div className="h-64">
            <div className="flex items-end justify-between h-full space-x-2">
              {salesData.monthly.map((data) => (
                <div key={data.month} className="flex-1 flex flex-col items-center">
                  <div className="w-full flex items-end justify-center h-48">
                    <div
                      className="w-full bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-lg hover:from-blue-600 hover:to-blue-500 transition-all cursor-pointer relative group"
                      style={{ height: `${(data.sales / maxMonthlySales) * 100}%` }}
                    >
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                        ${data.sales.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs text-gray-600 mt-2 font-medium">{data.month}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Stock by Category</h2>
          <div className="space-y-3">
            {salesData.byCategory.slice(0, 6).map((item) => {
              const maxValue = Math.max(...salesData.byCategory.map(d => d.value));
              const percentage = (item.value / maxValue) * 100;
              return (
                <div key={item.category}>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-700 font-medium">{item.category}</span>
                    <span className="text-gray-500">{item.value}%</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Expiry Distribution</h2>
          <div className="flex items-center justify-center h-48">
            <div className="relative w-48 h-48">
              {salesData.expiryDistribution.map((item, index) => {
                const colors = ['bg-red-500', 'bg-orange-500', 'bg-green-500'];
                const total = salesData.expiryDistribution.reduce((sum, d) => sum + d.count, 0);
                const percentage = (item.count / total) * 100;
                return (
                  <div key={item.status} className="absolute inset-0 flex items-center justify-center">
                    <div className={`w-full h-full rounded-full ${colors[index]} opacity-${30 + index * 20}`} />
                  </div>
                );
              })}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-3xl font-bold text-gray-900">
                    {salesData.expiryDistribution.reduce((sum, d) => sum + d.count, 0)}
                  </p>
                  <p className="text-sm text-gray-500">Total Batches</p>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-6 space-y-2">
            {salesData.expiryDistribution.map((item, index) => {
              const colors = ['text-red-600', 'text-orange-600', 'text-green-600'];
              const bgColors = ['bg-red-100', 'bg-orange-100', 'bg-green-100'];
              return (
                <div key={item.status} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${bgColors[index]}`} />
                    <span className="text-sm text-gray-700">{item.status}</span>
                  </div>
                  <span className={`text-sm font-semibold ${colors[index]}`}>{item.count}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.label}
                  onClick={action.action}
                  className="flex flex-col items-center justify-center p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
                >
                  <div className="w-12 h-12 bg-gray-100 group-hover:bg-blue-100 rounded-full flex items-center justify-center mb-2 transition-colors">
                    <Icon className="w-6 h-6 text-gray-600 group-hover:text-blue-600 transition-colors" />
                  </div>
                  <span className="text-sm font-medium text-gray-700 group-hover:text-blue-700 transition-colors text-center">
                    {action.label}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Recent Activity</h3>
            <div className="space-y-3">
              {[
                { action: 'Invoice generated', detail: 'INV-2025-003 - Michael Brown', time: '5 min ago' },
                { action: 'Stock received', detail: 'Metformin - 100 units', time: '1 hour ago' },
                { action: 'Medicine dispensed', detail: 'Sarah Johnson - 2 items', time: '2 hours ago' }
              ].map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                    <p className="text-xs text-gray-500">{activity.detail}</p>
                  </div>
                  <span className="text-xs text-gray-400 whitespace-nowrap">{activity.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
