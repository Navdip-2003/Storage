import { useState } from 'react';
import { Download, FileText, TrendingUp, Package, AlertTriangle } from 'lucide-react';
import { mockStockBatches, mockInvoices, salesData } from '../data/mockData';

export default function Reports() {
  const [activeTab, setActiveTab] = useState<'inventory' | 'sales' | 'expiry' | 'low-stock'>('inventory');
  const [dateRange, setDateRange] = useState({ from: '2025-09-01', to: '2025-10-10' });

  const tabs = [
    { id: 'inventory', name: 'Inventory', icon: Package },
    { id: 'sales', name: 'Sales', icon: TrendingUp },
    { id: 'expiry', name: 'Expiry', icon: AlertTriangle },
    { id: 'low-stock', name: 'Low Stock', icon: Package }
  ];

  const lowStockItems = mockStockBatches.filter(b => b.status === 'low');
  const expiringItems = mockStockBatches.filter(b => b.status === 'expired' || b.status === 'near-expiry');
  const totalStockValue = mockStockBatches.reduce((sum, b) => sum + (b.quantity * b.unitPrice), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-sm text-gray-500 mt-1">Analytics and insights for your pharmacy</p>
        </div>
        <button className="mt-4 sm:mt-0 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
          <Download className="w-4 h-4" />
          <span>Export Report</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="border-b border-gray-200 p-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex overflow-x-auto space-x-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="font-medium">{tab.name}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="date"
                value={dateRange.from}
                onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-gray-500">to</span>
              <input
                type="date"
                value={dateRange.to}
                onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {activeTab === 'inventory' && (
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                <p className="text-sm font-medium text-blue-700">Total Stock Value</p>
                <p className="text-2xl font-bold text-blue-900 mt-2">${totalStockValue.toFixed(2)}</p>
                <p className="text-xs text-blue-600 mt-1">Across all batches</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200">
                <p className="text-sm font-medium text-green-700">Total Items</p>
                <p className="text-2xl font-bold text-green-900 mt-2">{mockStockBatches.length}</p>
                <p className="text-xs text-green-600 mt-1">Stock batches</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg border border-orange-200">
                <p className="text-sm font-medium text-orange-700">Avg. Value/Batch</p>
                <p className="text-2xl font-bold text-orange-900 mt-2">
                  ${(totalStockValue / mockStockBatches.length).toFixed(2)}
                </p>
                <p className="text-xs text-orange-600 mt-1">Per stock batch</p>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Stock by Category</h3>
              <div className="space-y-3">
                {salesData.byCategory.map((item) => {
                  const maxValue = Math.max(...salesData.byCategory.map(d => d.value));
                  const percentage = (item.value / maxValue) * 100;
                  return (
                    <div key={item.category} className="flex items-center space-x-4">
                      <div className="w-32 text-sm font-medium text-gray-700">{item.category}</div>
                      <div className="flex-1">
                        <div className="w-full bg-gray-100 rounded-full h-8">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-blue-600 h-8 rounded-full flex items-center justify-end pr-3 transition-all"
                            style={{ width: `${percentage}%` }}
                          >
                            <span className="text-white text-sm font-semibold">{item.value}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="overflow-x-auto">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Stock Details</h3>
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Medicine</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Quantity</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Unit Price</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Total Value</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {mockStockBatches.slice(0, 10).map((batch) => (
                    <tr key={batch.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-900">{batch.medicineName}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.quantity}</td>
                      <td className="px-4 py-3 text-gray-700">${batch.unitPrice.toFixed(2)}</td>
                      <td className="px-4 py-3 font-semibold text-gray-900">
                        ${(batch.quantity * batch.unitPrice).toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                          batch.status === 'normal' ? 'bg-green-100 text-green-700' :
                          batch.status === 'low' ? 'bg-orange-100 text-orange-700' :
                          batch.status === 'near-expiry' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {batch.status === 'near-expiry' ? 'Near Expiry' : batch.status.charAt(0).toUpperCase() + batch.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'sales' && (
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200">
                <p className="text-sm font-medium text-green-700">Total Sales</p>
                <p className="text-2xl font-bold text-green-900 mt-2">
                  ${mockInvoices.reduce((sum, inv) => sum + inv.total, 0).toFixed(2)}
                </p>
                <p className="text-xs text-green-600 mt-1">All time</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                <p className="text-sm font-medium text-blue-700">Total Invoices</p>
                <p className="text-2xl font-bold text-blue-900 mt-2">{mockInvoices.length}</p>
                <p className="text-xs text-blue-600 mt-1">Generated</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg border border-orange-200">
                <p className="text-sm font-medium text-orange-700">Avg. Invoice</p>
                <p className="text-2xl font-bold text-orange-900 mt-2">
                  ${(mockInvoices.reduce((sum, inv) => sum + inv.total, 0) / mockInvoices.length).toFixed(2)}
                </p>
                <p className="text-xs text-orange-600 mt-1">Per transaction</p>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Sales Trend</h3>
              <div className="h-64">
                <div className="flex items-end justify-between h-full space-x-2">
                  {salesData.monthly.map((data) => {
                    const maxSales = Math.max(...salesData.monthly.map(d => d.sales));
                    return (
                      <div key={data.month} className="flex-1 flex flex-col items-center">
                        <div className="w-full flex items-end justify-center h-48">
                          <div
                            className="w-full bg-gradient-to-t from-green-500 to-green-400 rounded-t-lg hover:from-green-600 hover:to-green-500 transition-all cursor-pointer relative group"
                            style={{ height: `${(data.sales / maxSales) * 100}%` }}
                          >
                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                              ${data.sales.toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <span className="text-xs text-gray-600 mt-2 font-medium">{data.month}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Invoices</h3>
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Invoice No.</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Patient</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {mockInvoices.map((invoice) => (
                    <tr key={invoice.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-900">{invoice.invoiceNo}</td>
                      <td className="px-4 py-3 text-gray-700">{new Date(invoice.date).toLocaleDateString()}</td>
                      <td className="px-4 py-3 text-gray-700">{invoice.patientName}</td>
                      <td className="px-4 py-3 font-semibold text-gray-900">${invoice.total.toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                          invoice.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                        }`}>
                          {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'expiry' && (
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg border border-red-200">
                <p className="text-sm font-medium text-red-700">Expired</p>
                <p className="text-2xl font-bold text-red-900 mt-2">
                  {mockStockBatches.filter(b => b.status === 'expired').length}
                </p>
                <p className="text-xs text-red-600 mt-1">Batches</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg border border-yellow-200">
                <p className="text-sm font-medium text-yellow-700">Near Expiry</p>
                <p className="text-2xl font-bold text-yellow-900 mt-2">
                  {mockStockBatches.filter(b => b.status === 'near-expiry').length}
                </p>
                <p className="text-xs text-yellow-600 mt-1">Next 90 days</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200">
                <p className="text-sm font-medium text-green-700">Normal</p>
                <p className="text-2xl font-bold text-green-900 mt-2">
                  {mockStockBatches.filter(b => b.status === 'normal' || b.status === 'low').length}
                </p>
                <p className="text-xs text-green-600 mt-1">Safe batches</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Expiring Stock</h3>
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Medicine</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Batch No.</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Expiry Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Quantity</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Value</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {expiringItems.map((batch) => (
                    <tr key={batch.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-900">{batch.medicineName}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.batchNo}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.expiryDate}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.quantity}</td>
                      <td className="px-4 py-3 font-semibold text-gray-900">
                        ${(batch.quantity * batch.unitPrice).toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                          batch.status === 'expired' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {batch.status === 'near-expiry' ? 'Near Expiry' : 'Expired'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'low-stock' && (
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg border border-orange-200">
                <p className="text-sm font-medium text-orange-700">Low Stock Items</p>
                <p className="text-2xl font-bold text-orange-900 mt-2">{lowStockItems.length}</p>
                <p className="text-xs text-orange-600 mt-1">Below reorder level</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg border border-red-200">
                <p className="text-sm font-medium text-red-700">Critical</p>
                <p className="text-2xl font-bold text-red-900 mt-2">
                  {lowStockItems.filter(b => b.quantity < 20).length}
                </p>
                <p className="text-xs text-red-600 mt-1">Urgent restock needed</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                <p className="text-sm font-medium text-blue-700">Restock Value</p>
                <p className="text-2xl font-bold text-blue-900 mt-2">
                  ${lowStockItems.reduce((sum, b) => sum + (b.quantity * b.unitPrice), 0).toFixed(2)}
                </p>
                <p className="text-xs text-blue-600 mt-1">Current value</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Low Stock Details</h3>
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Medicine</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Current Stock</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Batch No.</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Supplier</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Priority</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {lowStockItems.map((batch) => (
                    <tr key={batch.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-900">{batch.medicineName}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.quantity}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.batchNo}</td>
                      <td className="px-4 py-3 text-gray-700">{batch.supplier}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                          batch.quantity < 20 ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'
                        }`}>
                          {batch.quantity < 20 ? 'Critical' : 'Low'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
