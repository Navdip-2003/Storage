import { AlertTriangle, Package, Calendar, CheckCircle } from 'lucide-react';
import { mockAlerts } from '../data/mockData';

export default function Alerts() {
  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'expired':
        return AlertTriangle;
      case 'near-expiry':
        return Calendar;
      case 'low-stock':
        return Package;
      default:
        return AlertTriangle;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'expired':
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          icon: 'bg-red-100 text-red-600',
          title: 'text-red-900',
          message: 'text-red-700'
        };
      case 'near-expiry':
        return {
          bg: 'bg-yellow-50',
          border: 'border-yellow-200',
          icon: 'bg-yellow-100 text-yellow-600',
          title: 'text-yellow-900',
          message: 'text-yellow-700'
        };
      case 'low-stock':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          icon: 'bg-orange-100 text-orange-600',
          title: 'text-orange-900',
          message: 'text-orange-700'
        };
      default:
        return {
          bg: 'bg-gray-50',
          border: 'border-gray-200',
          icon: 'bg-gray-100 text-gray-600',
          title: 'text-gray-900',
          message: 'text-gray-700'
        };
    }
  };

  const unacknowledgedAlerts = mockAlerts.filter(a => !a.acknowledged);
  const acknowledgedAlerts = mockAlerts.filter(a => a.acknowledged);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Alerts</h1>
          <p className="text-sm text-gray-500 mt-1">System notifications and warnings</p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center space-x-2">
          <span className="px-3 py-1.5 bg-red-100 text-red-700 rounded-full text-sm font-semibold">
            {unacknowledgedAlerts.length} Active
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Expired Items</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {mockAlerts.filter(a => a.type === 'expired').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Near Expiry</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {mockAlerts.filter(a => a.type === 'near-expiry').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Low Stock</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {mockAlerts.filter(a => a.type === 'low-stock').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Package className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {unacknowledgedAlerts.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Active Alerts</h2>
          </div>

          <div className="p-4 space-y-3">
            {unacknowledgedAlerts.map((alert) => {
              const Icon = getAlertIcon(alert.type);
              const colors = getAlertColor(alert.type);

              return (
                <div
                  key={alert.id}
                  className={`${colors.bg} ${colors.border} border rounded-lg p-4 hover:shadow-md transition-shadow`}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`${colors.icon} w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className={`font-semibold ${colors.title}`}>
                            {alert.type === 'expired' && 'Expired Medicine'}
                            {alert.type === 'near-expiry' && 'Near Expiry Warning'}
                            {alert.type === 'low-stock' && 'Low Stock Alert'}
                          </h3>
                          <p className={`text-sm mt-1 ${colors.message}`}>
                            <span className="font-medium">{alert.medicineName}</span>
                            {alert.batchNo && ` - Batch: ${alert.batchNo}`}
                          </p>
                          <p className={`text-sm mt-1 ${colors.message}`}>{alert.message}</p>
                        </div>
                        <button className="ml-4 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap">
                          Acknowledge
                        </button>
                      </div>
                      <div className="flex items-center mt-3 text-xs text-gray-500">
                        <span>{new Date(alert.date).toLocaleDateString()} at {new Date(alert.date).toLocaleTimeString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {acknowledgedAlerts.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Acknowledged Alerts</h2>
          </div>

          <div className="p-4 space-y-3">
            {acknowledgedAlerts.map((alert) => {
              const Icon = getAlertIcon(alert.type);

              return (
                <div
                  key={alert.id}
                  className="bg-gray-50 border border-gray-200 rounded-lg p-4"
                >
                  <div className="flex items-start space-x-4">
                    <div className="bg-gray-100 text-gray-400 w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-700">
                            {alert.type === 'expired' && 'Expired Medicine'}
                            {alert.type === 'near-expiry' && 'Near Expiry Warning'}
                            {alert.type === 'low-stock' && 'Low Stock Alert'}
                          </h3>
                          <p className="text-sm mt-1 text-gray-600">
                            <span className="font-medium">{alert.medicineName}</span>
                            {alert.batchNo && ` - Batch: ${alert.batchNo}`}
                          </p>
                          <p className="text-sm mt-1 text-gray-600">{alert.message}</p>
                        </div>
                        <div className="ml-4 flex items-center space-x-2 text-green-600">
                          <CheckCircle className="w-5 h-5" />
                          <span className="text-sm font-medium">Acknowledged</span>
                        </div>
                      </div>
                      <div className="flex items-center mt-3 text-xs text-gray-500">
                        <span>{new Date(alert.date).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {mockAlerts.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">All Clear!</h3>
          <p className="text-gray-500">No active alerts at the moment</p>
        </div>
      )}
    </div>
  );
}
