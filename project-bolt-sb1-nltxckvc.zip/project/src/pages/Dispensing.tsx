import { useState } from 'react';
import { Plus, Trash2, X, Calendar } from 'lucide-react';
import { mockPatients, mockMedicines, mockDispenses, mockStockBatches } from '../data/mockData';

export default function Dispensing() {
  const [view, setView] = useState<'list' | 'new'>('list');
  const [lineItems, setLineItems] = useState([{ id: 1, medicineId: '', quantity: 0, batchNo: '', dosage: '' }]);

  const addLineItem = () => {
    setLineItems([...lineItems, { id: Date.now(), medicineId: '', quantity: 0, batchNo: '', dosage: '' }]);
  };

  const removeLineItem = (id: number) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter(item => item.id !== id));
    }
  };

  const getAvailableStock = (medicineId: string) => {
    const batches = mockStockBatches.filter(b => b.medicineId === medicineId && b.status !== 'expired');
    return batches.reduce((sum, b) => sum + b.quantity, 0);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dispensing</h1>
          <p className="text-sm text-gray-500 mt-1">Manage medicine dispensing to patients</p>
        </div>
        {view === 'list' && (
          <button
            onClick={() => setView('new')}
            className="mt-4 sm:mt-0 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Dispense</span>
          </button>
        )}
      </div>

      {view === 'list' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Dispense History</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Patient</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider hidden md:table-cell">Doctor</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Items</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider hidden lg:table-cell">Dispensed By</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {mockDispenses.map((dispense) => (
                  <tr key={dispense.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 text-gray-700">
                      {new Date(dispense.date).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-4">
                      <p className="font-medium text-gray-900">{dispense.patientName}</p>
                    </td>
                    <td className="px-4 py-4 text-gray-700 hidden md:table-cell">{dispense.doctor}</td>
                    <td className="px-4 py-4">
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium">
                        {dispense.items.length} {dispense.items.length === 1 ? 'item' : 'items'}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-gray-700 hidden lg:table-cell">{dispense.dispensedBy}</td>
                    <td className="px-4 py-4">
                      <div className="flex items-center justify-end space-x-2">
                        <button className="px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          View
                        </button>
                        <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
                          Print
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {view === 'new' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">New Dispense</h2>
            <button
              onClick={() => setView('list')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-6 border-b border-gray-200">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Patient <span className="text-red-500">*</span>
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">Select patient</option>
                  {mockPatients.map(patient => (
                    <option key={patient.id} value={patient.id}>
                      {patient.name} - {patient.age}y {patient.gender}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  defaultValue={new Date().toISOString().split('T')[0]}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Doctor</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter doctor name"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-gray-900">Medication Lines</h3>
                <button
                  type="button"
                  onClick={addLineItem}
                  className="px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors flex items-center space-x-1 text-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Line</span>
                </button>
              </div>

              <div className="space-y-3">
                {lineItems.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-1 md:grid-cols-12 gap-3 p-4 bg-gray-50 rounded-lg">
                    <div className="md:col-span-4">
                      <label className="block text-xs font-medium text-gray-700 mb-1">Medicine</label>
                      <select
                        value={item.medicineId}
                        onChange={(e) => {
                          const newItems = [...lineItems];
                          newItems[index].medicineId = e.target.value;
                          setLineItems(newItems);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      >
                        <option value="">Select medicine</option>
                        {mockMedicines.map(med => (
                          <option key={med.id} value={med.id}>
                            {med.name} ({med.strength})
                          </option>
                        ))}
                      </select>
                      {item.medicineId && (
                        <p className="text-xs text-gray-500 mt-1">
                          Available: {getAvailableStock(item.medicineId)} units
                        </p>
                      )}
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-medium text-gray-700 mb-1">Quantity</label>
                      <input
                        type="number"
                        value={item.quantity || ''}
                        onChange={(e) => {
                          const newItems = [...lineItems];
                          newItems[index].quantity = parseInt(e.target.value) || 0;
                          setLineItems(newItems);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        placeholder="0"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-medium text-gray-700 mb-1">Batch No.</label>
                      <input
                        type="text"
                        value={item.batchNo}
                        onChange={(e) => {
                          const newItems = [...lineItems];
                          newItems[index].batchNo = e.target.value;
                          setLineItems(newItems);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        placeholder="Batch"
                      />
                    </div>

                    <div className="md:col-span-3">
                      <label className="block text-xs font-medium text-gray-700 mb-1">Dosage Instructions</label>
                      <input
                        type="text"
                        value={item.dosage}
                        onChange={(e) => {
                          const newItems = [...lineItems];
                          newItems[index].dosage = e.target.value;
                          setLineItems(newItems);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        placeholder="e.g., 3 times daily"
                      />
                    </div>

                    <div className="md:col-span-1 flex items-end">
                      <button
                        type="button"
                        onClick={() => removeLineItem(item.id)}
                        disabled={lineItems.length === 1}
                        className={`w-full p-2 rounded-lg transition-colors ${
                          lineItems.length === 1
                            ? 'text-gray-300 cursor-not-allowed'
                            : 'text-red-600 hover:bg-red-50'
                        }`}
                      >
                        <Trash2 className="w-4 h-4 mx-auto" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={() => setView('list')}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setLineItems([{ id: 1, medicineId: '', quantity: 0, batchNo: '', dosage: '' }])}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Save Dispense
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
