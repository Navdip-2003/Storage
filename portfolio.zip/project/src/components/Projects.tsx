import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { ExternalLink, Github, X } from 'lucide-react';

const Projects = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const projects = [
    {
      title: 'E-Commerce Platform',
      description: 'A full-featured online shopping platform with payment integration, inventory management, and real-time order tracking.',
      fullDescription: 'Built with React, Node.js, and PostgreSQL. Features include user authentication, product catalog, shopping cart, secure payment processing with Stripe, order management, and admin dashboard. Implements real-time notifications using WebSockets.',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'Node.js', 'PostgreSQL', 'Stripe', 'WebSockets'],
      github: '#',
      live: '#',
      gradient: 'from-cyan-500 to-blue-500',
    },
    {
      title: 'AI-Powered Analytics Dashboard',
      description: 'Advanced analytics platform with machine learning insights, predictive modeling, and interactive data visualizations.',
      fullDescription: 'Developed using React, Python, and TensorFlow. Integrates multiple data sources, performs real-time analysis, and provides actionable insights through interactive charts and reports. Features include anomaly detection, trend forecasting, and custom reporting.',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'Python', 'TensorFlow', 'D3.js', 'Redis'],
      github: '#',
      live: '#',
      gradient: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Social Media Management Tool',
      description: 'Comprehensive social media management platform for scheduling posts, analytics, and engagement tracking across multiple platforms.',
      fullDescription: 'Full-stack application built with Next.js and MongoDB. Allows users to manage multiple social accounts, schedule content, track engagement metrics, and generate detailed reports. Includes AI-powered content suggestions and optimal posting time recommendations.',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Next.js', 'MongoDB', 'GraphQL', 'AWS', 'OpenAI'],
      github: '#',
      live: '#',
      gradient: 'from-orange-500 to-red-500',
    },
    {
      title: 'Real-Time Collaboration Tool',
      description: 'A collaborative workspace application with real-time document editing, video conferencing, and project management features.',
      fullDescription: 'Built using React, WebRTC, and Firebase. Supports real-time document collaboration, video/audio calls, screen sharing, task management, and team chat. Implements operational transformation for conflict-free editing and end-to-end encryption for security.',
      image: 'https://images.pexels.com/photos/3184287/pexels-photo-3184287.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'WebRTC', 'Firebase', 'Socket.io', 'Tailwind'],
      github: '#',
      live: '#',
      gradient: 'from-green-500 to-teal-500',
    },
    {
      title: 'Fitness Tracking App',
      description: 'Mobile-first fitness application with workout tracking, nutrition planning, and progress visualization.',
      fullDescription: 'Progressive Web App built with React and Supabase. Features workout logging, exercise library with video demonstrations, meal planning, calorie tracking, progress photos, and social features. Integrates with wearable devices and health apps.',
      image: 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'Supabase', 'PWA', 'Chart.js', 'Tailwind'],
      github: '#',
      live: '#',
      gradient: 'from-yellow-500 to-orange-500',
    },
    {
      title: 'Blockchain Explorer',
      description: 'Decentralized application for exploring blockchain transactions, smart contracts, and cryptocurrency analytics.',
      fullDescription: 'Built with React, Ethers.js, and The Graph. Provides real-time blockchain data, transaction tracking, wallet analytics, smart contract interaction, and DeFi portfolio management. Features advanced search, customizable dashboards, and price alerts.',
      image: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'Ethers.js', 'GraphQL', 'Web3', 'TypeScript'],
      github: '#',
      live: '#',
      gradient: 'from-indigo-500 to-purple-500',
    },
  ];

  return (
    <section id="projects" ref={ref} className="relative py-20 bg-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Featured <span className="bg-gradient-to-r from-cyan-400 to-orange-500 bg-clip-text text-transparent">Projects</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-orange-500 mx-auto"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative cursor-pointer"
              onClick={() => setSelectedProject(index)}
            >
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-orange-500 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-1000"></div>
              <div className="relative bg-slate-900 rounded-lg overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${project.gradient} opacity-0 group-hover:opacity-80 transition-opacity duration-300 flex items-center justify-center`}>
                    <span className="text-white font-semibold text-lg">View Details</span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.slice(0, 3).map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 bg-slate-800 text-cyan-400 text-xs rounded-full border border-cyan-400/30"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                      <span className="px-3 py-1 bg-slate-800 text-gray-400 text-xs rounded-full">
                        +{project.technologies.length - 3}
                      </span>
                    )}
                  </div>
                  <div className="flex space-x-4">
                    <a
                      href={project.github}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center text-gray-400 hover:text-white transition-colors"
                    >
                      <Github size={18} className="mr-1" />
                      <span className="text-sm">Code</span>
                    </a>
                    <a
                      href={project.live}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center text-gray-400 hover:text-white transition-colors"
                    >
                      <ExternalLink size={18} className="mr-1" />
                      <span className="text-sm">Live</span>
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {selectedProject !== null && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedProject(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-slate-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={projects[selectedProject].image}
                alt={projects[selectedProject].title}
                className="w-full h-64 object-cover"
              />
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-slate-900/80 rounded-full flex items-center justify-center text-white hover:bg-slate-800 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-8">
              <h3 className="text-3xl font-bold text-white mb-4">
                {projects[selectedProject].title}
              </h3>
              <p className="text-gray-300 text-lg mb-6">
                {projects[selectedProject].fullDescription}
              </p>
              <div className="mb-6">
                <h4 className="text-xl font-semibold text-white mb-3">Technologies Used</h4>
                <div className="flex flex-wrap gap-3">
                  {projects[selectedProject].technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-slate-800 text-cyan-400 rounded-full border border-cyan-400/30"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex space-x-4">
                <a
                  href={projects[selectedProject].github}
                  className="flex items-center px-6 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
                >
                  <Github size={20} className="mr-2" />
                  View Code
                </a>
                <a
                  href={projects[selectedProject].live}
                  className="flex items-center px-6 py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-shadow"
                >
                  <ExternalLink size={20} className="mr-2" />
                  Live Demo
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </section>
  );
};

export default Projects;
