import { useState, useEffect, useMemo, createContext, useContext } from 'react';
import { BrowserRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import {
  ThemeProvider, createTheme, CssBaseline, AppBar, Toolbar, Typography, Button, IconButton, Drawer,
  List, ListItem, ListItemIcon, ListItemText, ListItemButton, Container, Grid, Card, CardContent,
  TextField, Select, MenuItem, FormControl, InputLabel, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, Paper, Dialog, DialogTitle, DialogContent, DialogActions,
  Alert, Snackbar, Chip, Box, Badge, Avatar, Divider, Checkbox, InputAdornment, Stack, Autocomplete , Tooltip
} from '@mui/material';
import {
  Zoom, Grow, Slide, LinearProgress, Collapse, ToggleButton, ToggleButtonGroup,
  SpeedDial, SpeedDialAction, SpeedDialIcon, Skeleton
} from '@mui/material';
import './App.css';

const theme = createTheme({
  palette: {
    primary: { main: '#667eea', light: '#8b9cff', dark: '#4c5fb7' },
    secondary: { main: '#764ba2', light: '#a571d3', dark: '#512b73' },
    error: { main: '#f44336' },
    warning: { main: '#ff9800' },
    success: { main: '#4caf50' },
    background: { default: '#f5f5f5', paper: '#ffffff' },
  },
  typography: {
    h4: { fontWeight: 600 },
    h5: { fontWeight: 500 },
    h6: { fontWeight: 500 },
  },
  shape: { borderRadius: 12 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { textTransform: 'none', borderRadius: 8, padding: '8px 16px' },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { boxShadow: '0 4px 20px rgba(0,0,0,0.08)', borderRadius: 16 },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': { borderRadius: 8 },
        },
      },
    },
  },
});

// Data Context
const DataContext = createContext();

const DataProvider = ({ children }) => {
  const [medicines, setMedicines] = useState(() => {
    const saved = localStorage.getItem('medicines');
    return saved ? JSON.parse(saved) : [
      { id: 1, name: 'Paracetamol', category: 'Analgesic', dosageForm: 'Tablet', unitSize: '500mg', defaultPrice: 5.99, supplier: 'MedSupply Co', reorderLevel: 100, manufacturer: 'PharmaCorp', barcode: '1234567890' },
      { id: 2, name: 'Amoxicillin', category: 'Antibiotic', dosageForm: 'Capsule', unitSize: '250mg', defaultPrice: 12.99, supplier: 'HealthDist', reorderLevel: 50, manufacturer: 'BioMed', barcode: '0987654321' }
    ];
  });

  const [stock, setStock] = useState(() => {
    const saved = localStorage.getItem('stock');
    return saved ? JSON.parse(saved) : [
      { id: 1, medicineId: 1, batchNo: 'B001', expiryDate: '2025-12-31', quantity: 150, location: 'Shelf A1', supplier: 'MedSupply Co', purchaseDate: '2024-01-15', unitPrice: 5.99 },
      { id: 2, medicineId: 2, batchNo: 'B002', expiryDate: '2024-11-30', quantity: 25, location: 'Shelf B2', supplier: 'HealthDist', purchaseDate: '2024-02-20', unitPrice: 12.99 }
    ];
  });

  const [suppliers, setSuppliers] = useState(() => {
    const saved = localStorage.getItem('suppliers');
    return saved ? JSON.parse(saved) : [
      { id: 1, name: 'MedSupply Co', contact: '555-0001', email: 'contact@medsupply.com', paymentTerms: 'Net 30' },
      { id: 2, name: 'HealthDist', contact: '555-0002', email: 'info@healthdist.com', paymentTerms: 'Net 60' }
    ];
  });

  const [categories] = useState(['Analgesic', 'Antibiotic', 'Antiviral', 'Cardiovascular', 'Respiratory', 'Gastrointestinal', 'Neurological', 'Dermatological']);
  const [dosageForms] = useState(['Tablet', 'Capsule', 'Syrup', 'Injection', 'Cream', 'Ointment', 'Drops', 'Inhaler']);
  const [units] = useState(['mg', 'ml', 'g', 'mcg', 'IU']);

  useEffect(() => { localStorage.setItem('medicines', JSON.stringify(medicines)); }, [medicines]);
  useEffect(() => { localStorage.setItem('stock', JSON.stringify(stock)); }, [stock]);
  useEffect(() => { localStorage.setItem('suppliers', JSON.stringify(suppliers)); }, [suppliers]);

  const value = { medicines, setMedicines, stock, setStock, suppliers, setSuppliers, categories, dosageForms, units };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};

const useData = () => useContext(DataContext);

function App() {
  // Navigation Component (defined inside App for single-file)
  const Navigation = () => {
    const [drawerOpen, setDrawerOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const { stock, medicines } = useData();

    const lowStockCount = useMemo(() => {
      return stock.filter(s => {
        const medicine = medicines.find(m => m.id === s.medicineId);
        return medicine && s.quantity <= medicine.reorderLevel;
      }).length;
    }, [stock, medicines]);

    const expiredCount = useMemo(() => {
      const today = new Date().toISOString().split('T')[0];
      return stock.filter(s => s.expiryDate <= today).length;
    }, [stock]);

    const menuItems = [
      { text: 'Dashboard', icon: '📊', path: '/' },
      { text: 'Medicine Catalog', icon: '💊', path: '/medicines' },
      { text: 'Inventory', icon: '📦', path: '/inventory' },
      { text: 'Receive Stock', icon: '📥', path: '/receive-stock' },
      { text: 'Suppliers', icon: '🏢', path: '/suppliers' },
      { text: 'Settings', icon: '⚙️', path: '/settings' }
    ];

    return (
      <>
        <AppBar position="fixed" className="glass-effect" sx={{ backdropFilter: 'blur(10px)', backgroundColor: 'rgba(102, 126, 234, 0.9)' }}>
          <Toolbar>
            <IconButton color="inherit" onClick={() => setDrawerOpen(true)} edge="start" sx={{ mr: 2, display: { sm: 'none' } }}>
              <span className="material-icons">menu</span>
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 600 }}>
              🏥 MedInventory Pro
            </Typography>
            <Stack direction="row" spacing={2} sx={{ display: { xs: 'none', sm: 'flex' } }}>
              {menuItems.slice(0, 4).map((item) => (
                <Button
                  key={item.path}
                  color="inherit"
                  onClick={() => navigate(item.path)}
                  sx={{
                    backgroundColor: location.pathname === item.path ? 'rgba(255,255,255,0.2)' : 'transparent',
                    '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
                  }}
                >
                  {item.text}
                </Button>
              ))}
            </Stack>
            <Box sx={{ ml: 2 }}>
              <Badge badgeContent={lowStockCount} color="warning" sx={{ mr: 2 }}>
                <Tooltip title="Low Stock Items">
                  <IconButton color="inherit">
                    <span className="material-icons">inventory_2</span>
                  </IconButton>
                </Tooltip>
              </Badge>
              <Badge badgeContent={expiredCount} color="error">
                <Tooltip title="Expired Items">
                  <IconButton color="inherit">
                    <span className="material-icons">warning</span>
                  </IconButton>
                </Tooltip>
              </Badge>
            </Box>
          </Toolbar>
        </AppBar>

        <Drawer
          anchor="left"
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          sx={{
            '& .MuiDrawer-paper': {
              width: 280,
              backgroundColor: 'rgba(255,255,255,0.95)',
              backdropFilter: 'blur(10px)'
            }
          }}
        >
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 600, color: 'primary.main' }}>
              Navigation
            </Typography>
          </Box>
          <Divider />
          <List>
            {menuItems.map((item) => (
              <ListItem key={item.path} disablePadding>
                <ListItemButton
                  onClick={() => {
                    navigate(item.path);
                    setDrawerOpen(false);
                  }}
                  selected={location.pathname === item.path}
                >
                  <ListItemIcon>
                    <Typography variant="h6">{item.icon}</Typography>
                  </ListItemIcon>
                  <ListItemText primary={item.text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Drawer>
      </>
    );
  };

  // Dashboard Component
  const Dashboard = () => {
    const { medicines, stock, suppliers } = useData();
    const navigate = useNavigate();

    const stats = useMemo(() => {
      const today = new Date().toISOString().split('T')[0];
      const lowStock = stock.filter(s => {
        const medicine = medicines.find(m => m.id === s.medicineId);
        return medicine && s.quantity <= medicine.reorderLevel;
      }).length;

      const expired = stock.filter(s => s.expiryDate <= today).length;
      const nearExpiry = stock.filter(s => {
        const expiryDate = new Date(s.expiryDate);
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        return expiryDate > new Date() && expiryDate <= thirtyDaysFromNow;
      }).length;

      const totalValue = stock.reduce((sum, s) => sum + (s.quantity * s.unitPrice), 0);

      return { lowStock, expired, nearExpiry, totalValue };
    }, [medicines, stock]);

    const cards = [
      { title: 'Total Medicines', value: medicines.length, icon: '💊', color: 'primary', path: '/medicines' },
      { title: 'Total Suppliers', value: suppliers.length, icon: '🏢', color: 'secondary', path: '/suppliers' },
      { title: 'Low Stock Items', value: stats.lowStock, icon: '📉', color: 'warning', path: '/inventory' },
      { title: 'Expired Items', value: stats.expired, icon: '⚠️', color: 'error', path: '/inventory' },
      { title: 'Near Expiry', value: stats.nearExpiry, icon: '⏰', color: 'info', path: '/inventory' },
      { title: 'Total Inventory Value', value: `$${stats.totalValue.toFixed(2)}`, icon: '💰', color: 'success', path: '/inventory' }
    ];

    return (
      <Container maxWidth="lg" sx={{ mt: 10, mb: 4 }}>
        <Grow in timeout={500}>
          <Box>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: 'white', mb: 4 }}>
              📊 Dashboard Overview
            </Typography>

            <Grid container spacing={3}>
              {cards.map((card, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Zoom in timeout={300 * (index + 1)}>
                    <Card 
                      className="hover-scale glass-effect" 
                      sx={{ 
                        cursor: 'pointer',
                        height: '100%',
                        background: `linear-gradient(135deg, ${theme.palette[card.color].light}15, ${theme.palette[card.color].main}10)`
                      }}
                      onClick={() => navigate(card.path)}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Box>
                            <Typography color="textSecondary" gutterBottom variant="body2">
                              {card.title}
                            </Typography>
                            <Typography variant="h4" component="div" sx={{ color: theme.palette[card.color].main, fontWeight: 600 }}>
                              {card.value}
                            </Typography>
                          </Box>
                          <Typography variant="h2">
                            {card.icon}
                          </Typography>
                        </Box>
                      </CardContent>
                    </Card>
                  </Zoom>
                </Grid>
              ))}
            </Grid>

            <Box sx={{ mt: 4 }}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Card className="glass-effect">
                    <CardContent>
                      <Typography variant="h6" gutterBottom sx={{ fontWeight: 500 }}>
                        🔔 Recent Activities
                      </Typography>
                      <List>
                        <ListItem>
                          <ListItemIcon>
                            <Avatar sx={{ bgcolor: 'success.main', width: 32, height: 32 }}>
                              <span className="material-icons" style={{ fontSize: 18 }}>add</span>
                            </Avatar>
                          </ListItemIcon>
                          <ListItemText 
                            primary="New medicine added"
                            secondary="Ibuprofen 400mg added to catalog"
                          />
                        </ListItem>
                        <ListItem>
                          <ListItemIcon>
                            <Avatar sx={{ bgcolor: 'warning.main', width: 32, height: 32 }}>
                              <span className="material-icons" style={{ fontSize: 18 }}>inventory</span>
                            </Avatar>
                          </ListItemIcon>
                          <ListItemText 
                            primary="Low stock alert"
                            secondary="Amoxicillin running low"
                          />
                        </ListItem>
                        <ListItem>
                          <ListItemIcon>
                            <Avatar sx={{ bgcolor: 'info.main', width: 32, height: 32 }}>
                              <span className="material-icons" style={{ fontSize: 18 }}>local_shipping</span>
                            </Avatar>
                          </ListItemIcon>
                          <ListItemText 
                            primary="Stock received"
                            secondary="100 units of Paracetamol received"
                          />
                        </ListItem>
                      </List>
                    </CardContent>
                  </Card>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Card className="glass-effect">
                    <CardContent>
                      <Typography variant="h6" gutterBottom sx={{ fontWeight: 500 }}>
                        ⚡ Quick Actions
                      </Typography>
                      <Stack spacing={2} sx={{ mt: 2 }}>
                        <Button 
                          variant="contained" 
                          fullWidth 
                          startIcon={<span className="material-icons">add</span>}
                          onClick={() => navigate('/medicines')}
                          sx={{ justifyContent: 'flex-start' }}
                        >
                          Add New Medicine
                        </Button>
                        <Button 
                          variant="contained" 
                          color="secondary"
                          fullWidth 
                          startIcon={<span className="material-icons">inventory</span>}
                          onClick={() => navigate('/receive-stock')}
                          sx={{ justifyContent: 'flex-start' }}
                        >
                          Receive Stock
                        </Button>
                        <Button 
                          variant="outlined" 
                          fullWidth 
                          startIcon={<span className="material-icons">assessment</span>}
                          onClick={() => navigate('/inventory')}
                          sx={{ justifyContent: 'flex-start' }}
                        >
                          View Inventory Report
                        </Button>
                      </Stack>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Grow>
      </Container>
    );
  };

  // Medicine Catalog Component
  const MedicineCatalog = () => {
    const { medicines, setMedicines, suppliers, categories, dosageForms } = useData();
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [search, setSearch] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('');
    const [supplierFilter, setSupplierFilter] = useState('');
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editingMedicine, setEditingMedicine] = useState(null);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
    const [selectedItems, setSelectedItems] = useState([]);
    const [bulkDeleteDialog, setBulkDeleteDialog] = useState(false);

    const [formData, setFormData] = useState({
      name: '', category: '', dosageForm: '', unitSize: '', defaultPrice: '', supplier: '', reorderLevel: '', manufacturer: '', barcode: ''
    });

    const filteredMedicines = useMemo(() => {
      return medicines.filter(medicine => {
        const matchesSearch = medicine.name.toLowerCase().includes(search.toLowerCase()) || medicine.barcode?.includes(search);
        const matchesCategory = !categoryFilter || medicine.category === categoryFilter;
        const matchesSupplier = !supplierFilter || medicine.supplier === supplierFilter;
        return matchesSearch && matchesCategory && matchesSupplier;
      });
    }, [medicines, search, categoryFilter, supplierFilter]);

    const handleOpenDialog = (medicine = null) => {
      if (medicine) {
        setEditingMedicine(medicine);
        setFormData(medicine);
      } else {
        setEditingMedicine(null);
        setFormData({ name: '', category: '', dosageForm: '', unitSize: '', defaultPrice: '', supplier: '', reorderLevel: '', manufacturer: '', barcode: '' });
      }
      setDialogOpen(true);
    };

    const handleSave = () => {
      if (!formData.name || !formData.category || !formData.defaultPrice || !formData.unitSize) {
        setSnackbar({ open: true, message: 'Please fill all required fields', severity: 'error' });
        return;
      }

      if (parseFloat(formData.defaultPrice) < 0 || parseFloat(formData.reorderLevel) < 0) {
        setSnackbar({ open: true, message: 'Numeric values must be ≥ 0', severity: 'error' });
        return;
      }

      if (editingMedicine) {
        setMedicines(prev => prev.map(m => m.id === editingMedicine.id ? { ...formData, id: m.id } : m));
        setSnackbar({ open: true, message: 'Medicine updated successfully', severity: 'success' });
      } else {
        const newMedicine = { ...formData, id: Date.now(), defaultPrice: parseFloat(formData.defaultPrice), reorderLevel: parseInt(formData.reorderLevel) || 0 };
        setMedicines(prev => [...prev, newMedicine]);
        setSnackbar({ open: true, message: 'Medicine added successfully', severity: 'success' });
      }
      setDialogOpen(false);
    };

    const handleDelete = (id) => {
      setMedicines(prev => prev.filter(m => m.id !== id));
      setSnackbar({ open: true, message: 'Medicine deleted successfully', severity: 'success' });
    };

    const handleBulkDelete = () => {
      setMedicines(prev => prev.filter(m => !selectedItems.includes(m.id)));
      setSelectedItems([]);
      setBulkDeleteDialog(false);
      setSnackbar({ open: true, message: `${selectedItems.length} medicines deleted successfully`, severity: 'success' });
    };

    const handleSelectAll = (event) => {
      if (event.target.checked) {
        setSelectedItems(filteredMedicines.map(m => m.id));
      } else {
        setSelectedItems([]);
      }
    };

    const handleSelectItem = (id) => {
      setSelectedItems(prev => 
        prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
      );
    };

    return (
      <Container maxWidth="lg" sx={{ mt: 10, mb: 4 }}>
        <Slide direction="up" in timeout={500}>
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h4" sx={{ fontWeight: 600, color: 'white' }}>
                💊 Medicine Catalog
              </Typography>
              <Button
                variant="contained"
                startIcon={<span className="material-icons">add</span>}
                onClick={() => handleOpenDialog()}
                sx={{ borderRadius: 2 }}
              >
                Add Medicine
              </Button>
            </Box>

            <Card className="glass-effect">
              <CardContent>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      placeholder="Search by name or barcode..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <span className="material-icons">search</span>
                          </InputAdornment>
                        )
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormControl fullWidth>
                      <InputLabel>Category Filter</InputLabel>
                      <Select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} label="Category Filter">
                        <MenuItem value="">All Categories</MenuItem>
                        {categories.map(cat => (
                          <MenuItem key={cat} value={cat}>{cat}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <FormControl fullWidth>
                      <InputLabel>Supplier Filter</InputLabel>
                      <Select value={supplierFilter} onChange={(e) => setSupplierFilter(e.target.value)} label="Supplier Filter">
                        <MenuItem value="">All Suppliers</MenuItem>
                        {suppliers.map(sup => (
                          <MenuItem key={sup.id} value={sup.name}>{sup.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  {selectedItems.length > 0 && (
                    <Button
                      color="error"
                      startIcon={<span className="material-icons">delete</span>}
                      onClick={() => setBulkDeleteDialog(true)}
                    >
                      Delete Selected ({selectedItems.length})
                    </Button>
                  )}
                  <Box>
                    <Typography variant="body2" color="textSecondary">
                      Showing {filteredMedicines.length} of {medicines.length} medicines
                    </Typography>
                  </Box>
                </Box>

                <Paper sx={{ mb: 2 }}>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell padding="checkbox">
                            <Checkbox
                              indeterminate={selectedItems.length > 0 && selectedItems.length < filteredMedicines.length}
                              checked={selectedItems.length === filteredMedicines.length && filteredMedicines.length > 0}
                              onChange={handleSelectAll}
                            />
                          </TableCell>
                          <TableCell>Name</TableCell>
                          <TableCell>Category</TableCell>
                          <TableCell>Dosage Form</TableCell>
                          <TableCell>Unit Size</TableCell>
                          <TableCell>Price</TableCell>
                          <TableCell>Reorder Level</TableCell>
                          <TableCell>Supplier</TableCell>
                          <TableCell>Manufacturer</TableCell>
                          <TableCell>Barcode</TableCell>
                          <TableCell>Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {filteredMedicines.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((medicine) => (
                          <TableRow key={medicine.id}>
                            <TableCell padding="checkbox">
                              <Checkbox
                                checked={selectedItems.includes(medicine.id)}
                                onChange={() => handleSelectItem(medicine.id)}
                              />
                            </TableCell>
                            <TableCell>{medicine.name}</TableCell>
                            <TableCell>{medicine.category}</TableCell>
                            <TableCell>{medicine.dosageForm}</TableCell>
                            <TableCell>{medicine.unitSize}</TableCell>
                            <TableCell>${medicine.defaultPrice.toFixed(2)}</TableCell>
                            <TableCell>{medicine.reorderLevel}</TableCell>
                            <TableCell>{medicine.supplier}</TableCell>
                            <TableCell>{medicine.manufacturer}</TableCell>
                            <TableCell>{medicine.barcode}</TableCell>
                            <TableCell>
                              <IconButton onClick={() => handleOpenDialog(medicine)} size="small">
                                <span className="material-icons">edit</span>
                              </IconButton>
                              <IconButton onClick={() => handleDelete(medicine.id)} size="small" color="error">
                                <span className="material-icons">delete</span>
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                        {filteredMedicines.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={11} align="center">
                              <Typography>No medicines found.</Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={filteredMedicines.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={(event, newPage) => setPage(newPage)}
                    onRowsPerPageChange={(event) => {
                      setRowsPerPage(parseInt(event.target.value, 10));
                      setPage(0);
                    }}
                  />
                </Paper>
              </CardContent>
            </Card>

            <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
              <DialogTitle>{editingMedicine ? 'Edit Medicine' : 'Add New Medicine'}</DialogTitle>
              <DialogContent>
                <Stack spacing={2} sx={{ mt: 1 }}>
                  <TextField
                    label="Name *"
                    fullWidth
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  <FormControl fullWidth>
                    <InputLabel>Category *</InputLabel>
                    <Select value={formData.category} label="Category *" onChange={(e) => setFormData({ ...formData, category: e.target.value })}>
                      {categories.map((cat) => (
                        <MenuItem key={cat} value={cat}>
                          {cat}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth>
                    <InputLabel>Dosage Form *</InputLabel>
                    <Select value={formData.dosageForm} label="Dosage Form *" onChange={(e) => setFormData({ ...formData, dosageForm: e.target.value })}>
                      {dosageForms.map((form) => (
                        <MenuItem key={form} value={form}>
                          {form}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <TextField
                    label="Unit Size *"
                    fullWidth
                    required
                    value={formData.unitSize}
                    onChange={(e) => setFormData({ ...formData, unitSize: e.target.value })}
                  />
                  <TextField
                    label="Default Price *"
                    fullWidth
                    required
                    type="number"
                    step="0.01"
                    value={formData.defaultPrice}
                    onChange={(e) => setFormData({ ...formData, defaultPrice: e.target.value })}
                  />
                  <TextField
                    label="Reorder Level"
                    fullWidth
                    type="number"
                    value={formData.reorderLevel}
                    onChange={(e) => setFormData({ ...formData, reorderLevel: e.target.value })}
                  />
                  <FormControl fullWidth>
                    <InputLabel>Supplier</InputLabel>
                    <Select value={formData.supplier} label="Supplier" onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}>
                      <MenuItem value="">None</MenuItem>
                      {suppliers.map((sup) => (
                        <MenuItem key={sup.id} value={sup.name}>
                          {sup.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <TextField
                    label="Manufacturer"
                    fullWidth
                    value={formData.manufacturer}
                    onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
                  />
                  <TextField
                    label="Barcode"
                    fullWidth
                    value={formData.barcode}
                    onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                  />
                </Stack>
              </DialogContent>
              <DialogActions>
                <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} variant="contained">Save</Button>
              </DialogActions>
            </Dialog>

            <Dialog open={bulkDeleteDialog} onClose={() => setBulkDeleteDialog(false)}>
              <DialogTitle>Delete Selected Medicines?</DialogTitle>
              <DialogContent>
                <Typography>This will permanently delete {selectedItems.length} medicines.</Typography>
              </DialogContent>
              <DialogActions>
                <Button onClick={() => setBulkDeleteDialog(false)}>Cancel</Button>
                <Button onClick={handleBulkDelete} color="error">Delete</Button>
              </DialogActions>
            </Dialog>

            <Snackbar
              open={snackbar.open}
              autoHideDuration={6000}
              onClose={() => setSnackbar({ ...snackbar, open: false })}
            >
              <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity}>
                {snackbar.message}
              </Alert>
            </Snackbar>
          </Box>
        </Slide>
      </Container>
    );
  };

  // Inventory Component (similar porting - abbreviated for brevity; full code follows the pattern)
  const Inventory = () => {
    const { stock, setStock, medicines, suppliers } = useData();
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [search, setSearch] = useState('');
    const [medicineFilter, setMedicineFilter] = useState('');
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editingStock, setEditingStock] = useState(null);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    const [formDataStock, setFormDataStock] = useState({
      medicineId: '', batchNo: '', expiryDate: '', quantity: '', location: '', supplier: '', purchaseDate: new Date().toISOString().split('T')[0], unitPrice: ''
    });

    const filteredStock = useMemo(() => {
      return stock.filter((s) => {
        const med = medicines.find((m) => m.id === s.medicineId);
        const matchesSearch = med?.name.toLowerCase().includes(search.toLowerCase()) || s.batchNo.includes(search);
        const matchesMed = !medicineFilter || s.medicineId.toString() === medicineFilter;
        return matchesSearch && matchesMed;
      });
    }, [stock, medicines, search, medicineFilter]);

    const getStatus = (item) => {
      const med = medicines.find((m) => m.id === item.medicineId);
      const today = new Date().toISOString().split('T')[0];
      if (item.expiryDate <= today) return 'expired';
      if (med && item.quantity <= med.reorderLevel) return 'low-stock';
      return 'good';
    };

    const formatDate = (dateStr) => new Date(dateStr).toLocaleDateString();

    const handleOpenStockDialog = (stockItem = null) => {
      if (stockItem) {
        setEditingStock(stockItem);
        setFormDataStock({
          medicineId: stockItem.medicineId.toString(),
          batchNo: stockItem.batchNo,
          expiryDate: stockItem.expiryDate,
          quantity: stockItem.quantity.toString(),
          location: stockItem.location,
          supplier: stockItem.supplier,
          purchaseDate: stockItem.purchaseDate,
          unitPrice: stockItem.unitPrice.toString()
        });
      }
      setDialogOpen(true);
    };

    const handleSaveStock = () => {
      if (
        !formDataStock.medicineId ||
        !formDataStock.batchNo ||
        !formDataStock.expiryDate ||
        !formDataStock.quantity ||
        !formDataStock.unitPrice
      ) {
        setSnackbar({ open: true, message: 'Please fill all required fields', severity: 'error' });
        return;
      }

      if (parseInt(formDataStock.quantity) < 0 || parseFloat(formDataStock.unitPrice) < 0) {
        setSnackbar({ open: true, message: 'Numeric values must be ≥ 0', severity: 'error' });
        return;
      }

      const updatedStock = {
        id: editingStock.id,
        medicineId: parseInt(formDataStock.medicineId),
        batchNo: formDataStock.batchNo,
        expiryDate: formDataStock.expiryDate,
        quantity: parseInt(formDataStock.quantity),
        location: formDataStock.location,
        supplier: formDataStock.supplier,
        purchaseDate: formDataStock.purchaseDate,
        unitPrice: parseFloat(formDataStock.unitPrice)
      };

      setStock((prev) => prev.map((s) => (s.id === editingStock.id ? updatedStock : s)));
      setDialogOpen(false);
      setSnackbar({ open: true, message: 'Stock updated successfully', severity: 'success' });
    };

    const handleDeleteStock = (id) => {
      setStock((prev) => prev.filter((s) => s.id !== id));
      setSnackbar({ open: true, message: 'Stock deleted successfully', severity: 'success' });
    };

    return (
      <Container maxWidth="lg" sx={{ mt: 10, mb: 4 }}>
        <Slide direction="up" in timeout={500}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: 'white', mb: 3 }}>
              📦 Inventory Management
            </Typography>

            <Card className="glass-effect">
              <CardContent>
                <Grid container spacing={2} sx={{ mb: 3 }}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      placeholder="Search by medicine name or batch..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <span className="material-icons">search</span>
                          </InputAdornment>
                        )
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                      <InputLabel>Medicine Filter</InputLabel>
                      <Select value={medicineFilter} onChange={(e) => setMedicineFilter(e.target.value)} label="Medicine Filter">
                        <MenuItem value="">All Medicines</MenuItem>
                        {medicines.map((m) => (
                          <MenuItem key={m.id} value={m.id.toString()}>
                            {m.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>

                <Paper sx={{ mb: 2 }}>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>Medicine</TableCell>
                          <TableCell>Batch No</TableCell>
                          <TableCell>Expiry Date</TableCell>
                          <TableCell>Quantity</TableCell>
                          <TableCell>Location</TableCell>
                          <TableCell>Unit Price</TableCell>
                          <TableCell>Purchase Date</TableCell>
                          <TableCell>Status</TableCell>
                          <TableCell>Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {filteredStock.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              {medicines.find((m) => m.id === item.medicineId)?.name || 'Unknown'}
                            </TableCell>
                            <TableCell>{item.batchNo}</TableCell>
                            <TableCell>{formatDate(item.expiryDate)}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{item.location}</TableCell>
                            <TableCell>${item.unitPrice.toFixed(2)}</TableCell>
                            <TableCell>{formatDate(item.purchaseDate)}</TableCell>
                            <TableCell>
                              <Chip
                                label={getStatus(item)}
                                className={`status-${getStatus(item)}`}
                                size="small"
                              />
                            </TableCell>
                            <TableCell>
                              <IconButton onClick={() => handleOpenStockDialog(item)} size="small">
                                <span className="material-icons">edit</span>
                              </IconButton>
                              <IconButton onClick={() => handleDeleteStock(item.id)} size="small" color="error">
                                <span className="material-icons">delete</span>
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                        {filteredStock.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={9} align="center">
                              <Typography>No stock items found.</Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={filteredStock.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={(event, newPage) => setPage(newPage)}
                    onRowsPerPageChange={(event) => {
                      setRowsPerPage(parseInt(event.target.value, 10));
                      setPage(0);
                    }}
                  />
                </Paper>
              </CardContent>
            </Card>

            <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
              <DialogTitle>Edit Stock Item</DialogTitle>
              <DialogContent>
                <Stack spacing={2} sx={{ mt: 1 }}>
                  <Autocomplete
                    options={medicines}
                    getOptionLabel={(option) => option.name}
                    value={medicines.find((m) => m.id.toString() === formDataStock.medicineId) || null}
                    onChange={(event, value) =>
                      setFormDataStock({ ...formDataStock, medicineId: value ? value.id.toString() : '' })
                    }
                    renderInput={(params) => <TextField {...params} label="Medicine *" required />}
                  />
                  <TextField
                    label="Batch Number *"
                    fullWidth
                    required
                    value={formDataStock.batchNo}
                    onChange={(e) => setFormDataStock({ ...formDataStock, batchNo: e.target.value })}
                  />
                  <TextField
                    label="Expiry Date *"
                    type="date"
                    fullWidth
                    required
                    InputLabelProps={{ shrink: true }}
                    value={formDataStock.expiryDate}
                    onChange={(e) => setFormDataStock({ ...formDataStock, expiryDate: e.target.value })}
                  />
                  <TextField
                    label="Quantity *"
                    type="number"
                    fullWidth
                    required
                    value={formDataStock.quantity}
                    onChange={(e) => setFormDataStock({ ...formDataStock, quantity: e.target.value })}
                  />
                  <TextField
                    label="Location"
                    fullWidth
                    value={formDataStock.location}
                    onChange={(e) => setFormDataStock({ ...formDataStock, location: e.target.value })}
                  />
                  <FormControl fullWidth>
                    <InputLabel>Supplier</InputLabel>
                    <Select value={formDataStock.supplier} label="Supplier" onChange={(e) => setFormDataStock({ ...formDataStock, supplier: e.target.value })}>
                      <MenuItem value="">Select Supplier</MenuItem>
                      {suppliers.map((s) => (
                        <MenuItem key={s.id} value={s.name}>
                          {s.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <TextField
                    label="Purchase Date"
                    type="date"
                    fullWidth
                    InputLabelProps={{ shrink: true }}
                    value={formDataStock.purchaseDate}
                    onChange={(e) => setFormDataStock({ ...formDataStock, purchaseDate: e.target.value })}
                  />
                  <TextField
                    label="Unit Price *"
                    type="number"
                    step="0.01"
                    fullWidth
                    required
                    value={formDataStock.unitPrice}
                    onChange={(e) => setFormDataStock({ ...formDataStock, unitPrice: e.target.value })}
                  />
                </Stack>
              </DialogContent>
              <DialogActions>
                <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSaveStock} variant="contained">Save</Button>
              </DialogActions>
            </Dialog>

            <Snackbar
              open={snackbar.open}
              autoHideDuration={6000}
              onClose={() => setSnackbar({ ...snackbar, open: false })}
            >
              <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity}>
                {snackbar.message}
              </Alert>
            </Snackbar>
          </Box>
        </Slide>
      </Container>
    );
  };

  // Receive Stock Component
  const ReceiveStock = () => {
    const { stock, setStock, medicines, suppliers } = useData();
    const [formData, setFormData] = useState({
      medicineId: '', batchNo: '', expiryDate: '', quantity: '', location: '', supplier: '', purchaseDate: new Date().toISOString().split('T')[0], unitPrice: ''
    });
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    const handleSubmit = () => {
      if (
        !formData.medicineId ||
        !formData.batchNo ||
        !formData.expiryDate ||
        !formData.quantity ||
        !formData.unitPrice
      ) {
        setSnackbar({ open: true, message: 'Please fill required fields', severity: 'error' });
        return;
      }

      if (parseInt(formData.quantity) < 0 || parseFloat(formData.unitPrice) < 0) {
        setSnackbar({ open: true, message: 'Numeric values must be ≥ 0', severity: 'error' });
        return;
      }

      const newStock = {
        id: Date.now(),
        medicineId: parseInt(formData.medicineId),
        batchNo: formData.batchNo,
        expiryDate: formData.expiryDate,
        quantity: parseInt(formData.quantity),
        location: formData.location,
        supplier: formData.supplier,
        purchaseDate: formData.purchaseDate,
        unitPrice: parseFloat(formData.unitPrice)
      };

      setStock((prev) => [...prev, newStock]);
      setFormData({
        medicineId: '', batchNo: '', expiryDate: '', quantity: '', location: '', supplier: '', purchaseDate: new Date().toISOString().split('T')[0], unitPrice: ''
      });
      setSnackbar({ open: true, message: 'Stock received successfully', severity: 'success' });
    };

    return (
      <Container maxWidth="md" sx={{ mt: 10, mb: 4 }}>
        <Slide direction="up" in timeout={500}>
          <Box>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: 'white' }}>
              📥 Receive New Stock
            </Typography>
            <Card className="glass-effect">
              <CardContent>
                <Stack spacing={3}>
                  <Autocomplete
                    options={medicines}
                    getOptionLabel={(option) => option.name}
                    value={medicines.find((m) => m.id.toString() === formData.medicineId) || null}
                    onChange={(event, value) =>
                      setFormData({ ...formData, medicineId: value ? value.id.toString() : '' })
                    }
                    renderInput={(params) => <TextField {...params} label="Medicine *" required />}
                  />
                  <TextField
                    label="Batch Number *"
                    fullWidth
                    required
                    value={formData.batchNo}
                    onChange={(e) => setFormData({ ...formData, batchNo: e.target.value })}
                  />
                  <TextField
                    label="Expiry Date *"
                    type="date"
                    fullWidth
                    required
                    InputLabelProps={{ shrink: true }}
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                  />
                  <TextField
                    label="Quantity *"
                    type="number"
                    fullWidth
                    required
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  />
                  <TextField
                    label="Location"
                    fullWidth
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                  <FormControl fullWidth>
                    <InputLabel>Supplier</InputLabel>
                    <Select value={formData.supplier} onChange={(e) => setFormData({ ...formData, supplier: e.target.value })} label="Supplier">
                      <MenuItem value="">Select Supplier</MenuItem>
                      {suppliers.map((s) => (
                        <MenuItem key={s.id} value={s.name}>
                          {s.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <TextField
                    label="Purchase Date"
                    type="date"
                    fullWidth
                    InputLabelProps={{ shrink: true }}
                    value={formData.purchaseDate}
                    onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                  />
                  <TextField
                    label="Unit Price *"
                    type="number"
                    step="0.01"
                    fullWidth
                    required
                    value={formData.unitPrice}
                    onChange={(e) => setFormData({ ...formData, unitPrice: e.target.value })}
                  />
                  <Button variant="contained" onClick={handleSubmit} fullWidth size="large">
                    Receive Stock
                  </Button>
                </Stack>
              </CardContent>
            </Card>

            <Snackbar
              open={snackbar.open}
              autoHideDuration={6000}
              onClose={() => setSnackbar({ ...snackbar, open: false })}
            >
              <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity}>
                {snackbar.message}
              </Alert>
            </Snackbar>
          </Box>
        </Slide>
      </Container>
    );
  };

  // Suppliers Component
  const Suppliers = () => {
    const { suppliers, setSuppliers } = useData();
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editingSupplier, setEditingSupplier] = useState(null);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    const [formData, setFormData] = useState({
      name: '', contact: '', email: '', paymentTerms: ''
    });

    const handleOpenDialog = (supplier = null) => {
      if (supplier) {
        setEditingSupplier(supplier);
        setFormData(supplier);
      } else {
        setEditingSupplier(null);
        setFormData({ name: '', contact: '', email: '', paymentTerms: '' });
      }
      setDialogOpen(true);
    };

    const handleSave = () => {
      if (!formData.name) {
        setSnackbar({ open: true, message: 'Please fill the name', severity: 'error' });
        return;
      }

      if (editingSupplier) {
        setSuppliers((prev) =>
          prev.map((s) => (s.id === editingSupplier.id ? { ...formData, id: s.id } : s))
        );
        setSnackbar({ open: true, message: 'Supplier updated successfully', severity: 'success' });
      } else {
        const newSupplier = { ...formData, id: Date.now() };
        setSuppliers((prev) => [...prev, newSupplier]);
        setSnackbar({ open: true, message: 'Supplier added successfully', severity: 'success' });
      }
      setDialogOpen(false);
    };

    const handleDelete = (id) => {
      setSuppliers((prev) => prev.filter((s) => s.id !== id));
      setSnackbar({ open: true, message: 'Supplier deleted successfully', severity: 'success' });
    };

    return (
      <Container maxWidth="lg" sx={{ mt: 10, mb: 4 }}>
        <Slide direction="up" in timeout={500}>
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h4" sx={{ fontWeight: 600, color: 'white' }}>
                🏢 Suppliers
              </Typography>
              <Button
                variant="contained"
                startIcon={<span className="material-icons">add</span>}
                onClick={() => handleOpenDialog()}
              >
                Add Supplier
              </Button>
            </Box>

            <Card className="glass-effect">
              <CardContent>
                <Paper sx={{ mb: 2 }}>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>Name</TableCell>
                          <TableCell>Contact</TableCell>
                          <TableCell>Email</TableCell>
                          <TableCell>Payment Terms</TableCell>
                          <TableCell>Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {suppliers.map((supplier) => (
                          <TableRow key={supplier.id}>
                            <TableCell>{supplier.name}</TableCell>
                            <TableCell>{supplier.contact}</TableCell>
                            <TableCell>{supplier.email}</TableCell>
                            <TableCell>{supplier.paymentTerms}</TableCell>
                            <TableCell>
                              <IconButton onClick={() => handleOpenDialog(supplier)} size="small">
                                <span className="material-icons">edit</span>
                              </IconButton>
                              <IconButton onClick={() => handleDelete(supplier.id)} size="small" color="error">
                                <span className="material-icons">delete</span>
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                        {suppliers.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={5} align="center">
                              <Typography>No suppliers found.</Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Paper>
              </CardContent>
            </Card>

            <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
              <DialogTitle>{editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}</DialogTitle>
              <DialogContent>
                <Stack spacing={2} sx={{ mt: 1 }}>
                  <TextField
                    label="Name *"
                    fullWidth
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  <TextField
                    label="Contact"
                    fullWidth
                    value={formData.contact}
                    onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                  />
                  <TextField
                    label="Email"
                    fullWidth
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                  <TextField
                    label="Payment Terms"
                    fullWidth
                    value={formData.paymentTerms}
                    onChange={(e) => setFormData({ ...formData, paymentTerms: e.target.value })}
                  />
                </Stack>
              </DialogContent>
              <DialogActions>
                <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} variant="contained">Save</Button>
              </DialogActions>
            </Dialog>

            <Snackbar
              open={snackbar.open}
              autoHideDuration={6000}
              onClose={() => setSnackbar({ ...snackbar, open: false })}
            >
              <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity}>
                {snackbar.message}
              </Alert>
            </Snackbar>
          </Box>
        </Slide>
      </Container>
    );
  };

  // Settings Component
  const Settings = () => (
    <Container maxWidth="lg" sx={{ mt: 10, mb: 4 }}>
      <Slide direction="up" in timeout={500}>
        <Box>
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: 'white' }}>
            ⚙️ Settings
          </Typography>
          <Card className="glass-effect">
            <CardContent>
              <Typography variant="body1">
                Application settings and configurations will be managed here in future updates.
              </Typography>
            </CardContent>
          </Card>
        </Box>
      </Slide>
    </Container>
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <DataProvider>
        <BrowserRouter>
          <Navigation />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/medicines" element={<MedicineCatalog />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/receive-stock" element={<ReceiveStock />} />
            <Route path="/suppliers" element={<Suppliers />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </BrowserRouter>
      </DataProvider>
    </ThemeProvider>
  );
}

export default App;